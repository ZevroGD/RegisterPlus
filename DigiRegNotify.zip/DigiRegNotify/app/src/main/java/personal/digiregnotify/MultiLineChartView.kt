package personal.digiregnotify

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.text.format.DateFormat
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.MaterialColors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ChartSeries(
    val subjectId: Int,
    val points: List<Pair<Long, Float>>, // (dateMillis, grade), oldest -> newest
    val color: Int,
    val strokeWidthDp: Float = 3f, // 0 hides both the line and its points for this subject
    val label: String = "",           // subject name, shown when a date is selected
    val details: List<String> = emptyList() // per point, e.g. "Test"; same order as points
)

/**
 * Plots several subjects' grades on one shared timeline, each in its own color/thickness,
 * with a labeled Y-axis so the actual grade values are readable, not just relative shapes.
 *
 * With [interactive] on, dragging a finger along the chart moves a dotted cursor from date to
 * date and shows every mark of that date as a colored chip (subject, kind, mark).
 * With [showMonthLabels] on, month names are drawn along the bottom.
 */
class MultiLineChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var interactive = false
    var showMonthLabels = false
        set(value) {
            field = value
            invalidate()
        }

    private var series: List<ChartSeries> = emptyList()
    private var selectedDate: Long? = null
    private val density = resources.displayMetrics.density

    // Geometry of the last draw, so touches can be mapped back to dates.
    private var geoLeft = 0f
    private var geoRight = 0f
    private var geoMinDate = 0L
    private var geoDateRange = 1L

    // The theme's own colors, so everything matches the rest of the text in light and dark mode.
    private val onSurface: Int by lazy {
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, Color.GRAY)
    }
    private val surface: Int by lazy {
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurface, Color.BLACK)
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#22888888")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val axisTextPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = onSurface
            alpha = 160
            textSize = 10f * density
            textAlign = Paint.Align.RIGHT
        }
    }

    private val monthTextPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = onSurface
            alpha = 160
            textSize = 11f * density
            textAlign = Paint.Align.CENTER
        }
    }

    private val cursorPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = onSurface
            alpha = 140
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * density
            pathEffect = DashPathEffect(floatArrayOf(4f * density, 4f * density), 0f)
        }
    }

    private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val chipTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }

    fun setSeries(newSeries: List<ChartSeries>) {
        series = newSeries
        // Drop the selection if its date is no longer shown (e.g. the subject was hidden).
        if (selectedDate != null && selectedDate !in visibleDates()) selectedDate = null
        invalidate()
    }

    private fun visibleDates(): List<Long> =
        series.filter { it.strokeWidthDp > 0f }.flatMap { s -> s.points.map { it.first } }.distinct().sorted()

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!interactive) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                select(event.x)
            }
            MotionEvent.ACTION_MOVE -> select(event.x)
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    /** Snaps the cursor to the date with marks that is nearest to the finger. */
    private fun select(x: Float) {
        val dates = visibleDates()
        if (dates.isEmpty() || geoRight <= geoLeft) return
        val touched = geoMinDate + (((x - geoLeft) / (geoRight - geoLeft)).coerceIn(0f, 1f) * geoDateRange).toLong()
        val nearest = dates.minByOrNull { Math.abs(it - touched) } ?: return
        if (nearest != selectedDate) {
            selectedDate = nearest
            invalidate()
        }
    }

    private fun formatValue(v: Float): String = GradeFormat.format(v)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val allPoints = series.flatMap { it.points }
        if (allPoints.isEmpty()) return

        val padding = 8f * density
        val axisWidth = 24f * density // reserved space for the "2 4 6 8 10" labels on the left
        val monthRow = if (showMonthLabels) 20f * density else 0f
        val chartLeft = axisWidth
        val chartRight = width - padding
        val chartTop = padding
        val chartBottom = height - padding - monthRow
        val w = chartRight - chartLeft
        val h = chartBottom - chartTop
        if (w <= 0 || h <= 0) return

        // The axis only reaches as low as the marks do, in steps of 2, but never lower than
        // is needed: 5 -> starts at 4, and it never goes below 4 unless a mark is under 4.
        val visibleMin = series.filter { it.strokeWidthDp > 0f }
            .flatMap { it.points }.minOfOrNull { it.second } ?: 1f
        val minVal = (Math.floor(((visibleMin - 1f) / 2f).toDouble()).toFloat() * 2f)
            .coerceIn(0f, 4f)
        val maxVal = 10f
        val range = (maxVal - minVal).coerceAtLeast(0.01f)

        fun yFor(value: Float) = chartTop + h - ((value - minVal) / range) * h

        // Axis: a line + number every 2 grade points, from the lower bound up to 10.
        var gridValue = if (minVal < 2f) 2f else minVal
        while (gridValue <= maxVal) {
            val y = yFor(gridValue)
            canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
            canvas.drawText(gridValue.toInt().toString(), axisWidth - 6f * density, y + 3f * density, axisTextPaint)
            gridValue += 2f
        }

        val minDate = allPoints.minOf { it.first }
        val maxDate = allPoints.maxOf { it.first }
        val dateRange = (maxDate - minDate).coerceAtLeast(1L)
        geoLeft = chartLeft
        geoRight = chartRight
        geoMinDate = minDate
        geoDateRange = dateRange

        fun xFor(dateMillis: Long) = chartLeft + ((dateMillis - minDate).toFloat() / dateRange) * w

        if (showMonthLabels) drawMonthLabels(canvas, minDate, maxDate, chartLeft, chartRight, chartBottom, ::xFor)

        val selected = if (interactive) selectedDate else null

        for (s in series) {
            if (s.points.isEmpty() || s.strokeWidthDp <= 0f) continue // 0 width = hidden entirely

            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = s.color
                style = Paint.Style.STROKE
                strokeWidth = s.strokeWidthDp * density
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = s.color
                style = Paint.Style.FILL
            }
            val dotRadius = (s.strokeWidthDp + 1f) * density / 2

            if (s.points.size >= 2) {
                var prevX = xFor(s.points[0].first)
                var prevY = yFor(s.points[0].second)
                for (i in 1 until s.points.size) {
                    val cx = xFor(s.points[i].first)
                    val cy = yFor(s.points[i].second)
                    canvas.drawLine(prevX, prevY, cx, cy, linePaint)
                    prevX = cx
                    prevY = cy
                }
            }
            for ((date, value) in s.points) {
                val r = if (date == selected) dotRadius * 1.9f else dotRadius
                canvas.drawCircle(xFor(date), yFor(value), r, dotPaint)
            }
        }

        if (selected != null) {
            val cursorX = xFor(selected)
            canvas.drawLine(cursorX, chartTop, cursorX, chartBottom, cursorPaint)
            drawChips(canvas, selected, cursorX, chartLeft, chartRight, chartTop, chartBottom)
        }
    }

    /** Month names at the first of each month inside the plotted range. */
    private fun drawMonthLabels(
        canvas: Canvas, minDate: Long, maxDate: Long,
        chartLeft: Float, chartRight: Float, chartBottom: Float,
        xFor: (Long) -> Float
    ) {
        val fmt = SimpleDateFormat("MMM", Locale.getDefault())
        val cal = Calendar.getInstance().apply {
            timeInMillis = minDate
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis < minDate) cal.add(Calendar.MONTH, 1)
        val baseline = chartBottom + 15f * density
        var guard = 0
        while (cal.timeInMillis <= maxDate && guard++ < 24) {
            val x = xFor(cal.timeInMillis)
            val label = fmt.format(cal.time)
            val half = monthTextPaint.measureText(label) / 2
            canvas.drawText(label, x.coerceIn(chartLeft + half, chartRight - half), baseline, monthTextPaint)
            cal.add(Calendar.MONTH, 1)
        }
    }

    /** The date, then one chip per mark of that date, stacked above the bottom edge. */
    private fun drawChips(
        canvas: Canvas, date: Long, cursorX: Float,
        chartLeft: Float, chartRight: Float, chartTop: Float, chartBottom: Float
    ) {
        data class Chip(val text: String, val background: Int, val textColor: Int)

        val chips = mutableListOf<Chip>()
        val pattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), "dMMMM")
        chips.add(Chip(SimpleDateFormat(pattern, Locale.getDefault()).format(Date(date)), onSurface, surface))
        for (s in series) {
            if (s.strokeWidthDp <= 0f) continue
            s.points.forEachIndexed { i, (d, value) ->
                if (d != date) return@forEachIndexed
                val kind = s.details.getOrNull(i).orEmpty()
                val text = buildString {
                    append(s.label.ifBlank { "Subject" })
                    append(" – ")
                    if (kind.isNotBlank()) append(kind).append(": ")
                    append(formatValue(value))
                }
                val textColor = if (ColorUtils.calculateLuminance(s.color) > 0.5) Color.BLACK else Color.WHITE
                chips.add(Chip(text, s.color, textColor))
            }
        }

        val padH = 12f * density
        val padV = 6f * density
        val gap = 6f * density
        val chipH = chipTextPaint.textSize + 2 * padV
        val total = chips.size * chipH + (chips.size - 1) * gap
        var top = (chartBottom - 8f * density - total).coerceAtLeast(chartTop)
        val rect = RectF()
        for (chip in chips) {
            val chipW = chipTextPaint.measureText(chip.text) + 2 * padH
            val left = (cursorX - chipW / 2).coerceIn(chartLeft, (chartRight - chipW).coerceAtLeast(chartLeft))
            rect.set(left, top, left + chipW, top + chipH)
            chipPaint.color = chip.background
            canvas.drawRoundRect(rect, chipH / 2, chipH / 2, chipPaint)
            chipTextPaint.color = chip.textColor
            canvas.drawText(chip.text, rect.centerX(), rect.centerY() - (chipTextPaint.descent() + chipTextPaint.ascent()) / 2, chipTextPaint)
            top += chipH + gap
        }
    }
}
