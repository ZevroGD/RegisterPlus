package personal.digiregnotify

import android.content.Context

object SubjectRegistry {

    private const val PREFS = "digireg_subject_registry"
    private const val KEY = "known_codes"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Call whenever a screen loads real data, with whatever codes it found. Cheap no-op
     *  if nothing new showed up, so it's safe to call on every refresh. */
    fun recordCodes(context: Context, codes: Collection<String>) {
        val clean = codes.filter { it.isNotBlank() }.toSet()
        if (clean.isEmpty()) return
        val existing = prefs(context).getStringSet(KEY, emptySet()) ?: emptySet()
        if (existing.containsAll(clean)) return // nothing new, skip the write
        prefs(context).edit().putStringSet(KEY, existing + clean).apply()
    }

    fun getAllCodes(context: Context): List<String> =
        (prefs(context).getStringSet(KEY, emptySet()) ?: emptySet()).sorted()
}
