package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.slider.Slider
import java.text.SimpleDateFormat
import java.util.Locale

data class SubjectOverviewRow(
    val summary: SubjectSummary,
    val displayName: String,
    val color: Int,
    val averageText: String,
    val observations: List<Observation> = emptyList()
)

/**
 * One row per subject; tapping a subject that has grades slides open its exact marks.
 *
 * With an [editor] it is the edit screen's list: the same rows, but every subject opens (even
 * without marks), "Add mark" sits at the top of the opened subject, and each mark can be opened
 * to change its mark or weight, or to remove it. [onAddMark] asks for the new mark's details;
 * [onEdited] is called after every change so the screen can update its chart and average.
 */
class SubjectOverviewAdapter(
    private var rows: List<SubjectOverviewRow>,
    private val editor: MarksEditor? = null,
    private val onAddMark: (SubjectSummary) -> Unit = {},
    private val onEdited: () -> Unit = {}
) : RecyclerView.Adapter<SubjectOverviewAdapter.ViewHolder>() {

    private val expandedIds = mutableSetOf<Int>()
    private val expandedGradeIds = mutableSetOf<Int>() // opened marks on the edit screen
    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val shortDate = SimpleDateFormat("dd.MM.yy", Locale.getDefault())

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val header: View = view.findViewById(R.id.overviewRowHeader)
        val dot: View = view.findViewById(R.id.overviewRowColorDot)
        val name: TextView = view.findViewById(R.id.overviewRowName)
        val detail: TextView = view.findViewById(R.id.overviewRowDetail)
        val average: TextView = view.findViewById(R.id.overviewRowAverage)
        val chevron: TextView = view.findViewById(R.id.overviewRowChevron)
        val expanded: View = view.findViewById(R.id.overviewRowExpanded)
        val chart: GradeChartView = view.findViewById(R.id.overviewRowChart)
        val grades: LinearLayout = view.findViewById(R.id.overviewRowGrades)
        val add: View = view.findViewById(R.id.overviewRowAdd)
    }

    fun updateRows(newRows: List<SubjectOverviewRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    /** Re-draws one subject (after a mark was added or removed). */
    fun notifySubject(subjectId: Int) {
        val i = rows.indexOfFirst { it.summary.subjectId == subjectId }
        if (i >= 0) notifyItemChanged(i)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_overview_row, parent, false)
        return ViewHolder(view)
    }

    private fun prettyDate(iso: String): String = try {
        isoDate.parse(iso)?.let { shortDate.format(it) } ?: iso
    } catch (e: Exception) {
        iso
    }

    private fun gradeCount(summary: SubjectSummary): Int =
        editor?.grades(summary.subjectId)?.size ?: summary.grades.size

    /** The average and the line under the subject's name. */
    private fun bindTexts(holder: ViewHolder, row: SubjectOverviewRow) {
        val summary = row.summary
        val count = gradeCount(summary)
        holder.average.text = if (editor != null) {
            editor.average(summary)?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "–"
        } else {
            row.averageText
        }
        val observationCount = row.observations.size
        val unmarkedCount = summary.unmarked.size
        val parts = mutableListOf(
            when (count) {
                0 -> "No grades yet"
                1 -> "1 grade"
                else -> "$count grades"
            }
        )
        if (observationCount > 0) parts.add(if (observationCount == 1) "1 observation" else "$observationCount observations")
        if (unmarkedCount > 0) parts.add("$unmarkedCount without a mark")
        if (editor != null && editor.isModified(summary)) parts.add("edited")
        // "No grades yet" is only said when there is nothing else to say.
        holder.detail.text = (if (count == 0 && parts.size > 1) parts.drop(1) else parts).joinToString(" · ")
        holder.average.alpha = if (count == 0) 0.4f else 1f
    }

    private fun bindChart(holder: ViewHolder, summary: SubjectSummary) {
        val values = if (editor != null) editor.chronological(summary.subjectId).map { it.value }
        else summary.grades.map { it.value }
        if (values.size >= 2) {
            holder.chart.visibility = View.VISIBLE
            holder.chart.showAxis = true // grade lines, and each mark's value by its dot
            holder.chart.setValues(values)
        } else {
            holder.chart.visibility = View.GONE
        }
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        val summary = row.summary
        val count = gradeCount(summary)
        val id = summary.subjectId

        holder.name.text = row.displayName
        val observationCount = row.observations.size
        val unmarkedCount = summary.unmarked.size
        bindTexts(holder, row)
        (holder.dot.background.mutate() as GradientDrawable).setColor(row.color)

        // On the edit screen every subject opens, so a mark can be added to an empty one.
        val expandable = editor != null || count > 0 || observationCount > 0 || unmarkedCount > 0
        holder.chevron.visibility = if (expandable) View.VISIBLE else View.INVISIBLE
        if (!expandable) expandedIds.remove(id)
        val isOpen = id in expandedIds

        holder.add.visibility = if (editor != null) View.VISIBLE else View.GONE
        holder.add.setOnClickListener { onAddMark(summary) }

        // The marks themselves, newest first.
        holder.grades.removeAllViews()
        val inflater = LayoutInflater.from(holder.itemView.context)
        if (editor != null) {
            for (g in editor.grades(id)) addEditableLine(holder, row, g, inflater)
        } else {
            for (g in summary.grades.asReversed()) {
                val line = inflater.inflate(R.layout.item_grade_line, holder.grades, false)
                val title = listOf(g.type, g.description).filter { it.isNotBlank() }.joinToString(" · ")
                line.findViewById<TextView>(R.id.gradeLineTitle).text = title.ifBlank { "Grade" }
                line.findViewById<TextView>(R.id.gradeLineSub).text = "${prettyDate(g.date)} · ${g.weight}%"
                line.findViewById<TextView>(R.id.gradeLineValue).text = formatValue(g.value)
                holder.grades.addView(line)
            }
        }
        // Entries without a mark, newest first, with a dash where the mark would be.
        for (e in summary.unmarked.asReversed()) {
            val line = inflater.inflate(R.layout.item_grade_line, holder.grades, false)
            val title = listOf(e.type, e.description).filter { it.isNotBlank() }.joinToString(" · ")
            line.findViewById<TextView>(R.id.gradeLineTitle).text = title.ifBlank { "Entry without a mark" }
            line.findViewById<TextView>(R.id.gradeLineSub).text = prettyDate(e.date)
            line.findViewById<TextView>(R.id.gradeLineValue).text = "–"
            holder.grades.addView(line)
        }
        // Teacher observations come after the marks, marked with "!".
        for (o in row.observations.asReversed()) {
            val line = inflater.inflate(R.layout.item_grade_line, holder.grades, false)
            line.findViewById<TextView>(R.id.gradeLineTitle).text = o.text.ifBlank { "Observation" }
            line.findViewById<TextView>(R.id.gradeLineSub).text =
                listOf(prettyDate(o.date), o.created).filter { it.isNotBlank() }.joinToString(" · ")
            line.findViewById<TextView>(R.id.gradeLineValue).text = "!"
            holder.grades.addView(line)
        }
        bindChart(holder, summary)

        // Restore state without animating (rows get re-bound while scrolling).
        holder.expanded.visibility = if (isOpen) View.VISIBLE else View.GONE
        holder.expanded.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        holder.expanded.alpha = 1f
        Expand.rotateChevron(holder.chevron, isOpen, animate = false)

        holder.header.setOnClickListener {
            if (!expandable) return@setOnClickListener
            if (id in expandedIds) {
                expandedIds.remove(id)
                Expand.collapse(holder.expanded)
                Expand.rotateChevron(holder.chevron, false)
            } else {
                expandedIds.add(id)
                Expand.expand(holder.expanded)
                Expand.rotateChevron(holder.chevron, true)
            }
        }
    }

    /** One mark on the edit screen: tap to open it, then change its mark or weight, or remove it. */
    private fun addEditableLine(holder: ViewHolder, row: SubjectOverviewRow, g: EditableGrade, inflater: LayoutInflater) {
        val ed = editor ?: return
        val subjectId = row.summary.subjectId
        val line = inflater.inflate(R.layout.item_edit_grade, holder.grades, false)
        val header = line.findViewById<View>(R.id.editGradeHeader)
        val title = line.findViewById<TextView>(R.id.editGradeTitle)
        val sub = line.findViewById<TextView>(R.id.editGradeSub)
        val value = line.findViewById<TextView>(R.id.editGradeValue)
        val chevron = line.findViewById<TextView>(R.id.editGradeChevron)
        val panel = line.findViewById<View>(R.id.editGradePanel)
        val markLabel = line.findViewById<TextView>(R.id.editGradeMarkLabel)
        val slider = line.findViewById<Slider>(R.id.editGradeSlider)
        val weightEdit = line.findViewById<EditText>(R.id.editGradeWeight)

        fun refreshLine() {
            title.text = g.title
            sub.text = buildString {
                append(prettyDate(g.isoDate))
                append(" · ${g.weight}%")
                if (g.added) append(" · added") else if (g.changed) append(" · edited")
            }
            value.text = GradeFormat.format(g.value)
            markLabel.text = "Mark: ${GradeFormat.format(g.value)}"
        }
        fun changed() {
            refreshLine()
            bindTexts(holder, row)
            bindChart(holder, row.summary)
            onEdited()
        }
        refreshLine()

        // The slider only takes quarter steps inside the scale, so what it shows is rounded and
        // clamped; the mark itself only changes when the slider is moved.
        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        slider.value = (Math.round(g.value * 4) / 4f)
            .coerceIn(GradeCalc.MIN_MARK.toFloat(), GradeCalc.MAX_MARK.toFloat())
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        slider.addOnChangeListener { _, v, fromUser ->
            if (!fromUser) return@addOnChangeListener
            g.value = v
            changed()
        }

        weightEdit.setText(g.weight.toString())
        weightEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                // An empty or unreadable box keeps the last good weight.
                val w = s?.toString()?.trim()?.toIntOrNull() ?: return
                g.weight = w
                changed()
            }
        })

        line.findViewById<View>(R.id.editGradeRemove).setOnClickListener {
            ed.remove(subjectId, g)
            expandedGradeIds.remove(g.id)
            notifySubject(subjectId)
            onEdited()
        }

        val open = g.id in expandedGradeIds
        panel.visibility = if (open) View.VISIBLE else View.GONE
        panel.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        panel.alpha = 1f
        Expand.rotateChevron(chevron, open, animate = false)
        header.setOnClickListener {
            if (g.id in expandedGradeIds) {
                expandedGradeIds.remove(g.id)
                Expand.collapse(panel)
                Expand.rotateChevron(chevron, false)
            } else {
                expandedGradeIds.add(g.id)
                Expand.expand(panel)
                Expand.rotateChevron(chevron, true)
            }
        }
        holder.grades.addView(line)
    }

    /** 6.5 -> "6/7", 8.25 -> "8+", 9.75 -> "10-", 8.0 -> "8". */
    private fun formatValue(v: Float): String = GradeFormat.format(v)

    override fun getItemCount(): Int = rows.size
}
