package personal.digiregnotify

import android.app.Activity
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText

/** A free single-colour picker: a colour wheel (hue ring with a brightness/saturation triangle)
 *  or a hex code, with a live preview. Used for subject colours, which are just stored numbers,
 *  so any colour works (the app theme can't do that, see CustomThemeDialog). */
object ColorPickerDialog {

    fun show(activity: Activity, title: String, initial: Int, onPicked: (Int) -> Unit) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_color_picker, null)
        val preview = view.findViewById<View>(R.id.customPreviewPrimary)
        val wheel = view.findViewById<ColorWheelView>(R.id.customWheel)
        val hex = view.findViewById<EditText>(R.id.customHex)

        var color = initial or 0xFF000000.toInt()
        var updating = false

        fun showHex() { hex.setText(String.format("#%06X", color and 0xFFFFFF)) }

        wheel.onColorChanged = { picked ->
            color = picked
            updating = true
            showHex()
            updating = false
            preview.setBackgroundColor(color)
        }

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val text = s.toString().trimStart('#')
                if (text.length != 6) return // wait until a full code is typed
                color = try {
                    Color.parseColor("#$text")
                } catch (e: Exception) {
                    return
                }
                wheel.setColor(color)
                preview.setBackgroundColor(color)
            }
        })

        updating = true
        wheel.setColor(color)
        showHex()
        updating = false
        preview.setBackgroundColor(color)

        SlideDialogBuilder(activity)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Save") { _, _ -> onPicked(color) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
