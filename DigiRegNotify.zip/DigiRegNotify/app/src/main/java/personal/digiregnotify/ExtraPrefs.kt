package personal.digiregnotify

import android.content.Context
import java.util.Calendar
import java.util.Locale

/**
 * The optional extras, each switched on or off in Settings → Extras:
 * an evening reminder, quiet hours for the background checks, colouring homework by the time
 * left, the back-to-top button on lists, and a fun mode (jelly menus). Times are minutes since midnight.
 */
object ExtraPrefs {

    private const val PREFS = "digireg_extras"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // --- Evening reminder: what is due tomorrow (and any exam), at a time you choose ---
    fun isReminderEnabled(context: Context) = prefs(context).getBoolean("reminder_on", false)
    fun setReminderEnabled(context: Context, on: Boolean) = prefs(context).edit().putBoolean("reminder_on", on).apply()
    fun reminderMinutes(context: Context) = prefs(context).getInt("reminder_minutes", 18 * 60)
    fun setReminderMinutes(context: Context, minutes: Int) = prefs(context).edit().putInt("reminder_minutes", minutes).apply()

    // --- Quiet hours: no background checks between these two times ---
    fun isQuietEnabled(context: Context) = prefs(context).getBoolean("quiet_on", false)
    fun setQuietEnabled(context: Context, on: Boolean) = prefs(context).edit().putBoolean("quiet_on", on).apply()
    fun quietStart(context: Context) = prefs(context).getInt("quiet_start", 22 * 60)
    fun setQuietStart(context: Context, minutes: Int) = prefs(context).edit().putInt("quiet_start", minutes).apply()
    fun quietEnd(context: Context) = prefs(context).getInt("quiet_end", 6 * 60)
    fun setQuietEnd(context: Context, minutes: Int) = prefs(context).edit().putInt("quiet_end", minutes).apply()

    // --- Looks ---
    fun isUrgencyColors(context: Context) = prefs(context).getBoolean("urgency_colors", false)
    fun setUrgencyColors(context: Context, on: Boolean) = prefs(context).edit().putBoolean("urgency_colors", on).apply()
    fun isFunMode(context: Context) = prefs(context).getBoolean("fun_mode", false)
    fun setFunMode(context: Context, on: Boolean) = prefs(context).edit().putBoolean("fun_mode", on).apply()
    fun isBackToTop(context: Context) = prefs(context).getBoolean("back_to_top", true)
    fun setBackToTop(context: Context, on: Boolean) = prefs(context).edit().putBoolean("back_to_top", on).apply()

    /** "18:05" */
    fun timeLabel(minutes: Int): String = String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60)

    private fun minuteOfDay(millis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    /** True if quiet hours are on and [millis] falls inside them (the window may cross midnight). */
    fun isQuiet(context: Context, millis: Long): Boolean {
        if (!isQuietEnabled(context)) return false
        val start = quietStart(context)
        val end = quietEnd(context)
        if (start == end) return false
        val now = minuteOfDay(millis)
        return if (start < end) now in start until end else now >= start || now < end
    }

    /** The first moment at or after [fromMillis] when the quiet hours end. */
    fun nextQuietEnd(context: Context, fromMillis: Long): Long {
        val end = quietEnd(context)
        val cal = Calendar.getInstance().apply {
            timeInMillis = fromMillis
            set(Calendar.HOUR_OF_DAY, end / 60)
            set(Calendar.MINUTE, end % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= fromMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
}
