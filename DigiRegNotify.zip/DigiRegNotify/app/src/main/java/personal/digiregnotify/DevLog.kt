package personal.digiregnotify

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Small persistent log for the Developer menu. Lives in the app's private storage, is trimmed
 * automatically, and never contains passwords, cookies or response bodies — only what
 * happened (requests with their status, alarms, checks, notifications, errors).
 */
object DevLog {

    private const val FILE = "devlog.txt"
    private const val MAX_BYTES = 200_000

    @Volatile
    private var appContext: Context? = null
    private val lock = Any()
    private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    private const val PREFS = "digireg_devlog"
    private const val KEY_ENABLED = "record_enabled"

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** On by default (the log is capped at ~200 KB); can be switched off in the Developer menu. */
    fun isRecording(context: Context): Boolean =
        prefs(context.applicationContext).getBoolean(KEY_ENABLED, true)

    fun setRecording(context: Context, on: Boolean) {
        prefs(context.applicationContext).edit().putBoolean(KEY_ENABLED, on).apply()
    }

    fun d(tag: String, msg: String) = write('D', tag, msg, null)
    fun i(tag: String, msg: String) = write('I', tag, msg, null)
    fun w(tag: String, msg: String, t: Throwable? = null) = write('W', tag, msg, t)
    fun e(tag: String, msg: String, t: Throwable? = null) = write('E', tag, msg, t)

    private fun write(level: Char, tag: String, msg: String, t: Throwable?) {
        when (level) {
            'D' -> Log.d("DigiReg/$tag", msg)
            'I' -> Log.i("DigiReg/$tag", msg)
            'W' -> Log.w("DigiReg/$tag", msg, t)
            else -> Log.e("DigiReg/$tag", msg, t)
        }
        val ctx = appContext ?: return
        if (!isRecording(ctx)) return // switched off: logcat only, nothing stored
        try {
            synchronized(lock) {
                val file = File(ctx.filesDir, FILE)
                val sb = StringBuilder()
                sb.append(timeFormat.format(Date())).append(' ').append(level).append('/').append(tag)
                    .append(": ").append(msg).append('\n')
                if (t != null) {
                    sb.append("    ").append(t.javaClass.simpleName).append(": ").append(t.message).append('\n')
                    t.stackTrace.take(5).forEach { sb.append("      at ").append(it).append('\n') }
                }
                file.appendText(sb.toString())
                if (file.length() > MAX_BYTES) trim(file)
            }
        } catch (e: Exception) {
            // Logging must never be the thing that breaks the app.
        }
    }

    /** Keeps the newest half, starting at a line boundary. */
    private fun trim(file: File) {
        val text = file.readText()
        val cut = text.indexOf('\n', text.length / 2)
        file.writeText(if (cut >= 0) text.substring(cut + 1) else "")
    }

    private fun levelRank(c: Char) = when (c) { 'D' -> 0; 'I' -> 1; 'W' -> 2; else -> 3 }

    /**
     * The newest [maxLines] entries (continuation lines stay with their entry), filtered by
     * minimum level (D, I, W or E) and a case-insensitive text filter.
     */
    fun read(context: Context, minLevel: Char = 'D', filter: String = "", maxLines: Int = 300): String {
        val file = File(context.applicationContext.filesDir, FILE)
        if (!file.exists()) return ""
        val entries = mutableListOf<StringBuilder>()
        for (line in synchronized(lock) { file.readLines() }) {
            if (line.startsWith("    ") || line.startsWith("      ")) {
                entries.lastOrNull()?.append('\n')?.append(line)
            } else {
                entries.add(StringBuilder(line))
            }
        }
        val min = levelRank(minLevel)
        val f = filter.trim()
        return entries.map { it.toString() }
            .filter { e ->
                val level = e.getOrNull(24) ?: 'D' // "yyyy-MM-dd HH:mm:ss.SSS " is 24 chars
                levelRank(level) >= min && (f.isEmpty() || e.contains(f, ignoreCase = true))
            }
            .takeLast(maxLines)
            .joinToString("\n")
    }

    fun sizeBytes(context: Context): Long =
        File(context.applicationContext.filesDir, FILE).let { if (it.exists()) it.length() else 0L }

    fun clear(context: Context) {
        synchronized(lock) { File(context.applicationContext.filesDir, FILE).delete() }
    }
}
