package personal.digiregnotify

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Full-screen grade chart: drag a finger along it to move a cursor from day to day and see
 * that day's marks. The legend lists every subject and lets you show or hide each one.
 */
class MarksChartActivity : BaseActivity() {

    private lateinit var chart: MultiLineChartView
    private var subjects: List<SubjectSummary> = emptyList()
    private val hidden = mutableSetOf<Int>() // subjectIds switched off in the legend

    companion object {
        const val TRANSITION_NAME = "chart_container"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        window.requestFeature(android.view.Window.FEATURE_ACTIVITY_TRANSITIONS)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks_chart)
        setUpMorph()

        subjects = MarksChartData.subjects
        // Start with what the Marks screen shows: subjects set to thickness 0 there stay hidden.
        subjects.forEach { if ((MarksChartData.thickness[it.subjectId] ?: 3) == 0) hidden.add(it.subjectId) }

        chart = findViewById(R.id.fullChart)
        chart.interactive = true
        chart.showMonthLabels = true

        findViewById<ImageButton>(R.id.chartBackButton).setOnClickListener { finishAfterTransition() }
        findViewById<View>(R.id.legendBar).setOnClickListener { showLegend() }

        if (subjects.isEmpty()) {
            findViewById<TextView>(R.id.chartHint).apply {
                text = "No marks yet."
                visibility = View.VISIBLE
            }
        }
        renderChart()
    }

    /** The whole screen is the other end of the card's morph. */
    private fun setUpMorph() {
        val content = findViewById<View>(android.R.id.content)
        content.transitionName = TRANSITION_NAME
        val background = com.google.android.material.color.MaterialColors.getColor(
            content, android.R.attr.colorBackground, android.graphics.Color.BLACK
        )
        setEnterSharedElementCallback(
            com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback()
        )
        window.sharedElementsUseOverlay = false
        fun morph(ms: Long) = com.google.android.material.transition.platform.MaterialContainerTransform().apply {
            addTarget(android.R.id.content)
            setAllContainerColors(background)
            scrimColor = android.graphics.Color.TRANSPARENT
            duration = ms
        }
        window.sharedElementEnterTransition = morph(350)
        window.sharedElementReturnTransition = morph(280)
    }

    private fun renderChart() {
        chart.setSeries(
            buildChartSeries(this, subjects) { s ->
                if (s.subjectId in hidden) 0f else (MarksChartData.thickness[s.subjectId] ?: 3).coerceAtLeast(1).toFloat()
            }
        )
    }

    /** One tappable row per subject: colour dot, name, and a tick while it is shown. */
    private fun showLegend() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val onSurface = com.google.android.material.color.MaterialColors.getColor(
            findViewById<View>(android.R.id.content),
            com.google.android.material.R.attr.colorOnSurface,
            android.graphics.Color.GRAY
        )

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
        }
        for (s in subjects) {
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(14) }
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(SubjectColors.colorForCode(this@MarksChartActivity, s.name))
                }
            }
            val name = TextView(this).apply {
                text = SubjectNames.nameFor(this@MarksChartActivity, s.name)
                textSize = 15f
                setTextColor(onSurface)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tick = TextView(this).apply {
                textSize = 16f
                setTextColor(onSurface)
                gravity = Gravity.CENTER
            }
            fun refresh() {
                val shown = s.subjectId !in hidden
                tick.text = if (shown) "✓" else ""
                name.alpha = if (shown) 1f else 0.4f
                dot.alpha = if (shown) 1f else 0.4f
            }
            refresh()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(12), 0, dp(12))
                background = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground)).let { a ->
                    a.getDrawable(0).also { a.recycle() }
                }
                isClickable = true
                isFocusable = true
                addView(dot)
                addView(name)
                addView(tick, LinearLayout.LayoutParams(dp(24), LinearLayout.LayoutParams.WRAP_CONTENT))
                setOnClickListener {
                    if (s.subjectId in hidden) hidden.remove(s.subjectId) else hidden.add(s.subjectId)
                    refresh()
                    renderChart()
                }
            }
            column.addView(row)
        }

        SlideDialogBuilder(this)
            .setTitle("Legend")
            .setView(ScrollView(this).apply { addView(column) })
            .setPositiveButton("Done", null)
            .show()
    }
}
