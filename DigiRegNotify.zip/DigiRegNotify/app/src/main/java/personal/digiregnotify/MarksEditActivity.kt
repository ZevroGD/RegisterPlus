package personal.digiregnotify

import android.content.DialogInterface
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ScrollView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.slider.Slider
import java.util.Locale

/**
 * The Marks screen with its marks editable: same average and subject list, but every subject
 * has an "Add mark" button at the top and each mark can be changed or removed. It works
 * on a copy; nothing is sent to the school or saved, and leaving the screen drops the changes.
 */
class MarksEditActivity : BaseActivity() {

    private lateinit var source: List<SubjectSummary>
    private lateinit var editor: MarksEditor
    private lateinit var adapter: SubjectOverviewAdapter
    private lateinit var averageCard: View
    private lateinit var overallAverage: TextView
    private lateinit var overallDiff: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val subjects = MarksEditData.subjects
        if (subjects.isEmpty()) { // e.g. the app was restarted while this screen was open
            finish()
            return
        }
        source = subjects
        editor = MarksEditor(source)
        setContentView(R.layout.activity_marks_edit)

        findViewById<ImageButton>(R.id.editBackButton).setOnClickListener { finish() }
        averageCard = findViewById(R.id.editAverageCard)
        overallAverage = findViewById(R.id.editOverallAverage)
        overallDiff = findViewById(R.id.editOverallDiff)
        findViewById<TextView>(R.id.editSubjectsTitle).text = "All subjects · ${source.size}"

        adapter = SubjectOverviewAdapter(
            emptyList(), editor,
            onAddMark = { summary -> showAddDialog(summary) },
            onEdited = { refreshSummary() }
        )
        val recycler = findViewById<RecyclerView>(R.id.editSubjectsRecycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter
        adapter.updateRows(source.map { s ->
            SubjectOverviewRow(
                summary = s,
                displayName = SubjectNames.nameFor(this, s.name),
                color = SubjectColors.colorForCode(this, s.name),
                averageText = "",
                observations = MarksEditData.observations[s.subjectId].orEmpty()
            )
        })

        refreshSummary()
    }

    /** The overall average, after any change. */
    private fun refreshSummary() {
        val editedAverages = source.mapNotNull { editor.average(it) }
        val realAverages = source.mapNotNull { it.averageYear ?: it.averageSemester }
        if (editedAverages.isEmpty() && realAverages.isEmpty()) {
            averageCard.visibility = View.GONE
        } else {
            averageCard.visibility = View.VISIBLE
            val now = if (editedAverages.isEmpty()) null else editedAverages.sum() / editedAverages.size
            val real = if (realAverages.isEmpty()) null else realAverages.sum() / realAverages.size
            overallAverage.text = if (now == null) "–" else num(now)
            if (now != null && real != null && Math.abs(now - real) >= 0.005f) {
                val d = now - real
                overallDiff.text = (if (d > 0) "+" else "−") + num(Math.abs(d)) +
                    " from the real average (${num(real)})"
                overallDiff.setTextColor(if (d > 0) GREEN else RED)
                overallDiff.visibility = View.VISIBLE
            } else {
                overallDiff.visibility = View.GONE
            }
        }

    }

    private fun num(v: Float): String = String.format(Locale.getDefault(), "%.2f", v)

    /** Asks for everything about the new mark first; it is only added on "Add". */
    private fun showAddDialog(summary: SubjectSummary) {
        val view = layoutInflater.inflate(R.layout.dialog_add_mark, null)
        val markLabel = view.findViewById<TextView>(R.id.addMarkLabel)
        val slider = view.findViewById<Slider>(R.id.addMarkSlider)
        val weightEdit = view.findViewById<EditText>(R.id.addMarkWeight)

        val currentAvg = editor.average(summary)
        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        slider.value = if (currentAvg == null) 8f
        else (Math.round(currentAvg * 4) / 4f)
            .coerceIn(GradeCalc.MIN_MARK.toFloat(), GradeCalc.MAX_MARK.toFloat())
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        fun showMark() { markLabel.text = "Mark: ${GradeFormat.format(slider.value)}" }
        slider.addOnChangeListener { _, _, _ -> showMark() }
        showMark()


        val dialog = SlideDialogBuilder(this)
            .setTitle("Add a mark")
            .setView(ScrollView(this).apply { addView(view) })
            .setPositiveButton("Add", null) // set below, so a bad weight keeps the dialog open
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val weight = weightEdit.text?.toString()?.trim()?.toIntOrNull()
                if (weight == null || weight < 1 || weight > 999) {
                    weightEdit.error = "Enter a number from 1 to 999"
                    return@setOnClickListener
                }
                editor.add(summary.subjectId, slider.value, weight)
                dialog.dismiss()
                adapter.notifySubject(summary.subjectId)
                refreshSummary()
            }
        }
        dialog.show()
    }

    companion object {
        private val GREEN = Color.parseColor("#43A047")
        private val RED = Color.parseColor("#EF5350")
    }
}
