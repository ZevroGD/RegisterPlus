package personal.digiregnotify

/** Hands the subject from the grade calculator over to the what-if editor screen. */
object GradeSimData {
    var summary: SubjectSummary? = null
    var displayName: String = ""
}
