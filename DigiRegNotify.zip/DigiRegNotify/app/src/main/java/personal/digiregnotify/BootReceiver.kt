package personal.digiregnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // MY_PACKAGE_REPLACED: installing a new build cancels all of the app's alarms.
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val api = RegisterApi(context)
            if (api.hasCredentials() && AlarmScheduler.isPollingEnabled(context)) {
                DevLog.i("Alarm", "rescheduling after ${intent.action}")
                AlarmScheduler.scheduleRepeating(context)
            }
            if (api.hasCredentials()) ReminderScheduler.schedule(context) // the optional evening reminder (does nothing when it's off)
        }
    }
}
