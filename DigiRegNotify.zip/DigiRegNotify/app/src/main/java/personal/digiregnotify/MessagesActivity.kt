package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MessagesActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: MessageAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var recyclerView: RecyclerView

    private var autoOpenHandled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.messagesEmptyText)
        swipeRefresh = findViewById(R.id.messagesSwipeRefresh)
        recyclerView = findViewById(R.id.messagesRecyclerView)

        adapter = MessageAdapter(emptyList()) { message -> messageOpened(message) }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        ScrollToTop.attach(this, recyclerView, findViewById(R.id.scrollToTopButton))

        findViewById<ImageButton>(R.id.messagesBackButton).setOnClickListener { finish() }
        swipeRefresh.setOnRefreshListener { loadMessages() }
        loadMessages()
    }

    /** A message was opened (it slides open in the list): mark it read on the server if it was unread. */
    private fun messageOpened(message: MessageSummary) {
        CoroutineScope(Dispatchers.IO).launch {
            val ok = api.markMessageAsRead(message.id)
            if (ok) withContext(Dispatchers.Main) { adapter.markRead(message.id) }
        }
    }

    private fun loadMessages() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            if (!showSaved("No internet")) {
                emptyText.text = "No internet connection right now"
                emptyText.visibility = TextView.VISIBLE
            }
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val json = api.fetchMessages() // read-only: never calls markAsRead
            if (json != null) OfflineCache.save(this@MessagesActivity, "messages", json)
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (isFinishing || isDestroyed) return@withContext
                if (json == null) {
                    if (!showSaved(ErrorText.reason(api.lastError))) {
                        emptyText.text = ErrorText.friendly(api.lastError, "load messages")
                        emptyText.visibility = TextView.VISIBLE
                        Toast.makeText(this@MessagesActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    }
                    return@withContext
                }
                showMessages(json, null)
            }
        }
    }

    /** Shows the last messages the school sent, greyed out, if there are any. */
    private fun showSaved(reason: String): Boolean {
        val saved = OfflineCache.load(this, "messages") ?: return false
        return showMessages(saved.json, OfflineCache.note(saved.savedAt, reason))
    }

    /** [storedNote] is set for a stored copy: greyed out, with a line saying when it was saved. */
    private fun showMessages(json: String, storedNote: String?): Boolean {
        val messages = try {
            MessageParser.parse(json)
        } catch (e: Exception) {
            if (storedNote == null) {
                emptyText.text = "Could not read the messages data"
                emptyText.visibility = TextView.VISIBLE
            }
            return false
        }

        val banner = findViewById<TextView>(R.id.messagesStatusBanner)
        banner.text = storedNote
        banner.visibility = if (storedNote != null) TextView.VISIBLE else TextView.GONE
        swipeRefresh.animate().alpha(if (storedNote != null) 0.55f else 1f).setDuration(200).start()

        adapter.updateMessages(messages)
        emptyText.visibility = if (messages.isEmpty()) TextView.VISIBLE else TextView.GONE
        emptyText.text = "No messages"

        scrollToRequestedMessage(messages)
        return true
    }

    /** If opened from a "new message" notification, jump straight to reading it. */
    private fun scrollToRequestedMessage(messages: List<MessageSummary>) {
        val targetId = intent.getLongExtra(EXTRA_MESSAGE_ID, -1L)
        if (targetId <= 0) return
        val target = messages.firstOrNull { it.id == targetId } ?: return
        val position = messages.indexOf(target)
        if (position >= 0) recyclerView.scrollToPosition(position)
        if (!autoOpenHandled) {
            autoOpenHandled = true
            adapter.openMessage(target.id) // slides it open
            if (target.isUnread) messageOpened(target)
        }
    }

    companion object {
        const val EXTRA_MESSAGE_ID = "message_id"
    }
}
