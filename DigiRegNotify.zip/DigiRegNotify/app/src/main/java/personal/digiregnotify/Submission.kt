package personal.digiregnotify

import org.json.JSONArray
import org.json.JSONObject

/**
 * One "Anhang" of a homework item or message: a written description (type "text"), a link, or
 * a file. [parentId] is the gradeGroup / message it belongs to (needed for the download URL).
 */
data class Submission(
    val id: Long,
    val type: String,        // "text", "link" or "file"
    val title: String,
    val link: String,
    val originalName: String,
    val text: String,        // plain text; for type "text"
    val parentId: Long
) {
    companion object {
        /** [parentKey] is "gradeGroupId" for homework, "messageId" for messages. */
        fun parseList(array: JSONArray?, parentKey: String): List<Submission> {
            if (array == null) return emptyList()
            val result = mutableListOf<Submission>()
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                if (o.optInt("deleted", 0) != 0) continue
                result.add(
                    Submission(
                        id = o.optLong("id"),
                        type = o.optString("type"),
                        title = o.optStringOrEmpty("title"),
                        link = o.optStringOrEmpty("link"),
                        originalName = o.optStringOrEmpty("originalName"),
                        text = plainText(o.optStringOrEmpty("text")),
                        parentId = o.optLong(parentKey)
                    )
                )
            }
            return result
        }

        private fun JSONObject.optStringOrEmpty(key: String): String =
            if (isNull(key)) "" else optString(key)

        /** The text is Quill "delta" JSON ({"ops":[{"insert":"..."}]}): keep just the words. */
        fun plainText(deltaJson: String): String {
            if (deltaJson.isBlank()) return ""
            return try {
                val ops = JSONObject(deltaJson).optJSONArray("ops") ?: return ""
                val sb = StringBuilder()
                for (i in 0 until ops.length()) {
                    val insert = ops.optJSONObject(i)?.opt("insert")
                    if (insert is String) sb.append(insert)
                }
                sb.toString().replace(Regex("\\n{3,}"), "\n\n").trim()
            } catch (e: Exception) {
                deltaJson.take(2000)
            }
        }
    }
}
