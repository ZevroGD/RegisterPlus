package personal.digiregnotify

import android.content.Context
import org.json.JSONObject

/** A teacher observation ("Beobachtung"), e.g. "Unterrichtsmaterialien fehlen". */
data class Observation(
    val id: Long,
    val subjectId: Int,
    val date: String,      // yyyy-MM-dd
    val typeName: String,  // what was observed
    val note: String,      // the teacher's extra comment, often empty
    val created: String    // "Von <teacher> am <date> eingetragen"
) {
    /** The main text: what was observed, plus the comment if there is one. */
    val text: String get() = if (note.isBlank()) typeName else "$typeName – $note"
}

object Observations {

    /** Reads the "observations" list of a subject_detail reply. */
    fun parse(json: String): List<Observation> {
        val array = JSONObject(json).optJSONArray("observations") ?: return emptyList()
        val result = mutableListOf<Observation>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            if (o.optInt("cancelled", 0) != 0 || o.optInt("hidden", 0) != 0) continue
            result.add(
                Observation(
                    id = o.optLong("id"),
                    subjectId = o.optInt("subjectId"),
                    date = o.optString("date"),
                    typeName = o.optString("typeName"),
                    note = o.optString("note").trim(),
                    created = o.optString("created")
                )
            )
        }
        return result
    }

    /** Logs the field names (never the values) of a subject_detail reply and of the first entry
     *  of each list in it, once per list name and run of the app. */
    private val loggedLists = mutableSetOf<String>()
    private fun logFields(json: String) {
        try {
            val root = JSONObject(json)
            if (loggedLists.add("*")) {
                DevLog.i("Marks", "Subject detail fields: " + root.keys().asSequence().joinToString(", "))
            }
            for (key in root.keys()) {
                val array = root.optJSONArray(key) ?: continue
                val first = array.optJSONObject(0) ?: continue
                if (loggedLists.add(key)) {
                    DevLog.i("Marks", "Subject detail $key[0] fields: " + first.keys().asSequence().joinToString(", "))
                }
            }
        } catch (e: Exception) {
            DevLog.w("Observations", "could not list the subject detail fields", e)
        }
    }

    /**
     * The observations of every subject that has some (the subject list only holds a count; the
     * details are on each subject's own page). Blocking: call it off the main thread.
     */
    fun load(context: Context, subjects: List<SubjectSummary>): List<Observation> {
        val api = RegisterApi(context)
        val all = mutableListOf<Observation>()
        for (subject in subjects.filter { it.countObservations > 0 }) {
            try {
                val json = api.fetchSubjectDetail(subject.subjectId) ?: continue
                logFields(json)
                all.addAll(parse(json))
            } catch (e: Exception) {
                DevLog.w("Observations", "subject ${subject.subjectId} failed", e)
            }
        }
        return all.sortedBy { it.date }
    }
}
