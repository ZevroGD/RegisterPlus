package personal.digiregnotify

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * What-if editor for one subject's marks. It works on a copy: marks can be tweaked (mark and
 * weight), removed or added, and the average updates at once. Nothing here is sent to the school
 * or saved; "Reset" goes back to the real marks and leaving the screen drops the changes.
 */
class GradeSimulatorActivity : BaseActivity() {

    private class SimGrade(
        val id: Int,
        var value: Float,
        var weight: Int,
        val semester: Int,
        val title: String,
        val date: String,
        val added: Boolean,
        val originalValue: Float?,
        val originalWeight: Int?
    ) {
        val changed: Boolean get() = !added && (value != originalValue || weight != originalWeight)
        fun toGrade() = SubjectGrade(value, date, title, weight, "", semester)
    }

    private lateinit var summary: SubjectSummary
    private val grades = mutableListOf<SimGrade>() // newest first
    private val expanded = mutableSetOf<Int>()
    private var nextId = 0

    private lateinit var avgText: TextView
    private lateinit var diffText: TextView
    private lateinit var semText: TextView
    private lateinit var emptyText: TextView
    private lateinit var listContainer: LinearLayout
    private lateinit var resetButton: View

    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val shortDate = SimpleDateFormat("dd.MM.yy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = GradeSimData.summary
        if (data == null) { // e.g. the app was restarted while this screen was open
            finish()
            return
        }
        summary = data
        setContentView(R.layout.activity_grade_sim)

        findViewById<TextView>(R.id.simTitle).text = GradeSimData.displayName
        findViewById<ImageButton>(R.id.simBackButton).setOnClickListener { finish() }
        avgText = findViewById(R.id.simAverage)
        diffText = findViewById(R.id.simDiff)
        semText = findViewById(R.id.simSemesters)
        emptyText = findViewById(R.id.simEmpty)
        listContainer = findViewById(R.id.simList)
        resetButton = findViewById(R.id.simReset)

        resetButton.setOnClickListener {
            SlideDialogBuilder(this)
                .setTitle("Reset?")
                .setMessage("This brings back the real marks and drops every change you made here.")
                .setPositiveButton("Reset") { _, _ ->
                    expanded.clear()
                    loadReal()
                    render()
                    updateTotals()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.simAdd).setOnClickListener { showAddDialog() }

        loadReal()
        render()
        updateTotals()
    }

    private fun loadReal() {
        grades.clear()
        for (g in summary.grades.asReversed()) {
            val title = listOf(g.type, g.description).filter { it.isNotBlank() }.joinToString(" · ")
            grades.add(
                SimGrade(
                    id = nextId++, value = g.value, weight = g.weight, semester = g.semester,
                    title = title.ifBlank { "Grade" }, date = prettyDate(g.date),
                    added = false, originalValue = g.value, originalWeight = g.weight
                )
            )
        }
    }

    private fun prettyDate(iso: String): String = try {
        isoDate.parse(iso)?.let { shortDate.format(it) } ?: iso
    } catch (e: Exception) {
        iso
    }

    private fun num(d: Double): String = String.format(Locale.getDefault(), "%.2f", d)

    private fun isModified(): Boolean =
        grades.size != summary.grades.size || grades.any { it.added || it.changed }

    /** The averages at the top, and whether "Reset" has anything to do. */
    private fun updateTotals() {
        val real = GradeCalc.totals(summary.grades).average
        val sim = GradeCalc.totals(grades.map { it.toGrade() }).average
        avgText.text = if (sim == null) "–" else num(sim)

        if (real != null && sim != null) {
            val d = sim - real
            when {
                Math.abs(d) < 0.005 -> {
                    diffText.text = "Same as your real average (${num(real)})"
                    diffText.setTextColor(onSurface())
                    diffText.alpha = 0.6f
                }
                else -> {
                    val sign = if (d > 0) "+" else "−"
                    diffText.text = "$sign${num(Math.abs(d))} from your real average (${num(real)})"
                    diffText.setTextColor(if (d > 0) GREEN else RED)
                    diffText.alpha = 1f
                }
            }
        } else {
            diffText.text = if (real == null) "No real marks yet" else ""
            diffText.setTextColor(onSurface())
            diffText.alpha = 0.6f
        }

        val parts = mutableListOf<String>()
        for (s in 1..2) {
            val inSem = grades.filter { it.semester == s }.map { it.toGrade() }
            val avg = GradeCalc.totals(inSem).average
            if (avg != null) parts.add("Sem. $s: ${num(avg)}")
        }
        semText.text = parts.joinToString(" · ")
        semText.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE

        resetButton.isEnabled = isModified()
        resetButton.alpha = if (resetButton.isEnabled) 1f else 0.4f
    }

    private fun onSurface(): Int =
        com.google.android.material.color.MaterialColors.getColor(
            avgText, com.google.android.material.R.attr.colorOnSurface
        )

    /** Rebuilds the list (after adding, removing or resetting; not while editing a mark). */
    private fun render() {
        listContainer.removeAllViews()
        emptyText.visibility = if (grades.isEmpty()) View.VISIBLE else View.GONE
        for (g in grades) listContainer.addView(buildRow(g))
    }

    private fun buildRow(g: SimGrade): View {
        val row = layoutInflater.inflate(R.layout.item_sim_grade, listContainer, false)
        val header = row.findViewById<View>(R.id.simHeader)
        val title = row.findViewById<TextView>(R.id.simRowTitle)
        val sub = row.findViewById<TextView>(R.id.simRowSub)
        val value = row.findViewById<TextView>(R.id.simRowValue)
        val chevron = row.findViewById<TextView>(R.id.simRowChevron)
        val panel = row.findViewById<View>(R.id.simExpanded)
        val markLabel = row.findViewById<TextView>(R.id.simMarkLabel)
        val slider = row.findViewById<Slider>(R.id.simSlider)
        val weightEdit = row.findViewById<EditText>(R.id.simWeight)

        fun refreshHeader() {
            title.text = g.title
            sub.text = buildString {
                append(g.date)
                append(" · ${g.weight}%")
                if (g.semester == 1 || g.semester == 2) append(" · Sem. ${g.semester}")
                if (g.added) append(" · added") else if (g.changed) append(" · edited")
            }
            value.text = GradeFormat.format(g.value)
            markLabel.text = "Mark: ${GradeFormat.format(g.value)}"
        }
        refreshHeader()

        // The slider only takes quarter steps inside the scale, so what it shows is rounded and
        // clamped; the mark itself only changes when the person moves the slider.
        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        slider.value = (Math.round(g.value * 4) / 4f)
            .coerceIn(GradeCalc.MIN_MARK.toFloat(), GradeCalc.MAX_MARK.toFloat())
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        slider.addOnChangeListener { _, v, fromUser ->
            if (!fromUser) return@addOnChangeListener
            g.value = v
            refreshHeader()
            updateTotals()
        }

        weightEdit.setText(g.weight.toString())
        weightEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                // An empty or unreadable box keeps the last good weight.
                val w = s?.toString()?.trim()?.toIntOrNull() ?: return
                g.weight = w
                refreshHeader()
                updateTotals()
            }
        })

        row.findViewById<View>(R.id.simRemove).setOnClickListener {
            grades.remove(g)
            expanded.remove(g.id)
            render()
            updateTotals()
        }

        // Restore state without animating (the list is rebuilt after add/remove).
        val isOpen = g.id in expanded
        panel.visibility = if (isOpen) View.VISIBLE else View.GONE
        panel.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        panel.alpha = 1f
        Expand.rotateChevron(chevron, isOpen, animate = false)

        header.setOnClickListener {
            if (g.id in expanded) {
                expanded.remove(g.id)
                Expand.collapse(panel)
                Expand.rotateChevron(chevron, false)
            } else {
                expanded.add(g.id)
                Expand.expand(panel)
                Expand.rotateChevron(chevron, true)
            }
        }
        return row
    }

    /** Asks for everything about the new mark first; it is only added on "Add". */
    private fun showAddDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_sim_add, null)
        val markLabel = view.findViewById<TextView>(R.id.simAddMarkLabel)
        val slider = view.findViewById<Slider>(R.id.simAddSlider)
        val weightEdit = view.findViewById<EditText>(R.id.simAddWeight)
        val semToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.simAddSemester)

        val currentAvg = GradeCalc.totals(grades.map { it.toGrade() }).average
        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        slider.value = if (currentAvg == null) 8f
        else (Math.round(currentAvg * 4) / 4f)
            .coerceIn(GradeCalc.MIN_MARK.toFloat(), GradeCalc.MAX_MARK.toFloat())
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        fun showMark() { markLabel.text = "Mark: ${GradeFormat.format(slider.value)}" }
        slider.addOnChangeListener { _, _, _ -> showMark() }
        showMark()

        val newestSemester = summary.grades.lastOrNull()?.semester?.takeIf { it == 1 || it == 2 } ?: 1
        semToggle.check(if (newestSemester == 2) R.id.simAddSem2 else R.id.simAddSem1)

        val dialog = SlideDialogBuilder(this)
            .setTitle("Add a mark")
            .setView(ScrollView(this).apply { addView(view) })
            .setPositiveButton("Add", null) // set below, so a bad weight keeps the dialog open
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val weight = weightEdit.text?.toString()?.trim()?.toIntOrNull()
                if (weight == null || weight < 1 || weight > 999) {
                    weightEdit.error = "Enter a number from 1 to 999"
                    return@setOnClickListener
                }
                val semester = if (semToggle.checkedButtonId == R.id.simAddSem2) 2 else 1
                grades.add(
                    0,
                    SimGrade(
                        id = nextId++, value = slider.value, weight = weight, semester = semester,
                        title = "Added mark", date = shortDate.format(Date()),
                        added = true, originalValue = null, originalWeight = null
                    )
                )
                dialog.dismiss()
                render()
                updateTotals()
            }
        }
        dialog.show()
    }

    companion object {
        private val GREEN = Color.parseColor("#43A047")
        private val RED = Color.parseColor("#EF5350")
    }
}
