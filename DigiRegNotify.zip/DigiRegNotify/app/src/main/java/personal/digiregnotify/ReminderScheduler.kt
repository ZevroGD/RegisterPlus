package personal.digiregnotify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * The optional evening reminder: once a day, at the time chosen in Settings → Extras, a
 * notification lists what is due tomorrow (any test or exam first). It works from the copy of
 * the dashboard that the last check saved, so it needs no connection and no extra request.
 */
object ReminderScheduler {

    private const val REQUEST_CODE = 200

    private fun pendingIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQUEST_CODE, Intent(context, ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Sets the alarm for the next time the reminder is due, or removes it when it is off. */
    fun schedule(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java)
        if (!ExtraPrefs.isReminderEnabled(context)) {
            am.cancel(pendingIntent(context))
            return
        }
        val minutes = ExtraPrefs.reminderMinutes(context)
        val due = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (due.timeInMillis <= System.currentTimeMillis() + 1000) due.add(Calendar.DAY_OF_YEAR, 1)

        val pi = pendingIntent(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due.timeInMillis, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due.timeInMillis, pi)
        }
        DevLog.i("Reminder", "next reminder at ${ExtraPrefs.timeLabel(minutes)} (${due.time})")
    }

    fun cancel(context: Context) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context))
    }

    /** Builds the reminder from the saved dashboard and posts it, if anything is due tomorrow. */
    fun post(context: Context) {
        val saved = DashboardCache.load(context) ?: run {
            DevLog.i("Reminder", "no saved dashboard yet")
            return
        }
        val items = DashboardDiffer(context).parseItems(saved.json).filter { it.type == "gradeGroup" }

        val tomorrowStart = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val dayAfterStart = (tomorrowStart.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val dueTomorrow = items.filter { item ->
            val due = DueDateFormat.parse(item.deadline)?.time ?: return@filter false
            due >= tomorrowStart.timeInMillis && due < dayAfterStart.timeInMillis
        }
        val exams = dueTomorrow.filter { ExamWords.matches(it.title) }
        val homework = dueTomorrow.filter { !ExamWords.matches(it.title) && !it.checked } // ticked = done
        if (exams.isEmpty() && homework.isEmpty()) {
            DevLog.i("Reminder", "nothing due tomorrow")
            return
        }

        fun line(item: DashboardItem): String {
            val subject = SubjectNames.nameFor(context, item.label.ifBlank { "?" })
            val what = if (ExamWords.matches(item.title)) item.title else item.subtitle.lineSequence().firstOrNull().orEmpty()
            return if (what.isBlank()) subject else "$subject: ${what.take(60)}"
        }

        val title = when {
            exams.isNotEmpty() && homework.isNotEmpty() -> "Tomorrow: ${exams.size} exam" + (if (exams.size > 1) "s" else "") + ", ${homework.size} homework"
            exams.isNotEmpty() -> if (exams.size == 1) "Exam tomorrow" else "${exams.size} exams tomorrow"
            homework.size == 1 -> "1 homework due tomorrow"
            else -> "${homework.size} homework due tomorrow"
        }
        val body = (exams.map { "! " + line(it) } + homework.map { line(it) }).joinToString("\n").take(400)
        NotificationHelper.notifyReminder(context, title, body)
    }
}
