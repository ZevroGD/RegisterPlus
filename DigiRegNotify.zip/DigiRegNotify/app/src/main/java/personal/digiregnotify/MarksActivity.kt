package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

class MarksActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var chart: MultiLineChartView
    private lateinit var dropdownAdapter: SubjectDropdownAdapter
    private lateinit var overviewAdapter: SubjectOverviewAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var dropdownRecycler: RecyclerView
    private lateinit var overviewRecycler: RecyclerView
    private lateinit var chevron: TextView
    private lateinit var overviewChevron: TextView

    private var subjects: List<SubjectSummary> = emptyList() // only those with grades — charted
    private var allSubjects: List<SubjectSummary> = emptyList() // every subject, grades or not
    private var observationsBySubject: Map<Int, List<Observation>> = emptyMap()
    private val thicknessBySubject = mutableMapOf<Int, Int>() // default 3, 0..5 (0 = hidden)
    private var dropdownExpanded = false
    private var overviewExpanded = true // the main content, so it starts open

    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        // The chart card morphs into the full-screen chart (and back).
        window.requestFeature(android.view.Window.FEATURE_ACTIVITY_TRANSITIONS)
        setExitSharedElementCallback(
            com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback()
        )
        window.sharedElementsUseOverlay = false
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.marksEmptyText)
        swipeRefresh = findViewById(R.id.marksSwipeRefresh)
        chart = findViewById(R.id.combinedChart)
        findViewById<android.view.View>(R.id.chartCard).setOnClickListener {
            // Hand over what is loaded, so the full-screen chart opens instantly.
            MarksChartData.subjects = subjects
            MarksChartData.thickness = thicknessBySubject.toMap()
            val card = findViewById<android.view.View>(R.id.chartCard)
            card.transitionName = MarksChartActivity.TRANSITION_NAME
            val options = android.app.ActivityOptions.makeSceneTransitionAnimation(
                this, card, MarksChartActivity.TRANSITION_NAME
            )
            startActivity(android.content.Intent(this, MarksChartActivity::class.java), options.toBundle())
        }
        chevron = findViewById(R.id.subjectsDropdownChevron)
        overviewChevron = findViewById(R.id.allSubjectsDropdownChevron)

        dropdownRecycler = findViewById(R.id.marksRecyclerView)
        dropdownAdapter = SubjectDropdownAdapter(emptyList()) { subjectId, newThickness ->
            thicknessBySubject[subjectId] = newThickness
            renderChart() // the slider already shows its own value; don't re-bind the list
        }
        dropdownRecycler.layoutManager = LinearLayoutManager(this)
        dropdownRecycler.adapter = dropdownAdapter

        overviewRecycler = findViewById(R.id.allSubjectsRecyclerView)
        overviewAdapter = SubjectOverviewAdapter(emptyList())
        overviewRecycler.layoutManager = LinearLayoutManager(this)
        overviewRecycler.adapter = overviewAdapter

        findViewById<ImageButton>(R.id.marksBackButton).setOnClickListener { finish() }
        findViewById<android.widget.LinearLayout>(R.id.subjectsDropdownHeader).setOnClickListener {
            dropdownExpanded = !dropdownExpanded
            if (dropdownExpanded) Expand.expand(dropdownRecycler) else Expand.collapse(dropdownRecycler)
            Expand.rotateChevron(chevron, dropdownExpanded)
        }
        findViewById<android.widget.LinearLayout>(R.id.allSubjectsDropdownHeader).setOnClickListener {
            overviewExpanded = !overviewExpanded
            if (overviewExpanded) Expand.expand(overviewRecycler) else Expand.collapse(overviewRecycler)
            Expand.rotateChevron(overviewChevron, overviewExpanded)
        }
        Expand.rotateChevron(overviewChevron, overviewExpanded, animate = false) // starts open
        swipeRefresh.setOnRefreshListener { loadMarks() }
        loadMarks()
    }

    private fun loadMarks() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            if (!showSavedMarks("No internet")) {
                emptyText.text = "No internet connection right now"
                emptyText.visibility = TextView.VISIBLE
            }
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val (firstJson, secondJson) = api.fetchAllSubjectsBothSemesters()
            if (firstJson != null) {
                OfflineCache.save(this@MarksActivity, "marks-1", firstJson)
                if (secondJson != null) OfflineCache.save(this@MarksActivity, "marks-2", secondJson)
            }
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (isFinishing || isDestroyed) return@withContext
                if (firstJson == null) {
                    if (!showSavedMarks(ErrorText.reason(api.lastError))) {
                        emptyText.text = ErrorText.friendly(api.lastError, "load marks")
                        emptyText.visibility = TextView.VISIBLE
                        Toast.makeText(this@MarksActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    }
                    return@withContext
                }
                showMarks(firstJson, secondJson, null)
            }
        }
    }

    /** Shows the last marks the school sent, greyed out, if there are any. */
    private fun showSavedMarks(reason: String): Boolean {
        val first = OfflineCache.load(this, "marks-1") ?: return false
        val second = OfflineCache.load(this, "marks-2")
        return showMarks(first.json, second?.json, OfflineCache.note(first.savedAt, reason))
    }

    /**
     * Fills the screen from the school's answer. [storedNote] is set when this is a stored copy:
     * it is shown greyed out with a line saying when it was saved.
     */
    private fun showMarks(firstJson: String, secondJson: String?, storedNote: String?): Boolean {
        val merged = try {
            val first = AllSubjectsParser.parse(firstJson)
            if (secondJson != null) {
                AllSubjectsParser.merge(first, AllSubjectsParser.parse(secondJson))
            } else {
                if (storedNote == null) {
                    // Semester switch failed — still show what we have, but say so.
                    Toast.makeText(
                        this,
                        "Could only load one semester (the other failed to switch)",
                        Toast.LENGTH_LONG
                    ).show()
                }
                first
            }
        } catch (e: Exception) {
            if (storedNote == null) {
                emptyText.text = "Could not read the marks data"
                emptyText.visibility = TextView.VISIBLE
            }
            return false
        }

        val banner = findViewById<TextView>(R.id.marksStatusBanner)
        banner.text = storedNote
        banner.visibility = if (storedNote != null) TextView.VISIBLE else TextView.GONE
        swipeRefresh.animate().alpha(if (storedNote != null) 0.55f else 1f).setDuration(200).start()

        allSubjects = merged.sortedBy { it.name }
        if (storedNote == null) loadObservations() // needs the school's server
        subjects = allSubjects.filter { it.grades.isNotEmpty() }
        for (s in subjects) thicknessBySubject.putIfAbsent(s.subjectId, 3)
        SubjectRegistry.recordCodes(this, allSubjects.map { it.name })

        renderChart()
        renderDropdown()
        renderOverview()
        findViewById<TextView>(R.id.allSubjectsTitle).text = "All subjects · ${allSubjects.size}"
        findViewById<TextView>(R.id.subjectsDropdownTitle).text = "Chart lines · ${subjects.size}"

        emptyText.visibility = if (subjects.isEmpty()) TextView.VISIBLE else TextView.GONE
        emptyText.text = "No grades found yet"
        return true
    }

    private fun renderOverview() {
        val rows = allSubjects.map { s ->
            SubjectOverviewRow(
                summary = s,
                displayName = SubjectNames.nameFor(this, s.name),
                color = SubjectColors.colorForCode(this, s.name),
                averageText = (s.averageYear ?: s.averageSemester)?.let {
                    String.format(Locale.getDefault(), "%.2f", it)
                } ?: "–",
                observations = observationsBySubject[s.subjectId].orEmpty()
            )
        }
        overviewAdapter.updateRows(rows)
    }

    /** Teacher observations: the subject list only counts them, so fetch the details of the
     *  subjects that have some (usually few), then show them in the expanded subject. */
    private fun loadObservations() {
        val subjectsWithObservations = allSubjects.filter { it.countObservations > 0 }
        if (subjectsWithObservations.isEmpty()) {
            observationsBySubject = emptyMap()
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            val loaded = Observations.load(this@MarksActivity, subjectsWithObservations)
            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed) return@withContext
                observationsBySubject = loaded.groupBy { it.subjectId }
                renderOverview()
            }
        }
    }

    private fun renderChart() {
        chart.setSeries(
            buildChartSeries(this, subjects) { s -> (thicknessBySubject[s.subjectId] ?: 3).toFloat() }
        )
    }

    private fun renderDropdown() {
        val rows = subjects.map { s ->
            SubjectRowState(
                subjectId = s.subjectId,
                name = SubjectNames.nameFor(this, s.name),
                average = s.averageYear ?: s.averageSemester,
                color = SubjectColors.colorForCode(this, s.name),
                thickness = thicknessBySubject[s.subjectId] ?: 3
            )
        }
        dropdownAdapter.updateRows(rows)
    }
}
