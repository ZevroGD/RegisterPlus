package personal.digiregnotify

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(
    private var messages: List<MessageSummary>,
    private val onExpanded: (MessageSummary) -> Unit // called when an unread message is opened
) : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val unreadDot: View = view.findViewById(R.id.messageUnreadDot)
        val from: TextView = view.findViewById(R.id.messageFrom)
        val subject: TextView = view.findViewById(R.id.messageSubject)
        val preview: TextView = view.findViewById(R.id.messagePreview)
        val panel: LinearLayout = view.findViewById(R.id.messagePanel)
        var morph: ValueAnimator? = null // the preview growing into the full text, or back
    }

    // Which messages are open, so they stay open when the list is refreshed.
    private val openIds = mutableSetOf<Long>()

    /** Opens a message from outside (the "new message" notification); shown when the list is next drawn. */
    fun openMessage(messageId: Long) {
        if (openIds.add(messageId)) {
            val position = messages.indexOfFirst { it.id == messageId }
            if (position >= 0) notifyItemChanged(position)
        }
    }

    fun updateMessages(newMessages: List<MessageSummary>) {
        messages = newMessages
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val m = messages[position]
        holder.from.text = m.fromName.ifBlank { "Unknown sender" }
        holder.subject.text = m.subject.ifBlank { "(no subject)" }
        val open = m.id in openIds
        showState(holder, m, open)

        val color = ContextCompat.getColor(
            holder.itemView.context,
            if (m.isUnread) R.color.forest else R.color.hairline
        )
        (holder.unreadDot.background.mutate() as GradientDrawable).setColor(color)

        // The text itself is the preview, grown; the panel below only holds the attachments.
        Attachments.fillMessagePanel(holder.panel, m, includeBody = false)
        holder.panel.visibility = if (open && m.submissions.isNotEmpty()) View.VISIBLE else View.GONE
        holder.panel.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        holder.panel.alpha = 1f

        holder.itemView.setOnClickListener {
            if (m.id in openIds) {
                openIds.remove(m.id)
                morph(holder, m, open = false)
                if (m.submissions.isNotEmpty()) Expand.collapse(holder.panel)
            } else {
                openIds.add(m.id)
                morph(holder, m, open = true)
                if (m.submissions.isNotEmpty()) Expand.expand(holder.panel)
                if (m.isUnread) onExpanded(m)
            }
        }
    }

    override fun getItemCount(): Int = messages.size

    private fun fullText(m: MessageSummary) = m.fullBody.ifBlank { "(empty message)" }

    /** The preview as the closed message shows it, or the full text as the open one does. */
    private fun showState(holder: ViewHolder, m: MessageSummary, open: Boolean) {
        holder.morph?.cancel()
        val tv = holder.preview
        tv.maxLines = if (open) Int.MAX_VALUE else 2
        tv.text = if (open) fullText(m) else m.bodyPreview
        tv.alpha = if (open) 1f else PREVIEW_ALPHA
        tv.setTextIsSelectable(open)
        tv.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        tv.requestLayout()
    }

    /**
     * One text, not two: the preview itself grows into the full text (and shrinks back), brightening
     * as it goes. Its first two lines are the same in both states, so only the rest is revealed.
     */
    private fun morph(holder: ViewHolder, m: MessageSummary, open: Boolean) {
        val tv = holder.preview
        val width = tv.width
        if (width <= 0) {
            showState(holder, m, open)
            return
        }
        holder.morph?.cancel()
        val startHeight = tv.height
        val full = fullText(m)

        // How tall the text is closed (two lines) and open, at this width.
        fun heightWith(lines: Int): Int {
            tv.text = full
            tv.maxLines = lines
            tv.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            return tv.measuredHeight
        }
        val targetHeight = heightWith(if (open) Int.MAX_VALUE else 2)

        // Show all of the text, clipped to the height that is animated.
        tv.text = full
        tv.maxLines = Int.MAX_VALUE
        tv.setTextIsSelectable(false)
        val lp = tv.layoutParams
        lp.height = startHeight
        tv.requestLayout()

        val startAlpha = tv.alpha
        val endAlpha = if (open) 1f else PREVIEW_ALPHA
        holder.morph = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.height = (startHeight + (targetHeight - startHeight) * f).toInt()
                tv.alpha = startAlpha + (endAlpha - startAlpha) * f
                tv.requestLayout()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) showState(holder, m, open)
                }
            })
            start()
        }
    }

    private companion object {
        const val PREVIEW_ALPHA = 0.6f // as in item_message.xml
    }
}
