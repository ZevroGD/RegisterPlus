package personal.digiregnotify

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

data class UpdateInfo(
    val version: String,    // e.g. "1.1.14"
    val notes: String,
    val assetId: Long,
    val assetName: String
)

sealed class UpdateResult {
    object NoConnection : UpdateResult()
    data class UpToDate(val version: String) : UpdateResult()
    data class Available(val info: UpdateInfo) : UpdateResult()
    data class Failure(val message: String) : UpdateResult()
}

/**
 * Looks for a newer release of this app on GitHub and installs it. The repository is public, so
 * this works without any setup. A GitHub token is an optional extra that only raises GitHub's
 * request limit; it is kept encrypted on the phone (like the login).
 * Updates install over the old app because every build is signed with the same key.
 */
object UpdateChecker {

    private const val REPO = "ZevroGD/RegisterPlus"
    private const val AUTO_CHECK_EVERY_MS = 11L * 60 * 60 * 1000 // about twice a day
    private const val POPUP_EVERY_MS = 12L * 60 * 60 * 1000       // the in-app popup, at most twice a day

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(DevLogInterceptor()) // logs path and status only, never the token
        .build()

    private fun state(context: Context) =
        context.getSharedPreferences("digireg_update_state", Context.MODE_PRIVATE)

    private fun secret(context: Context) = EncryptedSharedPreferences.create(
        context.applicationContext, "digireg_update_secret",
        MasterKey.Builder(context.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getToken(context: Context): String? = try {
        secret(context).getString("token", null)?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    fun hasToken(context: Context) = getToken(context) != null

    fun saveToken(context: Context, token: String) {
        if (token.isBlank()) return
        try {
            secret(context).edit().putString("token", token.trim()).apply()
        } catch (e: Exception) {
            DevLog.w("Update", "could not save the token", e)
        }
    }

    fun clearToken(context: Context) {
        try {
            secret(context).edit().remove("token").apply()
        } catch (e: Exception) {
            // nothing to clear
        }
    }

    fun isAutoCheckEnabled(context: Context) = state(context).getBoolean("auto", false)
    fun setAutoCheck(context: Context, on: Boolean) = state(context).edit().putBoolean("auto", on).apply()

    fun currentVersion(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0"
    } catch (e: Exception) {
        "0"
    }

    /** True if [remote] (like "v1.1.14") is a higher version than [local] (like "1.1.13"). */
    fun isNewer(remote: String, local: String): Boolean {
        fun parts(v: String) = v.trim().trimStart('v', 'V').split('.')
            .map { it.takeWhile { c -> c.isDigit() }.toIntOrNull() ?: 0 }
        val a = parts(remote)
        val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** The token, if there is one, is only added for the higher rate limit. */
    private fun apiRequest(context: Context, url: String, accept: String, withToken: Boolean = true): Request {
        val builder = Request.Builder()
            .url(url)
            .header("Accept", accept)
            .header("X-GitHub-Api-Version", "2022-11-28")
        if (withToken) getToken(context)?.let { builder.header("Authorization", "Bearer $it") }
        return builder.build()
    }

    /**
     * Runs a GitHub request with the token. If GitHub rejects the token (expired or revoked),
     * it runs again without it: the repository is public, so updates keep working.
     */
    private fun call(context: Context, url: String, accept: String): okhttp3.Response {
        val response = client.newCall(apiRequest(context, url, accept)).execute()
        if (response.code == 401 && hasToken(context)) {
            response.close()
            DevLog.w("Update", "token rejected, trying without it")
            return client.newCall(apiRequest(context, url, accept, withToken = false)).execute()
        }
        return response
    }

    /** Asks GitHub for the latest release. Blocking: call it off the main thread. */
    fun check(context: Context): UpdateResult {
        return try {
            call(context, "https://api.github.com/repos/$REPO/releases/latest", "application/vnd.github+json").use { response ->
                when {
                    response.code == 401 ->
                        UpdateResult.Failure("GitHub rejected the token")
                    (response.code == 403 || response.code == 429) && response.header("x-ratelimit-remaining") == "0" ->
                        UpdateResult.Failure(
                            if (hasToken(context)) "GitHub limit reached, try again later"
                            else "GitHub limit reached. A token under GitHub access raises it"
                        )
                    response.code == 404 -> UpdateResult.Failure("No release found")
                    !response.isSuccessful -> UpdateResult.Failure("GitHub answered HTTP ${response.code}")
                    else -> parse(context, response.body?.string().orEmpty())
                }
            }
        } catch (e: IOException) {
            DevLog.w("Update", "check failed", e)
            if (NetworkUtil.isConnected(context)) UpdateResult.Failure(e.javaClass.simpleName) else UpdateResult.NoConnection
        } catch (e: Exception) {
            DevLog.w("Update", "check failed", e)
            UpdateResult.Failure(e.javaClass.simpleName)
        }
    }

    private fun parse(context: Context, body: String): UpdateResult {
        val json = JSONObject(body)
        val version = json.optString("tag_name").trimStart('v', 'V')
        if (version.isBlank()) return UpdateResult.Failure("The release has no version")
        val current = currentVersion(context)
        if (!isNewer(version, current)) {
            clearPending(context)
            return UpdateResult.UpToDate(current)
        }

        val assets = json.optJSONArray("assets")
        var assetId = 0L
        var assetName = ""
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                if (asset.optString("name").endsWith(".apk", ignoreCase = true)) {
                    assetId = asset.optLong("id")
                    assetName = asset.optString("name")
                    break
                }
            }
        }
        if (assetId == 0L) return UpdateResult.Failure("The release $version has no APK attached")
        val info = UpdateInfo(version, plainNotes(json.optString("body")), assetId, assetName)
        savePending(context, info)
        return UpdateResult.Available(info)
    }

    // ---- the update found by the latest check, so the app can offer it when it is opened ----

    private fun savePending(context: Context, info: UpdateInfo) {
        val json = JSONObject().put("version", info.version).put("notes", info.notes)
            .put("assetId", info.assetId).put("assetName", info.assetName)
        state(context).edit().putString("pending", json.toString()).apply()
    }

    private fun clearPending(context: Context) {
        state(context).edit().remove("pending").apply()
    }

    /** The update found earlier, if it is still newer than the installed app. */
    fun getPending(context: Context): UpdateInfo? {
        val raw = state(context).getString("pending", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val info = UpdateInfo(o.getString("version"), o.optString("notes"), o.getLong("assetId"), o.optString("assetName"))
            if (isNewer(info.version, currentVersion(context))) info else {
                clearPending(context)
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * What the in-app popup should show now: the pending update, but not more than about twice a
     * day (opening the app several times shouldn't nag). [force] ignores that, for a tap on the
     * notification. Showing it counts as shown.
     */
    fun takePendingForPopup(context: Context, force: Boolean): UpdateInfo? {
        val info = getPending(context) ?: return null
        val s = state(context)
        val now = System.currentTimeMillis()
        if (!force && now < s.getLong("popup_after", 0L)) return null
        s.edit().putLong("popup_after", now + POPUP_EVERY_MS).apply()
        return info
    }

    // ---- which app does the installing (chosen in the Developer menu) ----

    /** Package of the chosen installer app, or null for the system installer. */
    fun getInstallerPackage(context: Context): String? = state(context).getString("installer", null)

    fun setInstallerPackage(context: Context, packageName: String?) {
        state(context).edit().apply {
            if (packageName == null) remove("installer") else putString("installer", packageName)
        }.apply()
    }

    private const val APK_MIME = "application/vnd.android.package-archive"

    private fun apkViewIntent(): Intent = Intent(Intent.ACTION_VIEW)

    /**
     * The different ways an installer app can say "I take APK files". Every one is asked about,
     * since installers differ: opening a content or file address, a plain "install package"
     * request, or a share. (Android only shows us these kinds because the manifest lists them.)
     */
    private fun installerQueryIntents(): List<Intent> {
        val content = Uri.parse("content://installer.query/update.apk")
        val file = Uri.parse("file:///installer/query/update.apk")
        return listOf(
            Intent(Intent.ACTION_VIEW).setDataAndType(content, APK_MIME),
            Intent(Intent.ACTION_VIEW).setDataAndType(file, APK_MIME),
            Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(content, APK_MIME),
            Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(file, APK_MIME),
            Intent(Intent.ACTION_SEND).setType(APK_MIME)
        )
    }

    /** Apps that offer to take an APK, in any of those ways (label, package), without Register+. */
    fun listInstallers(context: Context): List<Pair<String, String>> {
        val pm = context.packageManager
        val found = linkedMapOf<String, String>() // package -> label
        for (query in installerQueryIntents()) {
            for (info in pm.queryIntentActivities(query, 0)) {
                val pkg = info.activityInfo.packageName
                if (pkg != context.packageName && pkg !in found) found[pkg] = info.loadLabel(pm).toString()
            }
        }
        return found.map { it.value to it.key }.sortedBy { it.first.lowercase() }
    }

    /** True for something shaped like an Android package name (com.example.app). */
    fun looksLikePackageName(text: String): Boolean =
        Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$").matches(text.trim())

    fun installerLabel(context: Context): String {
        val pkg = getInstallerPackage(context) ?: return "System installer"
        return try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg // an app Android won't tell us about (or it is gone): show the package name
        }
    }

    /** Release notes arrive as Markdown; show them as plain lines. */
    private fun plainNotes(markdown: String): String =
        markdown.replace("\r", "").lines().joinToString("\n") { line ->
            line.trimStart('#', ' ').replace("**", "").replace("*", "").replace(Regex("^- "), "• ")
        }.replace(Regex("\n{3,}"), "\n\n").trim()

    /** Downloads the APK of [info] into the cache. Blocking. Returns null on failure. */
    fun download(context: Context, info: UpdateInfo, onProgress: ((Int) -> Unit)? = null): File? {
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() } // only the newest download is kept
        val target = File(dir, info.assetName.ifBlank { "update.apk" })
        return try {
            // GitHub redirects the download to its storage; OkHttp drops the token on that hop.
            call(context, "https://api.github.com/repos/$REPO/releases/assets/${info.assetId}", "application/octet-stream").use { response ->
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    DevLog.w("Update", "download failed: HTTP ${response.code}")
                    null
                } else {
                    val total = body.contentLength()
                    var done = 0L
                    var lastPercent = -1
                    body.byteStream().use { input ->
                        target.outputStream().use { output ->
                            val buffer = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                done += n
                                if (total > 0 && onProgress != null) {
                                    val percent = (done * 100 / total).toInt()
                                    if (percent != lastPercent) {
                                        lastPercent = percent
                                        onProgress(percent)
                                    }
                                }
                            }
                        }
                    }
                    target
                }
            }
        } catch (e: Exception) {
            DevLog.w("Update", "download failed", e)
            null
        }
    }

    /**
     * Hands the APK to the installer chosen in the Developer menu; with none chosen (or if it is
     * gone) to the system installer, which first asks once for "install unknown apps".
     */
    fun install(activity: Activity, apk: File) {
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", apk)
        val intent = apkViewIntent().apply {
            setDataAndType(uri, APK_MIME)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chosen = getInstallerPackage(activity)
        if (chosen != null) {
            // Installers differ in what they accept, so try each in turn: open, install, share.
            val attempts = listOf(
                Intent(intent),
                Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
                    setDataAndType(uri, APK_MIME)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
                Intent(Intent.ACTION_SEND).apply {
                    type = APK_MIME
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
            for (attempt in attempts) {
                try {
                    activity.startActivity(attempt.setPackage(chosen))
                    DevLog.i("Update", "installing with $chosen (${attempt.action})")
                    return
                } catch (e: ActivityNotFoundException) {
                    // try the next way
                }
            }
            DevLog.w("Update", "installer $chosen accepts none of open/install/share, using the system installer")
        }

        if (!activity.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(activity, "Allow installing from Register+, then download again", Toast.LENGTH_LONG).show()
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, "Couldn't open the installer", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Called after a background check (and when the app is opened): about twice a day, and only when switched on, it
     * looks for a new release and posts one notification per new version ([notify]). It never installs.
     */
    fun autoCheck(context: Context, notify: Boolean = true) {
        if (!isAutoCheckEnabled(context)) return
        val s = state(context)
        val now = System.currentTimeMillis()
        if (now - s.getLong("last_auto", 0L) < AUTO_CHECK_EVERY_MS) return
        s.edit().putLong("last_auto", now).apply()

        val result = check(context)
        // A failed look (offline, GitHub busy) shouldn't use up the next 11 hours.
        if (result is UpdateResult.Failure || result is UpdateResult.NoConnection) s.edit().putLong("last_auto", 0L).apply()
        DevLog.i("Update", "auto check: " + when (result) {
            is UpdateResult.Available -> "update ${result.info.version}"
            is UpdateResult.UpToDate -> "up to date"
            is UpdateResult.Failure -> "failed (${result.message})"
            else -> "skipped"
        })
        if (notify && result is UpdateResult.Available && s.getString("last_notified", "") != result.info.version) {
            s.edit().putString("last_notified", result.info.version).apply()
            NotificationHelper.notifyUpdate(context, result.info.version)
        }
    }
}
