package personal.digiregnotify

sealed class HomeworkRow {
    data class DateHeader(
        val label: String,
        val deleted: List<DeletedHomework> = emptyList() // homework that was due this day but got deleted
    ) : HomeworkRow()
    data class Item(
        val item: DashboardItem,
        val versions: List<ItemVersion> = emptyList() // earlier texts, oldest first; empty = never edited
    ) : HomeworkRow()
    data class EmptyNote(val text: String) : HomeworkRow()
    /** Unread messages, shown at the very top — but as real rows, so they scroll away with
     *  everything else instead of staying pinned above the list. */
    data class UnreadMessage(val message: MessageSummary) : HomeworkRow()
    /** A new mark or observation the school lists as unread; it can be marked as read. */
    data class UnreadMark(val notice: UnreadNotification) : HomeworkRow()
}
