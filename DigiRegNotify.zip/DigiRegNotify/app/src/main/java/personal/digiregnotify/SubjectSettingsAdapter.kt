package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class SubjectSettingsRow(val code: String, val name: String, val color: Int)

class SubjectSettingsAdapter(
    private var rows: List<SubjectSettingsRow>,
    private val onRename: (code: String) -> Unit,
    private val onRecolor: (code: String) -> Unit
) : RecyclerView.Adapter<SubjectSettingsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dot: View = view.findViewById(R.id.subjSettingsColorDot)
        val name: TextView = view.findViewById(R.id.subjSettingsName)
        val code: TextView = view.findViewById(R.id.subjSettingsCode)
        val nameRow: View = name.parent as View
    }

    fun updateRows(newRows: List<SubjectSettingsRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_settings_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        holder.name.text = row.name
        holder.code.text = row.code
        (holder.dot.background.mutate() as GradientDrawable).setColor(row.color)

        holder.dot.setOnClickListener { onRecolor(row.code) }
        holder.nameRow.setOnClickListener { onRename(row.code) }
    }

    override fun getItemCount(): Int = rows.size
}
