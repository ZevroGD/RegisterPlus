package personal.digiregnotify

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Every screen extends this so palette changes apply consistently everywhere. */
abstract class BaseActivity : AppCompatActivity() {

    private var appliedPalette: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedPalette = PaletteManager.getAppearanceSignature(this)
        setTheme(PaletteManager.getStyleResId(this))
        PaletteManager.applyCustomOverlays(this) // no-op unless the Custom palette is selected
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        // The palette can be changed in Settings while this screen sits underneath it.
        // Without this it would keep the old colors until something else recreated it.
        if (appliedPalette != PaletteManager.getAppearanceSignature(this)) {
            recreate()
        }
    }
}
