package personal.digiregnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        DevLog.i("Reminder", "reminder alarm fired")
        // The next day's alarm first, so a failure below can't end the chain.
        ReminderScheduler.schedule(context)
        if (!ExtraPrefs.isReminderEnabled(context)) return
        try {
            ReminderScheduler.post(context)
        } catch (e: Exception) {
            DevLog.w("Reminder", "could not build the reminder", e)
        }
    }
}
