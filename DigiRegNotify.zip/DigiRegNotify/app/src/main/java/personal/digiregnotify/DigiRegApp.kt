package personal.digiregnotify

import android.app.Application

class DigiRegApp : Application() {
    override fun onCreate() {
        super.onCreate()
        DevLog.init(this)
        CrashReporter.install(this)
        ThemeManager.applySaved(this)
    }
}
