package personal.digiregnotify

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Hands what the Marks screen loaded over to the edit screen. */
object MarksEditData {
    var subjects: List<SubjectSummary> = emptyList() // every subject, grades or not
    var observations: Map<Int, List<Observation>> = emptyMap()
    var thickness: Map<Int, Int> = emptyMap() // chart line thickness per subject, 0 = hidden
}

/** One mark on the edit screen: a copy that can be changed, removed or added. */
class EditableGrade(
    val id: Int,
    var value: Float,
    var weight: Int,
    val semester: Int,
    val type: String,
    val description: String,
    val isoDate: String,
    val added: Boolean,
    val originalValue: Float?,
    val originalWeight: Int?
) {
    val title: String
        get() = listOf(type, description).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "Grade" }

    val changed: Boolean get() = !added && (value != originalValue || weight != originalWeight)

    fun toGrade() = SubjectGrade(value, isoDate, type, weight, description, semester)
}

/**
 * The marks of every subject, as editable copies. Nothing here is sent to the school or saved;
 * [reset] goes back to the real marks.
 */
class MarksEditor(private val source: List<SubjectSummary>) {

    private var nextId = 0
    private val bySubject = LinkedHashMap<Int, MutableList<EditableGrade>>() // newest first
    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    init { reset() }

    fun reset() {
        bySubject.clear()
        for (s in source) {
            bySubject[s.subjectId] = s.grades.asReversed().map { g ->
                EditableGrade(
                    id = nextId++, value = g.value, weight = g.weight, semester = g.semester,
                    type = g.type, description = g.description, isoDate = g.date,
                    added = false, originalValue = g.value, originalWeight = g.weight
                )
            }.toMutableList()
        }
    }

    fun grades(subjectId: Int): MutableList<EditableGrade> =
        bySubject.getOrPut(subjectId) { mutableListOf() }

    /** The subject's marks oldest to newest, for the charts. */
    fun chronological(subjectId: Int): List<SubjectGrade> =
        grades(subjectId).map { it.toGrade() }.sortedBy { it.date }

    fun isModified(s: SubjectSummary): Boolean {
        val list = grades(s.subjectId)
        return list.size != s.grades.size || list.any { it.added || it.changed }
    }

    fun anyModified(): Boolean = source.any { isModified(it) }

    /** The school's own average while the subject is untouched; calculated from the marks and
     *  weights once it has been changed. */
    fun average(s: SubjectSummary): Float? =
        if (!isModified(s)) s.averageYear ?: s.averageSemester
        else GradeCalc.totals(grades(s.subjectId).map { it.toGrade() }).average?.toFloat()

    fun add(subjectId: Int, value: Float, weight: Int, semester: Int) {
        grades(subjectId).add(
            0,
            EditableGrade(
                id = nextId++, value = value, weight = weight, semester = semester,
                type = "Added mark", description = "", isoDate = isoDate.format(Date()),
                added = true, originalValue = null, originalWeight = null
            )
        )
    }

    fun remove(subjectId: Int, g: EditableGrade) {
        grades(subjectId).remove(g)
    }
}
