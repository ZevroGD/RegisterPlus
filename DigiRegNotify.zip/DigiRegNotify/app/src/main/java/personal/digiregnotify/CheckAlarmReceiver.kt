package personal.digiregnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CheckAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Always reschedule the next check first, so a crash/failure below
        // doesn't silently kill the whole chain.
        DevLog.i("Alarm", "background check alarm fired")
        AlarmScheduler.scheduleRepeating(context)

        if (ExtraPrefs.isQuiet(context, System.currentTimeMillis())) {
            DevLog.i("Alarm", "quiet hours: skipping this check")
            return
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                when (val result = CheckRunner.performCheck(context, CheckStatus.Source.BACKGROUND)) {
                    is CheckResult.NoConnection ->
                        // No signal right now — say nothing, next scheduled
                        // check (already queued above) will try again.
                        Log.i("DigiReg", "Skipping check: no network connection")
                    is CheckResult.Failure ->
                        if (result.unreachable || ErrorText.isUnreachable(result.message) || ErrorText.isServerError(result.message)) {
                            // The school's server (or the connection) is down: it will try again next time.
                            Log.i("DigiReg", "Skipping error notification: transient connectivity issue")
                        } else {
                            NotificationHelper.notifyError(context, ErrorText.friendly(result.message, "check"))
                        }
                    is CheckResult.Success ->
                        Log.i("DigiReg", "Check OK: ${result.totalItems} items, ${result.newItems} new")
                }
                // Optional, about once a day: tell the user when a newer release exists.
                try {
                    UpdateChecker.autoCheck(context)
                } catch (e: Exception) {
                    DevLog.w("Update", "auto check crashed", e)
                }
            } catch (e: Exception) {
                Log.e("DigiReg", "Check failed", e)
                NotificationHelper.notifyError(context, e.message ?: "Unknown error")
            } finally {
                pendingResult.finish()
            }
        }
    }
}
