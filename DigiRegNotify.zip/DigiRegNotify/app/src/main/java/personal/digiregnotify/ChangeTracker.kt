package personal.digiregnotify

import android.content.Context
import org.json.JSONObject

/** Remembers what we've already told you about, so each thing notifies only once. */
object ChangeTracker {

    private const val PREFS = "digireg_change_tracker"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Developer menu: forget everything already announced; the next check re-baselines silently. */
    fun resetBaseline(context: Context) {
        prefs(context).edit().clear().apply()
    }

    /**
     * Given the ids of the currently unread message notifications, returns the ones we
     * haven't seen before. The very first call only records a baseline (returns empty),
     * so messages that were already unread when you installed the app don't all ping.
     */
    fun newMessageNotificationIds(context: Context, current: Set<String>): Set<String> =
        newNotificationIds(context, "seen_message_notifs", current)

    /** Same idea for unread observation notifications. */
    fun newObservationNotificationIds(context: Context, current: Set<String>): Set<String> =
        newNotificationIds(context, "seen_observation_notifs", current)

    /** Same idea for unread grade notifications. */
    fun newGradeNotificationIds(context: Context, current: Set<String>): Set<String> =
        newNotificationIds(context, "seen_grade_notifs", current)

    private fun newNotificationIds(context: Context, key: String, current: Set<String>): Set<String> {
        val p = prefs(context)
        val hadBaseline = p.contains(key)
        val seen = p.getStringSet(key, emptySet()) ?: emptySet()
        p.edit().putStringSet(key, current.toSet()).apply()
        return if (hadBaseline) current - seen else emptySet()
    }

    /** Last known timetable as "date|hour" -> lesson signature, or null if none yet. */
    fun getTimetableSnapshot(context: Context): Map<String, String>? {
        val raw = prefs(context).getString("timetable_snapshot", null) ?: return null
        return try {
            val obj = JSONObject(raw)
            val map = mutableMapOf<String, String>()
            for (key in obj.keys()) map[key] = obj.optString(key)
            map
        } catch (e: Exception) {
            null
        }
    }

    fun saveTimetableSnapshot(context: Context, snapshot: Map<String, String>) {
        val obj = JSONObject()
        for ((k, v) in snapshot) obj.put(k, v)
        prefs(context).edit().putString("timetable_snapshot", obj.toString()).apply()
    }

    fun clearTimetableSnapshot(context: Context) {
        prefs(context).edit().remove("timetable_snapshot").apply()
    }
}
