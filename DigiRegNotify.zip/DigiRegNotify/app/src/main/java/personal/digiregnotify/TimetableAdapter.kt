package personal.digiregnotify

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

private const val VIEW_TYPE_HEADER = 0
private const val VIEW_TYPE_LESSON = 1
private const val VIEW_TYPE_EMPTY = 2

class TimetableAdapter(private var rows: List<TimetableRow>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view as TextView
    }

    class LessonViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val time: TextView = view.findViewById(R.id.lessonTime)
        val subject: TextView = view.findViewById(R.id.lessonSubject)
        val detail: TextView = view.findViewById(R.id.lessonDetail)
        val substituteBadge: TextView = view.findViewById(R.id.lessonSubstituteBadge)
    }

    class EmptyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view as TextView
    }

    fun updateRows(newRows: List<TimetableRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int =
        when (rows[position]) {
            is TimetableRow.DayHeader -> VIEW_TYPE_HEADER
            is TimetableRow.Lesson -> VIEW_TYPE_LESSON
            is TimetableRow.NoLessons -> VIEW_TYPE_EMPTY
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_HEADER -> HeaderViewHolder(inflater.inflate(R.layout.item_homework_header, parent, false))
            VIEW_TYPE_EMPTY -> EmptyViewHolder(inflater.inflate(R.layout.item_homework_empty, parent, false))
            else -> LessonViewHolder(inflater.inflate(R.layout.item_timetable_lesson, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is TimetableRow.DayHeader -> (holder as HeaderViewHolder).label.text = row.label
            is TimetableRow.NoLessons -> (holder as EmptyViewHolder).text.text = row.text
            is TimetableRow.Lesson -> {
                val h = holder as LessonViewHolder
                val info = row.info
                h.time.text = info.time
                h.subject.text = info.subject.ifBlank { "(no subject)" }

                val detailParts = mutableListOf<String>()
                if (info.rooms.isNotBlank()) detailParts.add(info.rooms)
                if (info.teachers.isNotBlank()) detailParts.add(info.teachers)
                if (info.extras.isNotBlank()) detailParts.add(info.extras)
                h.detail.text = detailParts.joinToString(" · ")
                h.detail.visibility = if (detailParts.isEmpty()) View.GONE else View.VISIBLE

                h.substituteBadge.visibility = if (info.isSubstitute) View.VISIBLE else View.GONE
            }
        }
    }

    override fun getItemCount(): Int = rows.size
}
