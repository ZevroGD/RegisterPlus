package personal.digiregnotify

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * The timetable: one page per week in a horizontally snapping list, so you can swipe through
 * weeks smoothly (the arrows and "Today" glide the same way). A week is fetched when its page is
 * about to be seen, and the neighbouring weeks are fetched ahead so a swipe usually lands on a
 * page that is already filled in.
 */
class TimetableActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var pager: RecyclerView
    private lateinit var adapter: TimetablePagerAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var snapHelper: PagerSnapHelper
    private lateinit var weekLabel: TextView
    private lateinit var todayButton: TextView

    private val states = mutableMapOf<String, WeekState>()
    private val monthFormat = SimpleDateFormat("MMMM", Locale.getDefault())
    private var currentPosition = TimetablePagerAdapter.BASE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timetable)

        api = RegisterApi(this)
        pager = findViewById(R.id.weekPager)
        weekLabel = findViewById(R.id.weekLabelText)
        todayButton = findViewById(R.id.todayButton)

        adapter = TimetablePagerAdapter(
            baseMonday = mondayOf(Calendar.getInstance()),
            states = states,
            onNeedWeek = { position -> ensureLoaded(position) },
            onRefresh = { position -> reload(position) },
            onLesson = { lesson -> showLessonDetail(lesson) }
        )
        layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        pager.layoutManager = layoutManager
        pager.adapter = adapter
        pager.setItemViewCacheSize(2)
        snapHelper = PagerSnapHelper().also { it.attachToRecyclerView(pager) }
        pager.scrollToPosition(TimetablePagerAdapter.BASE)

        pager.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) = syncPosition()
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) syncPosition()
            }
        })

        findViewById<ImageButton>(R.id.timetableBackButton).setOnClickListener { finish() }
        findViewById<View>(R.id.prevWeekButton).setOnClickListener { glideTo(currentPosition - 1) }
        findViewById<View>(R.id.nextWeekButton).setOnClickListener { glideTo(currentPosition + 1) }
        todayButton.setOnClickListener { glideTo(TimetablePagerAdapter.BASE) }

        pager.post {
            syncPosition()
            updateHeader()
            ensureLoaded(TimetablePagerAdapter.BASE)
        }
    }

    private fun glideTo(position: Int) {
        pager.smoothScrollToPosition(position.coerceIn(0, TimetablePagerAdapter.PAGES - 1))
    }

    /** Works out which page is in the middle, and when it changes updates the title and loads ahead. */
    private fun syncPosition() {
        val view = snapHelper.findSnapView(layoutManager) ?: return
        val position = layoutManager.getPosition(view)
        if (position == RecyclerView.NO_POSITION || position == currentPosition) return
        currentPosition = position
        updateHeader()
        pager.post {
            ensureLoaded(position)
            ensureLoaded(position - 1)
            ensureLoaded(position + 1)
        }
    }

    private fun updateHeader() {
        val monday = adapter.mondayFor(currentPosition)
        val sunday = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 6) }
        // Just the month (or both months when the week spans two); the year only when it isn't this one.
        var range = monthFormat.format(monday.time)
        if (monday.get(Calendar.MONTH) != sunday.get(Calendar.MONTH)) {
            range += " – " + monthFormat.format(sunday.time)
        }
        val year = sunday.get(Calendar.YEAR)
        if (year != Calendar.getInstance().get(Calendar.YEAR)) range += " $year"
        weekLabel.text = if (currentPosition == TimetablePagerAdapter.BASE) "This week · $range" else range
        todayButton.visibility = if (currentPosition == TimetablePagerAdapter.BASE) View.INVISIBLE else View.VISIBLE
    }

    private val inFlight = mutableSetOf<String>() // weeks being fetched right now

    /** Fetches a week unless it is already loaded or on its way. */
    private fun ensureLoaded(position: Int) {
        if (position !in 0 until TimetablePagerAdapter.PAGES) return
        val key = adapter.keyFor(position)
        val state = states[key]
        // A week that failed, or is only a stored copy, is tried again when you come back to it.
        val settled = state != null && state !is WeekState.Failed && !(state is WeekState.Loaded && state.note != null)
        if (settled) return
        if (state == WeekState.Loading) return
        load(position, key)
    }

    /** Pull-to-refresh on a page: fetch that week again. */
    private fun reload(position: Int) {
        load(position, adapter.keyFor(position))
    }

    private fun load(position: Int, key: String) {
        if (!api.hasCredentials()) {
            states[key] = WeekState.Failed("Sign in from the main screen first")
            adapter.notifyItemChanged(position)
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            states[key] = savedWeek(key, "No internet") ?: WeekState.Failed("No internet connection right now")
            adapter.notifyItemChanged(position)
            return
        }
        if (!inFlight.add(key)) return // already on its way
        // A week that is already showing (even a stored copy) stays on screen while it is fetched again.
        if (states[key] !is WeekState.Loaded) {
            // Show the saved copy of this week at once if there is one (no note, not greyed out),
            // and only fall back to the spinner when there isn't.
            states[key] = savedWeek(key, null) ?: WeekState.Loading
            adapter.notifyItemChanged(position)
        }

        CoroutineScope(Dispatchers.IO).launch {
            val result: WeekState = try {
                val json = api.fetchCalendarWeek(key)
                if (json == null) {
                    savedWeek(key, ErrorText.reason(api.lastError))
                        ?: WeekState.Failed(ErrorText.friendly(api.lastError, "load the timetable"))
                } else {
                    val week = TimetableParser.parseWeek(json)
                    OfflineCache.save(this@TimetableActivity, "timetable-$key", json)
                    SubjectRegistry.recordCodes(this@TimetableActivity, week.lessons.map { it.subject })
                    WeekState.Loaded(week)
                }
            } catch (e: Exception) {
                DevLog.w("Timetable", "week $key failed", e)
                WeekState.Failed("Could not read the timetable")
            }
            withContext(Dispatchers.Main) {
                inFlight.remove(key)
                if (isFinishing || isDestroyed) return@withContext
                states[key] = result
                adapter.notifyItemChanged(position)
            }
        }
    }

    /** The last copy of a week the school sent, or null if there isn't one. */
    private fun savedWeek(key: String, reason: String?): WeekState.Loaded? {
        val saved = OfflineCache.load(this, "timetable-$key") ?: return null
        return try {
            // reason == null: shown only while the fresh week loads, so the note is empty ("").
            WeekState.Loaded(
                TimetableParser.parseWeek(saved.json),
                if (reason == null) "" else OfflineCache.note(saved.savedAt, reason)
            )
        } catch (e: Exception) {
            null
        }
    }

    /** The lesson's details: labels in a column on the left, the facts next to them. */
    private fun showLessonDetail(lesson: LessonInfo) {
        val view = layoutInflater.inflate(R.layout.dialog_lesson_detail, null)
        val rows = view.findViewById<LinearLayout>(R.id.lessonDetailRows)

        fun addRow(label: String, value: String) {
            val row = layoutInflater.inflate(R.layout.item_lesson_detail_row, rows, false)
            row.findViewById<TextView>(R.id.lessonRowLabel).text = label
            row.findViewById<TextView>(R.id.lessonRowValue).text = value
            rows.addView(row)
        }

        val status = mutableListOf<String>()
        if (lesson.isCancelled) status.add("Cancelled")
        if (lesson.isSubstitute) status.add("Substitute lesson")
        if (status.isNotEmpty()) {
            val statusView = view.findViewById<TextView>(R.id.lessonDetailStatus)
            statusView.text = status.joinToString(" · ")
            statusView.setTextColor(Color.parseColor(if (lesson.isCancelled) "#EF5350" else "#FFA726"))
            statusView.visibility = View.VISIBLE
        }

        addRow("Time", lesson.time)
        // A cancelled lesson has "Ausfall" or the like as its room, so the room is left out.
        if (!lesson.isCancelled && lesson.rooms.isNotBlank()) addRow("Room", lesson.rooms)
        if (lesson.teachers.isNotBlank()) addRow("Teacher", lesson.teachers)
        // The school files homework and tests (and things like "Mappe") in the same list.
        if (lesson.extras.isNotBlank()) addRow("Homework & tests", lesson.extras)

        SlideDialogBuilder(this)
            .setTitle(SubjectNames.nameFor(this, lesson.subject.ifBlank { "Lesson" }))
            .setView(view)
            .setPositiveButton("OK", null)
            .show()
    }

    companion object {
        private fun mondayOf(cal: Calendar): Calendar {
            val result = cal.clone() as Calendar
            result.set(Calendar.HOUR_OF_DAY, 0)
            result.set(Calendar.MINUTE, 0)
            result.set(Calendar.SECOND, 0)
            result.set(Calendar.MILLISECOND, 0)
            val isoDow = (result.get(Calendar.DAY_OF_WEEK) + 5) % 7
            result.add(Calendar.DAY_OF_YEAR, -isoDow)
            return result
        }
    }
}
