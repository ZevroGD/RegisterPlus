package personal.digiregnotify

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * The timetable: one page per week in a horizontally snapping list, so you can swipe through
 * weeks smoothly (the arrows and "Today" glide the same way). A week is fetched when its page is
 * about to be seen, and the neighbouring weeks are fetched ahead so a swipe usually lands on a
 * page that is already filled in.
 */
class TimetableActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var pager: RecyclerView
    private lateinit var adapter: TimetablePagerAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var snapHelper: PagerSnapHelper
    private lateinit var weekLabel: TextView
    private lateinit var todayButton: TextView

    private val states = mutableMapOf<String, WeekState>()
    private val rangeFormat = SimpleDateFormat("d MMM", Locale.getDefault())
    private var currentPosition = TimetablePagerAdapter.BASE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timetable)

        api = RegisterApi(this)
        pager = findViewById(R.id.weekPager)
        weekLabel = findViewById(R.id.weekLabelText)
        todayButton = findViewById(R.id.todayButton)

        adapter = TimetablePagerAdapter(
            baseMonday = mondayOf(Calendar.getInstance()),
            states = states,
            onNeedWeek = { position -> ensureLoaded(position) },
            onRefresh = { position -> reload(position) },
            onLesson = { lesson -> showLessonDetail(lesson) }
        )
        layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        pager.layoutManager = layoutManager
        pager.adapter = adapter
        pager.setItemViewCacheSize(2)
        snapHelper = PagerSnapHelper().also { it.attachToRecyclerView(pager) }
        pager.scrollToPosition(TimetablePagerAdapter.BASE)

        pager.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) = syncPosition()
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) syncPosition()
            }
        })

        findViewById<ImageButton>(R.id.timetableBackButton).setOnClickListener { finish() }
        findViewById<TextView>(R.id.prevWeekButton).setOnClickListener { glideTo(currentPosition - 1) }
        findViewById<TextView>(R.id.nextWeekButton).setOnClickListener { glideTo(currentPosition + 1) }
        todayButton.setOnClickListener { glideTo(TimetablePagerAdapter.BASE) }

        pager.post {
            syncPosition()
            updateHeader()
            ensureLoaded(TimetablePagerAdapter.BASE)
        }
    }

    private fun glideTo(position: Int) {
        pager.smoothScrollToPosition(position.coerceIn(0, TimetablePagerAdapter.PAGES - 1))
    }

    /** Works out which page is in the middle, and when it changes updates the title and loads ahead. */
    private fun syncPosition() {
        val view = snapHelper.findSnapView(layoutManager) ?: return
        val position = layoutManager.getPosition(view)
        if (position == RecyclerView.NO_POSITION || position == currentPosition) return
        currentPosition = position
        updateHeader()
        pager.post {
            ensureLoaded(position)
            ensureLoaded(position - 1)
            ensureLoaded(position + 1)
        }
    }

    private fun updateHeader() {
        val monday = adapter.mondayFor(currentPosition)
        val sunday = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 6) }
        val range = "${rangeFormat.format(monday.time)} – ${rangeFormat.format(sunday.time)}"
        weekLabel.text = if (currentPosition == TimetablePagerAdapter.BASE) "This week · $range" else range
        todayButton.visibility = if (currentPosition == TimetablePagerAdapter.BASE) View.INVISIBLE else View.VISIBLE
    }

    /** Fetches a week unless it is already loaded or on its way. */
    private fun ensureLoaded(position: Int) {
        if (position !in 0 until TimetablePagerAdapter.PAGES) return
        val key = adapter.keyFor(position)
        if (states.containsKey(key)) return
        load(position, key)
    }

    /** Pull-to-refresh on a page: fetch that week again. */
    private fun reload(position: Int) {
        load(position, adapter.keyFor(position))
    }

    private fun load(position: Int, key: String) {
        if (!api.hasCredentials()) {
            states[key] = WeekState.Failed("Sign in from the main screen first")
            adapter.notifyItemChanged(position)
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            states[key] = savedWeek(key, "No internet") ?: WeekState.Failed("No internet connection right now")
            adapter.notifyItemChanged(position)
            return
        }
        states[key] = WeekState.Loading
        adapter.notifyItemChanged(position)

        CoroutineScope(Dispatchers.IO).launch {
            val result: WeekState = try {
                val json = api.fetchCalendarWeek(key)
                if (json == null) {
                    savedWeek(key, ErrorText.reason(api.lastError))
                        ?: WeekState.Failed(ErrorText.friendly(api.lastError, "load the timetable"))
                } else {
                    val week = TimetableParser.parseWeek(json)
                    OfflineCache.save(this@TimetableActivity, "timetable-$key", json)
                    SubjectRegistry.recordCodes(this@TimetableActivity, week.lessons.map { it.subject })
                    WeekState.Loaded(week)
                }
            } catch (e: Exception) {
                DevLog.w("Timetable", "week $key failed", e)
                WeekState.Failed("Could not read the timetable")
            }
            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed) return@withContext
                states[key] = result
                adapter.notifyItemChanged(position)
            }
        }
    }

    /** The last copy of a week the school sent, or null if there isn't one. */
    private fun savedWeek(key: String, reason: String): WeekState.Loaded? {
        val saved = OfflineCache.load(this, "timetable-$key") ?: return null
        return try {
            WeekState.Loaded(TimetableParser.parseWeek(saved.json), OfflineCache.note(saved.savedAt, reason))
        } catch (e: Exception) {
            null
        }
    }

    private fun showLessonDetail(lesson: LessonInfo) {
        val lines = mutableListOf("Time: ${lesson.time}")
        if (lesson.rooms.isNotBlank()) lines.add("Room: ${lesson.rooms}")
        if (lesson.teachers.isNotBlank()) lines.add("Teacher: ${lesson.teachers}")
        if (lesson.extras.isNotBlank()) lines.add("Also: ${lesson.extras}")
        if (lesson.isSubstitute) lines.add("⚠ Substitute lesson")

        SlideDialogBuilder(this)
            .setTitle(SubjectNames.nameFor(this, lesson.subject.ifBlank { "Lesson" }))
            .setMessage(lines.joinToString("\n"))
            .setPositiveButton("OK", null)
            .show()
    }

    companion object {
        private fun mondayOf(cal: Calendar): Calendar {
            val result = cal.clone() as Calendar
            result.set(Calendar.HOUR_OF_DAY, 0)
            result.set(Calendar.MINUTE, 0)
            result.set(Calendar.SECOND, 0)
            result.set(Calendar.MILLISECOND, 0)
            val isoDow = (result.get(Calendar.DAY_OF_WEEK) + 5) % 7
            result.add(Calendar.DAY_OF_YEAR, -isoDow)
            return result
        }
    }
}
