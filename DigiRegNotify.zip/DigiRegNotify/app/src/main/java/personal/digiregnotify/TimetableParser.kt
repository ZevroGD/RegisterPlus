package personal.digiregnotify

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LessonInfo(
    val date: String,      // yyyy-MM-dd
    val hour: Int,
    val time: String,      // "08:00–08:45"
    val subject: String,
    val rooms: String,
    val teachers: String,
    val isSubstitute: Boolean,
    val extras: String,    // homework/tests attached to this lesson, e.g. "Hausaufgabe"
    val toHour: Int = 0    // last period it covers; a double hour has toHour = hour + 1 (0 = same as hour)
) {
    /** True if a test, exam or similar is attached (anything attached that isn't plain homework). */
    val hasExam: Boolean
        get() = extras.split(',').map { it.trim() }.filter { it.isNotEmpty() }.any {
            !it.contains("hausaufgabe", ignoreCase = true) && !it.contains("hausübung", ignoreCase = true)
        }

    /** What counts as "this lesson changed". Attached homework deliberately doesn't. */
    val signature: String get() = "$subject|$rooms|$teachers|$isSubstitute|$time"
}

data class ParsedWeek(val dates: List<String>, val lessons: List<LessonInfo>)

sealed class TimetableRow {
    data class DayHeader(val label: String) : TimetableRow()
    data class Lesson(val info: LessonInfo) : TimetableRow()
    data class NoLessons(val text: String) : TimetableRow()
}

/**
 * Reads the reply of POST /api/calendar/student, which is shaped
 *   { "2026-09-28": { "1": { "1": { "<hour>": { isLesson, lesson: {...} } } } }, ... }
 */
object TimetableParser {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    @Synchronized // the format isn't thread-safe, and checks run off the main thread
    fun parseDate(raw: String): Date? = try {
        dateFormat.parse(raw)
    } catch (e: Exception) {
        null
    }

    fun parseWeek(json: String): ParsedWeek {
        val root = JSONObject(json)
        val dates = mutableListOf<String>()
        val lessons = mutableListOf<LessonInfo>()

        for (date in root.keys()) {
            dates.add(date)
            val day = root.optJSONObject(date) ?: continue
            val entries = mutableListOf<JSONObject>()
            collectEntries(day, entries)

            for (entry in entries) {
                if (entry.optInt("isLesson", 0) != 1) continue
                val lesson = entry.optJSONObject("lesson") ?: continue
                // The second hour of a double lesson is listed again; skip that duplicate.
                if (lesson.optInt("linkToPreviousHour", 0) != 0) continue

                val start = lesson.optJSONObject("timeStartObject")?.optString("text").orEmpty()
                val endObj = lesson.optJSONObject("timeToEndObject") ?: lesson.optJSONObject("timeEndObject")
                val end = endObj?.optString("text").orEmpty()
                val time = if (start.isNotEmpty() && end.isNotEmpty()) "$start–$end" else start

                lessons.add(
                    LessonInfo(
                        date = date,
                        hour = entry.optInt("hour", lesson.optInt("hour", 0)),
                        time = time,
                        subject = lesson.optJSONObject("subject")?.optString("name").orEmpty(),
                        rooms = joinNames(lesson.optJSONArray("rooms"), "name"),
                        teachers = joinNames(lesson.optJSONArray("teachers"), "lastName"),
                        isSubstitute = lesson.optInt("isSubstitute", 0) != 0,
                        extras = joinNames(lesson.optJSONArray("homeworkExams"), "typeName"),
                        toHour = lesson.optInt("toHour", 0)
                    )
                )
            }
        }
        return ParsedWeek(dates.sorted(), lessons.sortedWith(compareBy({ it.date }, { it.hour })))
    }

    /** The reply nests entries a couple of levels deep; find every object that has "isLesson". */
    private fun collectEntries(node: JSONObject, out: MutableList<JSONObject>) {
        if (node.has("isLesson")) {
            out.add(node)
            return
        }
        for (key in node.keys()) {
            node.optJSONObject(key)?.let { collectEntries(it, out) }
        }
    }

    private fun joinNames(array: JSONArray?, key: String): String {
        if (array == null) return ""
        val names = mutableListOf<String>()
        for (i in 0 until array.length()) {
            val name = array.optJSONObject(i)?.optString(key).orEmpty()
            if (name.isNotBlank() && name !in names) names.add(name)
        }
        return names.joinToString(", ")
    }
}

/** Decides whether an hour now holds a different subject than at the last check. */
object TimetableChanges {

    /**
     * Compares [lessons] (from the weeks in [fetchedDates]) with the last snapshot, saves the
     * new snapshot, and returns the before and after of every hour whose subject changed, from
     * [today] onwards (swapped with another hour or replaced by a new one). Everything else (a
     * room, a teacher, a substitute, a cancelled or added lesson) is recorded but stays silent.
     * The first call only records a baseline.
     */
    fun detect(
        context: Context,
        lessons: List<LessonInfo>,
        fetchedDates: Set<String>,
        today: String
    ): String? {
        val current = lessons.associate { "${it.date}|${it.hour}" to it.signature }
        val previous = ChangeTracker.getTimetableSnapshot(context)
        ChangeTracker.saveTimetableSnapshot(context, current)
        if (previous == null) return null

        fun subject(signature: String) = signature.substringBefore('|')

        val changed = current.keys
            .filter { key ->
                val date = key.substringBefore('|')
                val old = previous[key]
                date >= today && date in fetchedDates && old != null &&
                    subject(old).isNotBlank() && subject(current.getValue(key)).isNotBlank() &&
                    subject(old) != subject(current.getValue(key))
            }
            .sortedWith(compareBy({ it.substringBefore('|') }, { it.substringAfter('|').toIntOrNull() ?: 0 }))
        if (changed.isEmpty()) return null

        // One block per day: "Tomorrow" / "Before: 3 Maths, 5 English" / "After: 3 English, 5 Maths".
        return changed.groupBy { it.substringBefore('|') }.map { (date, keys) ->
            val day = TimetableParser.parseDate(date)?.let { DueDateFormat.dayLabel(it) } ?: date
            fun slots(map: Map<String, String>) = keys.joinToString(", ") { key ->
                "${key.substringAfter('|')} ${SubjectNames.nameFor(context, subject(map.getValue(key)))}"
            }
            "$day\nBefore: ${slots(previous)}\nAfter: ${slots(current)}"
        }.joinToString("\n\n")
    }
}
