package personal.digiregnotify

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LessonInfo(
    val date: String,      // yyyy-MM-dd
    val hour: Int,
    val time: String,      // "08:00–08:45"
    val subject: String,
    val rooms: String,
    val teachers: String,
    val isSubstitute: Boolean,
    val extras: String,    // homework/tests attached to this lesson, e.g. "Hausaufgabe"
    val toHour: Int = 0,   // last period it covers; a double hour has toHour = hour + 1 (0 = same as hour)
    val cancelled: Boolean = false // the school's own "cancelled" flag, if its reply has one
) {
    /**
     * True if the lesson is cancelled. The register has no obvious field for it: a cancelled
     * lesson usually just gets "Ausfall" (or similar) entered as its room. So the room is checked
     * for those words, besides the school's own flag.
     */
    val isCancelled: Boolean
        get() = cancelled || CancelWords.matches(rooms)

    /**
     * True if a test or exam is attached. It goes by the kind's name: "everything that isn't
     * homework" flagged a third of a normal week, so only the names of tests count now.
     */
    val hasExam: Boolean
        get() = extras.split(',').map { it.trim() }.any { ExamWords.matches(it) }

    /** What counts as "this lesson changed". Attached homework deliberately doesn't. */
    val signature: String get() = "$subject|$rooms|$teachers|$isSubstitute|$time|$isCancelled"
}

data class ParsedWeek(val dates: List<String>, val lessons: List<LessonInfo>)

sealed class TimetableRow {
    data class DayHeader(val label: String) : TimetableRow()
    data class Lesson(val info: LessonInfo) : TimetableRow()
    data class NoLessons(val text: String) : TimetableRow()
}

/**
 * Reads the reply of POST /api/calendar/student, which is shaped
 *   { "2026-09-28": { "1": { "1": { "<hour>": { isLesson, lesson: {...} } } } }, ... }
 */
object TimetableParser {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    @Synchronized // the format isn't thread-safe, and checks run off the main thread
    fun parseDate(raw: String): Date? = try {
        dateFormat.parse(raw)
    } catch (e: Exception) {
        null
    }

    fun parseWeek(json: String): ParsedWeek {
        val root = JSONObject(json)
        val dates = mutableListOf<String>()
        val lessons = mutableListOf<LessonInfo>()

        for (date in root.keys()) {
            dates.add(date)
            val day = root.optJSONObject(date) ?: continue
            val entries = mutableListOf<JSONObject>()
            collectEntries(day, entries)

            for (entry in entries) {
                if (entry.optInt("isLesson", 0) != 1) continue
                val lesson = entry.optJSONObject("lesson") ?: continue
                // The second hour of a double lesson is listed again; skip that duplicate.
                if (lesson.optInt("linkToPreviousHour", 0) != 0) continue

                val start = lesson.optJSONObject("timeStartObject")?.optString("text").orEmpty()
                val endObj = lesson.optJSONObject("timeToEndObject") ?: lesson.optJSONObject("timeEndObject")
                val end = endObj?.optString("text").orEmpty()
                val time = if (start.isNotEmpty() && end.isNotEmpty()) "$start–$end" else start

                lessons.add(
                    LessonInfo(
                        date = date,
                        hour = entry.optInt("hour", lesson.optInt("hour", 0)),
                        time = time,
                        subject = lesson.optJSONObject("subject")?.optString("name").orEmpty(),
                        rooms = joinNames(lesson.optJSONArray("rooms"), "name"),
                        teachers = joinNames(lesson.optJSONArray("teachers"), "lastName"),
                        isSubstitute = lesson.optInt("isSubstitute", 0) != 0,
                        extras = joinNames(lesson.optJSONArray("homeworkExams"), "typeName"),
                        toHour = lesson.optInt("toHour", 0),
                        cancelled = lesson.optInt("cancelled", 0) != 0 || lesson.optInt("isCancelled", 0) != 0
                    )
                )
            }
        }
        return ParsedWeek(dates.sorted(), lessons.sortedWith(compareBy({ it.date }, { it.hour })))
    }

    /** The reply nests entries a couple of levels deep; find every object that has "isLesson". */
    private fun collectEntries(node: JSONObject, out: MutableList<JSONObject>) {
        if (node.has("isLesson")) {
            out.add(node)
            return
        }
        for (key in node.keys()) {
            node.optJSONObject(key)?.let { collectEntries(it, out) }
        }
    }

    private fun joinNames(array: JSONArray?, key: String): String {
        if (array == null) return ""
        val names = mutableListOf<String>()
        for (i in 0 until array.length()) {
            val name = array.optJSONObject(i)?.optString(key).orEmpty()
            if (name.isNotBlank() && name !in names) names.add(name)
        }
        return names.joinToString(", ")
    }
}

/** Decides whether an hour now holds a different subject than at the last check. */
object TimetableChanges {

    /**
     * Compares [lessons] (from the weeks in [fetchedDates]) with the last snapshot, saves the
     * new snapshot, and returns what to tell the user, from [today] onwards: lessons that have
     * just been cancelled, and the before and after of every hour whose subject changed (swapped
     * with another hour or replaced by a new one). Everything else (a room, a teacher, a
     * substitute, an added lesson) is recorded but stays silent. The first call only records a
     * baseline.
     */
    fun detect(
        context: Context,
        lessons: List<LessonInfo>,
        fetchedDates: Set<String>,
        today: String
    ): String? {
        val current = lessons.associate { "${it.date}|${it.hour}" to it.signature }
        val previous = ChangeTracker.getTimetableSnapshot(context)
        ChangeTracker.saveTimetableSnapshot(context, current)
        if (previous == null) return null

        fun subject(signature: String) = signature.substringBefore('|')

        // A lesson that wasn't cancelled at the last check and is now (the school gives no
        // message for it; it only shows up as "Ausfall" in the room).
        fun cancelled(signature: String): Boolean {
            val parts = signature.split('|') // subject | rooms | teachers | substitute | time | cancelled
            return parts.getOrNull(5) == "true" || CancelWords.matches(parts.getOrElse(1) { "" })
        }
        fun upcoming(key: String) = key.substringBefore('|') >= today && key.substringBefore('|') in fetchedDates
        fun inOrder(keys: List<String>) = keys.sortedWith(
            compareBy({ it.substringBefore('|') }, { it.substringAfter('|').toIntOrNull() ?: 0 })
        )

        val newlyCancelled = inOrder(
            current.keys.filter { key ->
                val old = previous[key]
                upcoming(key) && old != null && !cancelled(old) && cancelled(current.getValue(key))
            }
        )
        val changed = inOrder(
            current.keys.filter { key ->
                val old = previous[key]
                upcoming(key) && key !in newlyCancelled && old != null &&
                    subject(old).isNotBlank() && subject(current.getValue(key)).isNotBlank() &&
                    subject(old) != subject(current.getValue(key))
            }
        )
        if (changed.isEmpty() && newlyCancelled.isEmpty()) return null

        fun dayOf(date: String) = TimetableParser.parseDate(date)?.let { DueDateFormat.dayLabel(it) } ?: date

        // One block per day: "Tomorrow" / "Cancelled: 3 Maths" ...
        val cancelledBlocks = newlyCancelled.groupBy { it.substringBefore('|') }.map { (date, keys) ->
            val slots = keys.joinToString(", ") { key ->
                "${key.substringAfter('|')} ${SubjectNames.nameFor(context, subject(current.getValue(key)))}"
            }
            "${dayOf(date)}\nCancelled: $slots"
        }
        // ... or "Tomorrow" / "Before: 3 Maths, 5 English" / "After: 3 English, 5 Maths".
        val changedBlocks = changed.groupBy { it.substringBefore('|') }.map { (date, keys) ->
            fun slots(map: Map<String, String>) = keys.joinToString(", ") { key ->
                "${key.substringAfter('|')} ${SubjectNames.nameFor(context, subject(map.getValue(key)))}"
            }
            "${dayOf(date)}\nBefore: ${slots(previous)}\nAfter: ${slots(current)}"
        }
        return (cancelledBlocks + changedBlocks).joinToString("\n\n")
    }
}

/** The names of kinds of entries that are tests or exams (as opposed to homework). */
object ExamWords {
    private val words = listOf(
        "schularbeit", "klassenarbeit", "test", "prüfung", "pruefung", "klausur",
        "überprüfung", "ueberpruefung", "kontrolle", "exam"
    )

    fun matches(type: String): Boolean = words.any { type.contains(it, ignoreCase = true) }
}

/** Words that mean a lesson is cancelled, as teachers write them where the room would go. */
object CancelWords {
    private val words = listOf(
        "ausfall", "entfall", "entfäll", "entfaell", "fällt aus", "faellt aus", "abgesagt",
        "cancelled", "canceled", "annullat", "soppress", "cancellat"
    )

    fun matches(text: String): Boolean = text.isNotBlank() && words.any { text.contains(it, ignoreCase = true) }
}
