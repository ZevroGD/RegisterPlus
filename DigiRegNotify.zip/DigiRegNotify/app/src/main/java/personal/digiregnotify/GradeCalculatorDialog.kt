package personal.digiregnotify

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import java.util.Locale

/**
 * The grade calculator for one subject. The maths is in GradeCalc; it uses the marks and
 * weights the school lists.
 *
 * Simple: what each mark on the next test would do to the average (a short table, nothing to set)
 * and the lowest mark that keeps the average. Always the whole year, one test, normal weight.
 * Advanced: pick year or a semester, how many tests are still to come and how much each counts,
 * set the average you want to see the mark you need, and slide a mark to see the new average.
 * The chosen mode is remembered.
 */
object GradeCalculatorDialog {

    private const val PREFS = "digireg_calculator"
    private const val KEY_ADVANCED = "advanced"
    private val GREEN = Color.parseColor("#43A047")
    private val RED = Color.parseColor("#EF5350")

    fun show(activity: Activity, summary: SubjectSummary, displayName: String) {
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val view = activity.layoutInflater.inflate(R.layout.dialog_grade_calculator, null)
        val modeToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.calcModeToggle)
        val scopeToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.calcScopeToggle)
        val currentText = view.findViewById<TextView>(R.id.calcCurrent)
        val noteText = view.findViewById<TextView>(R.id.calcNote)
        val simpleGroup = view.findViewById<View>(R.id.calcSimpleGroup)
        val advancedGroup = view.findViewById<View>(R.id.calcAdvancedGroup)
        val table = view.findViewById<LinearLayout>(R.id.calcTable)
        val needText = view.findViewById<TextView>(R.id.calcNeed)
        val goalText = view.findViewById<TextView>(R.id.calcGoal)
        val advNeedText = view.findViewById<TextView>(R.id.calcAdvNeed)
        val markLabel = view.findViewById<TextView>(R.id.calcMarkLabel)
        val slider = view.findViewById<Slider>(R.id.calcMarkSlider)
        val whatIfText = view.findViewById<TextView>(R.id.calcWhatIf)
        val countEdit = view.findViewById<EditText>(R.id.calcCount)
        val weightEdit = view.findViewById<EditText>(R.id.calcWeight)

        var advanced = prefs.getBoolean(KEY_ADVANCED, false)
        var scope = 0 // advanced only: 0 = whole year, 1 or 2 = that semester

        // The goal starts at the whole number you are at or just under (at least the pass mark 6),
        // so the first answer is a sensible one instead of "not possible".
        val startAverage = GradeCalc.totals(summary.grades).average
        var goal = if (startAverage == null || startAverage < 6.0) 6.0 else Math.floor(startAverage)

        fun num(d: Double): String = String.format(Locale.getDefault(), "%.2f", d)

        fun parse(edit: EditText): Double? =
            edit.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()

        fun goalLabel(g: Double): String =
            if (g == Math.floor(g)) g.toInt().toString()
            else String.format(Locale.getDefault(), "%.1f", g)

        fun showNote(current: Double?, atScope: Int) {
            // The school's own year average is the reference; say so if the two disagree.
            val schoolYear = summary.averageYear
            if (atScope == 0 && current != null && schoolYear != null && Math.abs(schoolYear - current) > 0.05) {
                noteText.text = "The school shows ${num(schoolYear.toDouble())}. " +
                    "This calculator uses the marks and weights listed, so it can differ a little."
                noteText.visibility = View.VISIBLE
            } else {
                noteText.visibility = View.GONE
            }
        }

        fun updateSimple() {
            val totals = GradeCalc.totals(summary.grades)
            val current = totals.average
            currentText.text = if (current == null) "–" else num(current)
            showNote(current, 0)

            table.removeAllViews()
            for (m in GradeCalc.MAX_MARK.toInt() downTo GradeCalc.MIN_MARK.toInt()) {
                val row = activity.layoutInflater.inflate(R.layout.item_grade_calc_row, table, false)
                val after = GradeCalc.averageWith(totals, m.toDouble(), 100.0, 1)
                row.findViewById<TextView>(R.id.calcRowMark).text = GradeFormat.format(m.toFloat())
                row.findViewById<TextView>(R.id.calcRowAverage).text = num(after)
                val diffView = row.findViewById<TextView>(R.id.calcRowDiff)
                if (current != null) {
                    val diff = after - current
                    when {
                        Math.abs(diff) < 0.005 -> {
                            diffView.text = "±0.00"
                            diffView.alpha = 0.6f
                        }
                        diff > 0 -> {
                            diffView.text = "+" + num(diff)
                            diffView.setTextColor(GREEN)
                        }
                        else -> {
                            diffView.text = "−" + num(-diff)
                            diffView.setTextColor(RED)
                        }
                    }
                }
                table.addView(row)
            }

            // One sentence under the table: what it takes to stay where you are (or, if you are
            // below it, to reach the pass mark 6).
            val target = if (current == null || current < 6.0) 6.0 else Math.floor(current)
            val label = goalLabel(target)
            val verb = if (current != null && current >= 6.0) "To stay at $label or above" else "To reach $label"
            needText.text = when (val need = GradeCalc.neededMark(totals, target, 100.0, 1)) {
                is GradeCalc.Need.AnyMark -> "$verb, any mark is enough."
                is GradeCalc.Need.Mark -> "$verb you need at least ${GradeFormat.format(need.rounded)} on the next test."
                is GradeCalc.Need.Unreachable -> "$verb is not possible with the next test."
            }
        }

        fun updateAdvanced() {
            val grades = if (scope == 0) summary.grades else summary.grades.filter { it.semester == scope }
            val totals = GradeCalc.totals(grades)
            val current = totals.average
            currentText.text = if (current == null) "–" else num(current)
            showNote(current, scope)
            goalText.text = goalLabel(goal)

            val mark = slider.value
            val count = countEdit.text?.toString()?.trim()?.toIntOrNull()
            val weight = parse(weightEdit)
            if (count == null || count < 1 || weight == null || weight <= 0.0) {
                markLabel.text = "If I get ${GradeFormat.format(mark)}"
                advNeedText.text = "Tests to come must be 1 or more, and the weight above 0."
                whatIfText.text = ""
                return
            }
            val testsWord = if (count == 1) "the next test" else "each of the next $count tests"
            val onTests = if (count == 1) "on the next test" else "on each of the next $count tests"

            advNeedText.text = when (val need = GradeCalc.neededMark(totals, goal, weight, count)) {
                is GradeCalc.Need.AnyMark -> "Any mark is enough."
                is GradeCalc.Need.Mark -> "You need at least ${GradeFormat.format(need.rounded)} $onTests."
                is GradeCalc.Need.Unreachable -> "Not possible with $testsWord: even a 10 is not enough."
            }

            markLabel.text = "If I get ${GradeFormat.format(mark)} $onTests"
            val after = GradeCalc.averageWith(totals, mark.toDouble(), weight, count)
            whatIfText.text = if (current == null) {
                "Your average would be ${num(after)}."
            } else {
                val diff = after - current
                val sign = if (diff >= 0) "+" else "−"
                "Your average becomes ${num(after)} ($sign${num(Math.abs(diff))})."
            }
        }

        fun update() {
            simpleGroup.visibility = if (advanced) View.GONE else View.VISIBLE
            advancedGroup.visibility = if (advanced) View.VISIBLE else View.GONE
            if (advanced) updateAdvanced() else updateSimple()
        }

        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        // Start on the nearest quarter mark to the current average.
        slider.value = if (startAverage == null) 8f
        else (Math.round(startAverage * 4) / 4f).coerceIn(4f, 10f)
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        slider.addOnChangeListener { _, _, _ -> update() }

        view.findViewById<View>(R.id.calcGoalMinus).setOnClickListener {
            goal = (goal - 0.5).coerceAtLeast(GradeCalc.MIN_MARK)
            update()
        }
        view.findViewById<View>(R.id.calcGoalPlus).setOnClickListener {
            goal = (goal + 0.5).coerceAtMost(GradeCalc.MAX_MARK)
            update()
        }

        watch(countEdit) { update() }
        watch(weightEdit) { update() }

        scopeToggle.check(R.id.calcScopeYear)
        scopeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            scope = when (checkedId) {
                R.id.calcScopeSem1 -> 1
                R.id.calcScopeSem2 -> 2
                else -> 0
            }
            update()
        }

        modeToggle.check(if (advanced) R.id.calcModeAdvanced else R.id.calcModeSimple)
        modeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            advanced = checkedId == R.id.calcModeAdvanced
            prefs.edit().putBoolean(KEY_ADVANCED, advanced).apply()
            update()
        }

        update()

        SlideDialogBuilder(activity)
            .setTitle(displayName)
            .setView(ScrollView(activity).apply { addView(view) })
            .setPositiveButton("Close", null)
            .show()
    }

    private fun watch(edit: EditText, onChange: () -> Unit) {
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange()
        })
    }
}
