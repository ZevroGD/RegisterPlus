package personal.digiregnotify

import android.app.Activity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import java.util.Locale

/**
 * "What do I need?" and "What if?" for one subject, worked out from the marks and weights the
 * school lists (see GradeCalc). Pick the whole year or one semester, then either enter the
 * average you want and read off the mark you need, or slide a mark and read off the new average.
 */
object GradeCalculatorDialog {

    fun show(activity: Activity, summary: SubjectSummary, displayName: String) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_grade_calculator, null)
        val scopeToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.calcScopeToggle)
        val modeToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.calcModeToggle)
        val currentText = view.findViewById<TextView>(R.id.calcCurrent)
        val noteText = view.findViewById<TextView>(R.id.calcNote)
        val targetGroup = view.findViewById<View>(R.id.calcTargetGroup)
        val markGroup = view.findViewById<View>(R.id.calcMarkGroup)
        val markLabel = view.findViewById<TextView>(R.id.calcMarkLabel)
        val slider = view.findViewById<Slider>(R.id.calcMarkSlider)
        val targetEdit = view.findViewById<EditText>(R.id.calcTarget)
        val countEdit = view.findViewById<EditText>(R.id.calcCount)
        val weightEdit = view.findViewById<EditText>(R.id.calcWeight)
        val resultText = view.findViewById<TextView>(R.id.calcResult)
        val detailText = view.findViewById<TextView>(R.id.calcResultDetail)

        var scope = 0 // 0 = whole year, 1 or 2 = that semester
        var whatIf = false

        fun gradesInScope(): List<SubjectGrade> =
            if (scope == 0) summary.grades else summary.grades.filter { it.semester == scope }

        fun num(d: Double): String = String.format(Locale.getDefault(), "%.2f", d)

        fun parse(edit: EditText): Double? =
            edit.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()

        fun update() {
            val grades = gradesInScope()
            val totals = GradeCalc.totals(grades)
            val current = totals.average

            currentText.text = if (current == null) {
                "No marks in this period yet"
            } else {
                "Current average ${num(current)} · " + if (grades.size == 1) "1 mark" else "${grades.size} marks"
            }

            // The school's own year average is the reference; say so if the two disagree.
            val schoolYear = summary.averageYear
            if (scope == 0 && current != null && schoolYear != null && Math.abs(schoolYear - current) > 0.05) {
                noteText.text = "The school shows ${num(schoolYear.toDouble())} for the year. " +
                    "The calculator uses the marks and weights listed here, so its numbers can differ a little."
                noteText.visibility = View.VISIBLE
            } else {
                noteText.visibility = View.GONE
            }

            val count = countEdit.text?.toString()?.trim()?.toIntOrNull()
            val weight = parse(weightEdit)
            if (count == null || count < 1 || weight == null || weight <= 0.0) {
                resultText.text = "–"
                detailText.text = "Enter how many marks are still to come (1 or more) and their weight (above 0)."
                return
            }
            val marksWord = if (count == 1) "the next mark" else "each of the next $count marks"

            if (!whatIf) {
                val target = parse(targetEdit)
                if (target == null || target < GradeCalc.MIN_MARK || target > GradeCalc.MAX_MARK) {
                    resultText.text = "–"
                    detailText.text = "Enter the average you want, between 1 and 10."
                    return
                }
                when (val need = GradeCalc.neededMark(totals, target, weight, count)) {
                    is GradeCalc.Need.AnyMark -> {
                        resultText.text = "Any mark"
                        detailText.text = "You reach ${num(target)} even with the lowest mark."
                    }
                    is GradeCalc.Need.Mark -> {
                        resultText.text = "Need ${GradeFormat.format(need.rounded)}"
                        val reached = GradeCalc.averageWith(totals, need.rounded.toDouble(), weight, count)
                        detailText.text = "On $marksWord. Exactly ${num(need.exact)}; " +
                            "${GradeFormat.format(need.rounded)} is the next mark on the school's scale " +
                            "and gives an average of ${num(reached)}."
                    }
                    is GradeCalc.Need.Unreachable -> {
                        resultText.text = "Not reachable"
                        val best = GradeCalc.averageWith(totals, GradeCalc.MAX_MARK, weight, count)
                        detailText.text = "Even a 10 on $marksWord only gives ${num(best)}. " +
                            "You would need ${num(need.exact)}."
                    }
                }
            } else {
                val mark = slider.value.toDouble()
                markLabel.text = "If $marksWord is ${GradeFormat.format(slider.value)}"
                val after = GradeCalc.averageWith(totals, mark, weight, count)
                resultText.text = "Average ${num(after)}"
                detailText.text = if (current == null) {
                    "That would be your first marks in this period."
                } else {
                    val diff = after - current
                    val sign = if (diff >= 0) "+" else "−"
                    "Now ${num(current)}, so ${sign}${num(Math.abs(diff))}."
                }
            }
        }

        // Starting target: the pass mark, or the next whole number above a good average.
        val startAverage = GradeCalc.totals(summary.grades).average
        val startTarget = if (startAverage == null || startAverage < 6.0) 6.0
        else Math.floor(startAverage).coerceAtMost(9.0) + 1.0
        targetEdit.setText(String.format(Locale.US, "%.1f", startTarget))

        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        slider.value = 6f
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        slider.addOnChangeListener { _, _, _ -> update() }

        watch(targetEdit) { update() }
        watch(countEdit) { update() }
        watch(weightEdit) { update() }

        scopeToggle.check(R.id.calcScopeYear)
        scopeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            scope = when (checkedId) {
                R.id.calcScopeSem1 -> 1
                R.id.calcScopeSem2 -> 2
                else -> 0
            }
            update()
        }

        modeToggle.check(R.id.calcModeTarget)
        modeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            whatIf = checkedId == R.id.calcModeWhatIf
            targetGroup.visibility = if (whatIf) View.GONE else View.VISIBLE
            markGroup.visibility = if (whatIf) View.VISIBLE else View.GONE
            update()
        }

        update()

        SlideDialogBuilder(activity)
            .setTitle(displayName)
            .setView(ScrollView(activity).apply { addView(view) })
            .setPositiveButton("Close", null)
            .show()
    }

    private fun watch(edit: EditText, onChange: () -> Unit) {
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange()
        })
    }
}
