package personal.digiregnotify

import android.app.Activity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import java.util.Locale

/**
 * Two plain questions about one subject, worked out from the marks and weights the school
 * lists (see GradeCalc): "which mark do I need for the average I want?" and "what happens to my
 * average if I get this mark?". Tests still to come, their weight and year-or-semester are
 * tucked away under "More options" because most people never need them.
 */
object GradeCalculatorDialog {

    fun show(activity: Activity, summary: SubjectSummary, displayName: String) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_grade_calculator, null)
        val scopeToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.calcScopeToggle)
        val currentText = view.findViewById<TextView>(R.id.calcCurrent)
        val noteText = view.findViewById<TextView>(R.id.calcNote)
        val goalText = view.findViewById<TextView>(R.id.calcGoal)
        val needText = view.findViewById<TextView>(R.id.calcNeed)
        val markLabel = view.findViewById<TextView>(R.id.calcMarkLabel)
        val slider = view.findViewById<Slider>(R.id.calcMarkSlider)
        val whatIfText = view.findViewById<TextView>(R.id.calcWhatIf)
        val moreToggle = view.findViewById<TextView>(R.id.calcMoreToggle)
        val moreGroup = view.findViewById<View>(R.id.calcMoreGroup)
        val countEdit = view.findViewById<EditText>(R.id.calcCount)
        val weightEdit = view.findViewById<EditText>(R.id.calcWeight)

        var scope = 0 // 0 = whole year, 1 or 2 = that semester

        // Start at the whole number you are at or just under (at least the pass mark), so the
        // first answer is a sensible one instead of "not reachable".
        val startAverage = GradeCalc.totals(summary.grades).average
        var goal = if (startAverage == null || startAverage < 6.0) 6.0 else Math.floor(startAverage)

        fun gradesInScope(): List<SubjectGrade> =
            if (scope == 0) summary.grades else summary.grades.filter { it.semester == scope }

        fun num(d: Double): String = String.format(Locale.getDefault(), "%.2f", d)

        fun goalLabel(): String =
            if (goal == Math.floor(goal)) goal.toInt().toString()
            else String.format(Locale.getDefault(), "%.1f", goal)

        fun parse(edit: EditText): Double? =
            edit.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()

        fun update() {
            val grades = gradesInScope()
            val totals = GradeCalc.totals(grades)
            val current = totals.average

            currentText.text = if (current == null) "–" else num(current)
            goalText.text = goalLabel()

            // The school's own year average is the reference; say so if the two disagree.
            val schoolYear = summary.averageYear
            if (scope == 0 && current != null && schoolYear != null && Math.abs(schoolYear - current) > 0.05) {
                noteText.text = "The school shows ${num(schoolYear.toDouble())}. " +
                    "This calculator uses the marks and weights listed, so it can differ a little."
                noteText.visibility = View.VISIBLE
            } else {
                noteText.visibility = View.GONE
            }

            val mark = slider.value
            val count = countEdit.text?.toString()?.trim()?.toIntOrNull()
            val weight = parse(weightEdit)
            if (count == null || count < 1 || weight == null || weight <= 0.0) {
                markLabel.text = "If I get ${GradeFormat.format(mark)}"
                needText.text = "Check “More options”: tests to come must be 1 or more, weight above 0."
                whatIfText.text = ""
                return
            }
            val testsWord = if (count == 1) "the next test" else "each of the next $count tests"
            val onTests = if (count == 1) "on the next test" else "on each of the next $count tests"

            when (val need = GradeCalc.neededMark(totals, goal, weight, count)) {
                is GradeCalc.Need.AnyMark ->
                    needText.text = "Any mark is enough."
                is GradeCalc.Need.Mark ->
                    needText.text = "You need at least ${GradeFormat.format(need.rounded)} $onTests."
                is GradeCalc.Need.Unreachable ->
                    needText.text = "Not possible with $testsWord: even a 10 is not enough."
            }

            markLabel.text = "If I get ${GradeFormat.format(mark)} $onTests"
            val after = GradeCalc.averageWith(totals, mark.toDouble(), weight, count)
            whatIfText.text = if (current == null) {
                "Your average would be ${num(after)}."
            } else {
                val diff = after - current
                val sign = if (diff >= 0) "+" else "−"
                "Your average becomes ${num(after)} ($sign${num(Math.abs(diff))})."
            }
        }

        slider.valueFrom = GradeCalc.MIN_MARK.toFloat()
        slider.valueTo = GradeCalc.MAX_MARK.toFloat()
        slider.stepSize = 0.25f
        // Start on the nearest quarter mark to the current average.
        slider.value = if (startAverage == null) 8f
        else (Math.round(startAverage * 4) / 4f).coerceIn(1f, 10f)
        slider.setLabelFormatter { v -> GradeFormat.format(v) }
        slider.addOnChangeListener { _, _, _ -> update() }

        view.findViewById<View>(R.id.calcGoalMinus).setOnClickListener {
            goal = (goal - 0.5).coerceAtLeast(GradeCalc.MIN_MARK)
            update()
        }
        view.findViewById<View>(R.id.calcGoalPlus).setOnClickListener {
            goal = (goal + 0.5).coerceAtMost(GradeCalc.MAX_MARK)
            update()
        }

        watch(countEdit) { update() }
        watch(weightEdit) { update() }

        moreToggle.setOnClickListener {
            val open = moreGroup.visibility != View.VISIBLE
            moreGroup.visibility = if (open) View.VISIBLE else View.GONE
            moreToggle.text = if (open) "Fewer options ▴" else "More options ▾"
        }

        scopeToggle.check(R.id.calcScopeYear)
        scopeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            scope = when (checkedId) {
                R.id.calcScopeSem1 -> 1
                R.id.calcScopeSem2 -> 2
                else -> 0
            }
            update()
        }

        update()

        SlideDialogBuilder(activity)
            .setTitle(displayName)
            .setView(ScrollView(activity).apply { addView(view) })
            .setPositiveButton("Close", null)
            .show()
    }

    private fun watch(edit: EditText, onChange: () -> Unit) {
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange()
        })
    }
}
