package personal.digiregnotify

import android.app.Activity
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.button.MaterialButtonToggleGroup
import java.util.Locale

/**
 * Shows, for one subject, what each possible mark on the next test would do to the average
 * (a short table, no controls) and the lowest mark that keeps or reaches a sensible average.
 * Year or semester, the number of tests still to come and their weight are tucked away under
 * "More options". The maths is in GradeCalc; it uses the marks and weights the school lists.
 */
object GradeCalculatorDialog {

    private val GREEN = Color.parseColor("#43A047")
    private val RED = Color.parseColor("#EF5350")

    fun show(activity: Activity, summary: SubjectSummary, displayName: String) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_grade_calculator, null)
        val scopeToggle = view.findViewById<MaterialButtonToggleGroup>(R.id.calcScopeToggle)
        val currentText = view.findViewById<TextView>(R.id.calcCurrent)
        val noteText = view.findViewById<TextView>(R.id.calcNote)
        val tableTitle = view.findViewById<TextView>(R.id.calcTableTitle)
        val table = view.findViewById<LinearLayout>(R.id.calcTable)
        val needText = view.findViewById<TextView>(R.id.calcNeed)
        val moreToggle = view.findViewById<TextView>(R.id.calcMoreToggle)
        val moreGroup = view.findViewById<View>(R.id.calcMoreGroup)
        val countEdit = view.findViewById<EditText>(R.id.calcCount)
        val weightEdit = view.findViewById<EditText>(R.id.calcWeight)

        var scope = 0 // 0 = whole year, 1 or 2 = that semester

        fun gradesInScope(): List<SubjectGrade> =
            if (scope == 0) summary.grades else summary.grades.filter { it.semester == scope }

        fun num(d: Double): String = String.format(Locale.getDefault(), "%.2f", d)

        fun parse(edit: EditText): Double? =
            edit.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()

        fun update() {
            val grades = gradesInScope()
            val totals = GradeCalc.totals(grades)
            val current = totals.average

            currentText.text = if (current == null) "–" else num(current)

            // The school's own year average is the reference; say so if the two disagree.
            val schoolYear = summary.averageYear
            if (scope == 0 && current != null && schoolYear != null && Math.abs(schoolYear - current) > 0.05) {
                noteText.text = "The school shows ${num(schoolYear.toDouble())}. " +
                    "This calculator uses the marks and weights listed, so it can differ a little."
                noteText.visibility = View.VISIBLE
            } else {
                noteText.visibility = View.GONE
            }

            table.removeAllViews()
            val count = countEdit.text?.toString()?.trim()?.toIntOrNull()
            val weight = parse(weightEdit)
            if (count == null || count < 1 || weight == null || weight <= 0.0) {
                tableTitle.text = ""
                needText.text = "Check “More options”: tests to come must be 1 or more, weight above 0."
                return
            }
            val testsWord = if (count == 1) "the next test" else "each of the next $count tests"
            tableTitle.text = "If you get this on $testsWord:"

            for (m in GradeCalc.MAX_MARK.toInt() downTo GradeCalc.MIN_MARK.toInt()) {
                val row = activity.layoutInflater.inflate(R.layout.item_grade_calc_row, table, false)
                val after = GradeCalc.averageWith(totals, m.toDouble(), weight, count)
                row.findViewById<TextView>(R.id.calcRowMark).text = GradeFormat.format(m.toFloat())
                row.findViewById<TextView>(R.id.calcRowAverage).text = num(after)
                val diffView = row.findViewById<TextView>(R.id.calcRowDiff)
                if (current != null) {
                    val diff = after - current
                    when {
                        Math.abs(diff) < 0.005 -> {
                            diffView.text = "±0.00"
                            diffView.alpha = 0.6f
                        }
                        diff > 0 -> {
                            diffView.text = "+" + num(diff)
                            diffView.setTextColor(GREEN)
                        }
                        else -> {
                            diffView.text = "−" + num(-diff)
                            diffView.setTextColor(RED)
                        }
                    }
                }
                table.addView(row)
            }

            // One sentence on top of the table: what it takes to stay where you are (or, if you
            // are below it, to reach the pass mark 6).
            val goal = if (current == null || current < 6.0) 6.0 else Math.floor(current)
            val goalLabel = goal.toInt().toString()
            val onTests = if (count == 1) "on the next test" else "on each of the next $count tests"
            val verb = if (current != null && current >= 6.0) "To stay at $goalLabel or above" else "To reach $goalLabel"
            needText.text = when (val need = GradeCalc.neededMark(totals, goal, weight, count)) {
                is GradeCalc.Need.AnyMark -> "$verb, any mark is enough."
                is GradeCalc.Need.Mark -> "$verb you need at least ${GradeFormat.format(need.rounded)} $onTests."
                is GradeCalc.Need.Unreachable -> "$verb is not possible with $testsWord."
            }
        }

        watch(countEdit) { update() }
        watch(weightEdit) { update() }

        moreToggle.setOnClickListener {
            val open = moreGroup.visibility != View.VISIBLE
            moreGroup.visibility = if (open) View.VISIBLE else View.GONE
            moreToggle.text = if (open) "Fewer options ▴" else "More options ▾"
        }

        scopeToggle.check(R.id.calcScopeYear)
        scopeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            scope = when (checkedId) {
                R.id.calcScopeSem1 -> 1
                R.id.calcScopeSem2 -> 2
                else -> 0
            }
            update()
        }

        update()

        SlideDialogBuilder(activity)
            .setTitle(displayName)
            .setView(ScrollView(activity).apply { addView(view) })
            .setPositiveButton("Close", null)
            .show()
    }

    private fun watch(edit: EditText, onChange: () -> Unit) {
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange()
        })
    }
}
