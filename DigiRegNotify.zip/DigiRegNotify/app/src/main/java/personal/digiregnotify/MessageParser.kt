package personal.digiregnotify

import org.json.JSONArray
import org.json.JSONObject

data class MessageSummary(
    val id: Long,
    val fromName: String,
    val subject: String,
    val timeSent: String,
    val isUnread: Boolean,
    val bodyPreview: String,
    val fullBody: String,
    val submissions: List<Submission> = emptyList()
)

object MessageParser {

    /** Only messages actually sent TO you — your own sent copies ("outgoing") are excluded,
     *  since there's nothing to read there and they shouldn't count as "new" (confirmed via
     *  label_incoming/label_outgoing; a sent copy never gets timeRead set, so without this
     *  filter it would look unread forever — the real site has this same data quirk but
     *  just doesn't surface it as a notification, which is what we're matching here). */
    fun parse(json: String): List<MessageSummary> {
        val array = JSONArray(json)
        val result = mutableListOf<MessageSummary>()
        for (i in 0 until array.length()) {
            val m = array.optJSONObject(i) ?: continue
            if (m.optBoolean("label_outgoing", false)) continue
            if (m.optInt("deleted", 0) != 0) continue

            val fullBody = extractPlainText(m.optString("text"))
            result.add(
                MessageSummary(
                    id = m.optLong("id"),
                    fromName = m.optString("fromName"),
                    subject = m.optString("subject"),
                    timeSent = m.optString("timeSent"),
                    isUnread = m.isNull("timeRead") || !m.has("timeRead"),
                    bodyPreview = fullBody.take(180),
                    fullBody = fullBody,
                    submissions = Submission.parseList(m.optJSONArray("submissions"), "messageId")
                )
            )
        }
        // Newest first.
        return result.sortedByDescending { it.timeSent }
    }

    /** The body is Quill "delta" JSON ({"ops":[{"insert":"..."},...]}) — pull the plain text out. */
    private fun extractPlainText(deltaJson: String): String {
        if (deltaJson.isBlank()) return ""
        return try {
            val ops = JSONObject(deltaJson).optJSONArray("ops") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until ops.length()) {
                val insert = ops.optJSONObject(i)?.opt("insert")
                if (insert is String) sb.append(insert)
            }
            sb.toString().replace(Regex("\\n{3,}"), "\n\n").trim()
        } catch (e: Exception) {
            deltaJson.take(2000) // not delta JSON after all — show it raw rather than nothing
        }
    }
}
