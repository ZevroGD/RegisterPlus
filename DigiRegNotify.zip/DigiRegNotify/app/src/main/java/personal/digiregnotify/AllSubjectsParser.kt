package personal.digiregnotify

import org.json.JSONObject

data class SubjectGrade(
    val value: Float,
    val date: String,
    val type: String,
    val weight: Int,
    val description: String = ""
)

/** An entry the school lists with the grades but without a mark (e.g. an observation). */
data class UnmarkedEntry(
    val date: String,
    val type: String,
    val description: String
)

data class SubjectSummary(
    val name: String,
    val subjectId: Int,
    val grades: List<SubjectGrade>, // sorted oldest -> newest
    val averageSemester: Float?,
    val averageYear: Float?,
    val countObservations: Int = 0, // teacher observations; their details come from subject_detail
    val unmarked: List<UnmarkedEntry> = emptyList() // listed with the grades, but no mark; oldest -> newest
)

/** Reads the reply of POST /api/student/all_subjects. */
object AllSubjectsParser {

    fun parse(json: String): List<SubjectSummary> {
        val root = JSONObject(json)
        val subjectsArray = root.optJSONArray("subjects") ?: return emptyList()

        val result = mutableListOf<SubjectSummary>()
        for (i in 0 until subjectsArray.length()) {
            val s = subjectsArray.optJSONObject(i) ?: continue
            val name = s.optJSONObject("subject")?.optString("name").orEmpty()
            val subjectId = s.optInt("subjectId", -1)

            val gradesArray = s.optJSONArray("grades")
            val grades = mutableListOf<SubjectGrade>()
            val unmarked = mutableListOf<UnmarkedEntry>()
            if (gradesArray != null) {
                for (j in 0 until gradesArray.length()) {
                    val g = gradesArray.optJSONObject(j) ?: continue
                    if (g.optInt("cancelled", 0) != 0) continue // voided grade, don't count it
                    val value = parseGradeValue(g.optString("grade"))
                    if (value == null) {
                        // No mark (it can't go in the chart or the average), but it is still
                        // something the school entered, so it must not just disappear.
                        unmarked.add(
                            UnmarkedEntry(
                                date = g.optString("date"),
                                type = g.optString("type").trim(),
                                description = g.optString("description").trim()
                            )
                        )
                        continue
                    }
                    grades.add(
                        SubjectGrade(
                            value = value,
                            date = g.optString("date"),
                            type = g.optString("type"),
                            weight = g.optInt("weight", 100),
                            description = g.optString("description").trim()
                        )
                    )
                }
            }
            grades.sortBy { it.date }
            unmarked.sortBy { it.date }

            result.add(
                SubjectSummary(
                    name = name,
                    subjectId = subjectId,
                    grades = grades,
                    averageSemester = optFloatOrNull(s, "averageSemester"),
                    averageYear = optFloatOrNull(s, "averageYear"),
                    countObservations = s.optInt("countObservations", 0),
                    unmarked = unmarked
                )
            )
        }
        return result
    }

    /** Handles both "8.75" and German-style "8,75"; "-" or blank means no value. */
    private fun parseGradeValue(raw: String?): Float? {
        if (raw.isNullOrBlank() || raw == "-") return null
        return raw.replace(",", ".").toFloatOrNull()
    }

    private fun optFloatOrNull(obj: JSONObject, key: String): Float? {
        if (!obj.has(key) || obj.isNull(key)) return null
        val raw = obj.opt(key)
        return when (raw) {
            is Number -> raw.toFloat()
            is String -> parseGradeValue(raw)
            else -> null
        }
    }

    /** Combines two semesters' subject lists by subjectId, concatenating grade history. */
    fun merge(a: List<SubjectSummary>, b: List<SubjectSummary>): List<SubjectSummary> {
        val byId = LinkedHashMap<Int, SubjectSummary>()
        for (s in a) byId[s.subjectId] = s
        for (s in b) {
            val existing = byId[s.subjectId]
            byId[s.subjectId] = if (existing == null) {
                s
            } else {
                existing.copy(
                    grades = (existing.grades + s.grades).sortedBy { it.date },
                    unmarked = (existing.unmarked + s.unmarked).sortedBy { it.date },
                    averageYear = existing.averageYear ?: s.averageYear
                )
            }
        }
        return byId.values.toList()
    }
}
