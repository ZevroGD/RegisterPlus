package personal.digiregnotify

import org.json.JSONObject

data class SubjectGrade(
    val value: Float,
    val date: String,
    val type: String,
    val weight: Int,
    val description: String = "",
    val semester: Int = 0, // 1 or 2 when known (the edit screen can then work per semester)
    val name: String = "", // the mark's title, e.g. "first grammar test"; only on the subject's page
    val typeId: String = "", // with the date, mark, weight and creation time: finds the same mark on
    val created: String = "" // the subject's page (see MarkNames)
) {
    /** Type, title and description as one line, e.g. "Test · first vocabulary test". */
    val title: String
        get() = listOf(type, name, description).map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" · ")
}

/** An entry the school lists with the grades but without a mark (e.g. an observation). */
data class UnmarkedEntry(
    val date: String,
    val type: String,
    val description: String
)

data class SubjectSummary(
    val name: String,
    val subjectId: Int,
    val grades: List<SubjectGrade>, // sorted oldest -> newest
    val averageSemester: Float?,
    val averageYear: Float?,
    val countObservations: Int = 0, // teacher observations; their details come from subject_detail
    val unmarked: List<UnmarkedEntry> = emptyList() // listed with the grades, but no mark; oldest -> newest
)

/** Reads the reply of POST /api/student/all_subjects. */
object AllSubjectsParser {

    fun parse(json: String, semester: Int = 0): List<SubjectSummary> {
        val root = JSONObject(json)
        val subjectsArray = root.optJSONArray("subjects") ?: return emptyList()

        val result = mutableListOf<SubjectSummary>()
        for (i in 0 until subjectsArray.length()) {
            val s = subjectsArray.optJSONObject(i) ?: continue
            val name = s.optJSONObject("subject")?.optString("name").orEmpty()
            val subjectId = s.optInt("subjectId", -1)

            val gradesArray = s.optJSONArray("grades")
            val grades = mutableListOf<SubjectGrade>()
            val unmarked = mutableListOf<UnmarkedEntry>()
            if (gradesArray != null) {
                for (j in 0 until gradesArray.length()) {
                    val g = gradesArray.optJSONObject(j) ?: continue
                    if (g.optInt("cancelled", 0) != 0) continue // voided grade, don't count it
                    val value = parseGradeValue(g.optString("grade"))
                    if (value == null) {
                        // No mark (it can't go in the chart or the average), but it is still
                        // something the school entered, so it must not just disappear.
                        unmarked.add(
                            UnmarkedEntry(
                                date = g.optString("date"),
                                type = g.optString("type").trim(),
                                description = g.optString("description").trim()
                            )
                        )
                        continue
                    }
                    grades.add(
                        SubjectGrade(
                            value = value,
                            date = g.optString("date"),
                            type = g.optString("type"),
                            weight = g.optInt("weight", 100),
                            description = g.optString("description").trim(),
                            semester = semester,
                            typeId = g.optString("typeId"),
                            created = g.optString("createdTimeStamp")
                        )
                    )
                }
            }
            grades.sortBy { it.date }
            unmarked.sortBy { it.date }

            result.add(
                SubjectSummary(
                    name = name,
                    subjectId = subjectId,
                    grades = grades,
                    averageSemester = optFloatOrNull(s, "averageSemester"),
                    averageYear = optFloatOrNull(s, "averageYear"),
                    countObservations = s.optInt("countObservations", 0),
                    unmarked = unmarked
                )
            )
        }
        return result
    }

    /** Handles both "8.75" and German-style "8,75"; "-" or blank means no value. */
    fun parseGradeValue(raw: String?): Float? {
        if (raw.isNullOrBlank() || raw == "-") return null
        return raw.replace(",", ".").toFloatOrNull()
    }

    private fun optFloatOrNull(obj: JSONObject, key: String): Float? {
        if (!obj.has(key) || obj.isNull(key)) return null
        val raw = obj.opt(key)
        return when (raw) {
            is Number -> raw.toFloat()
            is String -> parseGradeValue(raw)
            else -> null
        }
    }

    /** Combines two semesters' subject lists by subjectId, concatenating grade history. */
    fun merge(a: List<SubjectSummary>, b: List<SubjectSummary>): List<SubjectSummary> {
        val byId = LinkedHashMap<Int, SubjectSummary>()
        for (s in a) byId[s.subjectId] = s
        for (s in b) {
            val existing = byId[s.subjectId]
            byId[s.subjectId] = if (existing == null) {
                s
            } else {
                existing.copy(
                    grades = (existing.grades + s.grades).sortedBy { it.date },
                    unmarked = (existing.unmarked + s.unmarked).sortedBy { it.date },
                    averageYear = existing.averageYear ?: s.averageYear
                )
            }
        }
        return byId.values.toList()
    }
}
