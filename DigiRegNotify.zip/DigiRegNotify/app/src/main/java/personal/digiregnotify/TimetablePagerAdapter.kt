package personal.digiregnotify

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.widget.TextViewCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.color.MaterialColors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** What a week page currently holds. */
sealed class WeekState {
    object Loading : WeekState()
    /** [note] is set when this is a stored copy (offline / school unreachable): shown greyed out. */
    data class Loaded(val week: ParsedWeek, val note: String? = null) : WeekState()
    data class Failed(val message: String) : WeekState()
}

/**
 * One page per week, so weeks can be swiped through smoothly (the pages snap into place).
 * Page [BASE] is the current week; there are [PAGES] pages in all, a year either side.
 * A page draws its own grid: periods down the side, days across the top, and lesson tiles whose
 * height follows the periods they cover (a double hour is twice as tall), filling the screen.
 */
class TimetablePagerAdapter(
    private val baseMonday: Calendar,
    private val states: Map<String, WeekState>,
    private val onNeedWeek: (Int) -> Unit,
    private val onRefresh: (Int) -> Unit,
    private val onLesson: (LessonInfo) -> Unit
) : RecyclerView.Adapter<TimetablePagerAdapter.PageHolder>() {

    companion object {
        const val PAGES = 105
        const val BASE = 52
        private val iso = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        private val EXAM_RED = Color.rgb(255, 59, 48)
    }

    class PageHolder(view: View) : RecyclerView.ViewHolder(view) {
        val refresh: SwipeRefreshLayout = view.findViewById(R.id.weekRefresh)
        val header: LinearLayout = view.findViewById(R.id.weekHeader)
        val body: LinearLayout = view.findViewById(R.id.weekBody)
        val message: TextView = view.findViewById(R.id.weekMessage)
        val note: TextView = view.findViewById(R.id.weekNote)
    }

    fun mondayFor(position: Int): Calendar =
        (baseMonday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, (position - BASE) * 7) }

    fun keyFor(position: Int): String = iso.format(mondayFor(position).time)

    /** Monday to Saturday of the week on [position], as "yyyy-MM-dd". */
    private fun weekDates(position: Int): List<String> {
        val monday = mondayFor(position)
        return (0..5).map { i ->
            iso.format((monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }.time)
        }
    }

    override fun getItemCount() = PAGES

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder =
        PageHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_timetable_week, parent, false))

    override fun onBindViewHolder(holder: PageHolder, position: Int) {
        val state = states[keyFor(position)]
        holder.refresh.setOnRefreshListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onRefresh(pos)
        }
        holder.header.removeAllViews()
        holder.body.removeAllViews()
        holder.message.visibility = View.GONE
        // A stored copy is shown greyed out, with a line saying when it was saved.
        val stored = (state as? WeekState.Loaded)?.note
        holder.note.text = stored
        holder.note.visibility = if (stored != null) View.VISIBLE else View.GONE
        val dim = if (stored != null) 0.55f else 1f
        holder.header.alpha = dim
        holder.body.alpha = dim

        when (state) {
            null -> {
                // Not requested yet: ask for it once the list has finished laying out.
                holder.refresh.isRefreshing = true
                holder.itemView.post { onNeedWeek(position) }
            }
            is WeekState.Loading -> holder.refresh.isRefreshing = true
            is WeekState.Failed -> {
                holder.refresh.isRefreshing = false
                holder.message.text = state.message
                holder.message.visibility = View.VISIBLE
            }
            is WeekState.Loaded -> {
                holder.refresh.isRefreshing = false
                // A week without lessons still gets its grid: every weekday shows as free (with the
                // holiday or break, if one is known). If the reply listed no dates, use Mon-Sat.
                val week = state.week
                buildGrid(holder, if (week.dates.isEmpty()) ParsedWeek(weekDates(position), week.lessons) else week)
            }
        }
    }

    private fun buildGrid(holder: PageHolder, week: ParsedWeek) {
        val ctx = holder.itemView.context
        val density = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        fun themeColor(attr: Int) = MaterialColors.getColor(holder.itemView, attr, Color.GRAY)
        val onBackground = themeColor(com.google.android.material.R.attr.colorOnBackground)
        val primary = themeColor(com.google.android.material.R.attr.colorPrimary)
        val periodWidth = dp(38)
        val today = iso.format(Date())

        // --- Header: weekday and date, with today picked out ---
        holder.header.addView(View(ctx), LinearLayout.LayoutParams(periodWidth, dp(8)))
        for (dateStr in week.dates) {
            val date = TimetableParser.parseDate(dateStr)
            val isToday = dateStr == today
            val cell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2); marginEnd = dp(2); bottomMargin = dp(6)
                }
                gravity = Gravity.CENTER
                textSize = 12f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                text = date?.let {
                    SimpleDateFormat("EEE", Locale.getDefault()).format(it) + "\n" +
                        SimpleDateFormat("d", Locale.getDefault()).format(it)
                } ?: dateStr
                setPadding(dp(2), dp(6), dp(2), dp(6))
                if (isToday) {
                    setTextColor(primary)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(ColorUtils.setAlphaComponent(primary, 40))
                    }
                } else {
                    setTextColor(onBackground)
                    alpha = 0.75f
                }
            }
            holder.header.addView(cell)
        }

        // --- Body ---
        // A column of period labels, then one column per day. Every row is one unit of height and
        // a lesson is as tall as the rows it covers, so a double hour is a tall tile; the gaps
        // between lessons are spacers of the right size. Every period from the 1st to the last one
        // that has a lesson gets a row, with the school's real period number, so a period that is
        // empty on every day is a blank row (not skipped). Nothing is shown after the last lesson.
        // (A week with no lessons at all gets six rows so the free days have some height.)
        val firstPeriod = if (week.lessons.isEmpty()) 1 else minOf(1, week.lessons.minOf { it.hour })
        val lastPeriod = if (week.lessons.isEmpty()) 6 else week.lessons.maxOf { maxOf(it.toHour, it.hour) }
        val rowCount = lastPeriod - firstPeriod + 1
        fun rowOf(period: Int) = period - firstPeriod
        holder.body.orientation = LinearLayout.HORIZONTAL
        holder.body.minimumHeight = dp(54) * rowCount

        val labels = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(periodWidth, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        for (period in firstPeriod..lastPeriod) {
            val start = week.lessons.firstOrNull { it.hour == period }?.time?.substringBefore('–').orEmpty()
            val number = period
            labels.addView(TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                gravity = Gravity.CENTER
                textSize = 12f
                text = if (start.isBlank()) "$number" else "$number\n$start"
                setTextColor(onBackground)
                alpha = 0.55f
            })
        }
        holder.body.addView(labels)

        for (dateStr in week.dates) {
            val column = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = dp(2); marginEnd = dp(2)
                }
            }
            // A weekday without any lesson is a free day: one tall tile with a symbol and "Free".
            if (SchoolCalendar.isWeekday(dateStr) && week.lessons.none { it.date == dateStr }) {
                column.addView(
                    slot(ctx, makeFreeTile(holder, SchoolCalendar.freeDay(dateStr), ::dp), ::dp),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, rowCount.toFloat())
                )
                holder.body.addView(column)
                continue
            }
            var cursor = 0 // the next free row in this column
            val byStart = week.lessons.filter { it.date == dateStr }.groupBy { it.hour }.toSortedMap()
            for ((hour, group) in byStart) {
                val firstRow = rowOf(hour)
                val start = maxOf(firstRow, cursor) // lessons never overlap a tile that is already placed
                val lastRow = rowOf(group.maxOf { maxOf(it.toHour, it.hour) })
                val span = lastRow - firstRow + 1
                if (start > cursor) {
                    column.addView(View(ctx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, (start - cursor).toFloat()))
                }
                if (group.size == 1) {
                    column.addView(
                        slot(ctx, makeTile(holder, group[0], ::dp), ::dp),
                        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, span.toFloat())
                    )
                } else {
                    // Several lessons in the same period (a split group): side by side.
                    val side = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                    for (lesson in group) {
                        side.addView(
                            makeTile(holder, lesson, ::dp),
                            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                                .apply { marginStart = dp(1); marginEnd = dp(1) }
                        )
                    }
                    column.addView(
                        slot(ctx, side, ::dp),
                        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, span.toFloat())
                    )
                }
                cursor = start + span
            }
            if (cursor < rowCount) {
                column.addView(View(ctx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, (rowCount - cursor).toFloat()))
            }
            holder.body.addView(column)
        }
    }

    /**
     * The space a tile occupies: as tall as its periods, with the small gap below it inside that
     * space. A gap kept as a margin on the tile would make periods slightly taller in columns
     * that have fewer tiles (e.g. with a double hour), so tiles would differ in size.
     */
    private fun slot(ctx: android.content.Context, tile: View, dp: (Int) -> Int): View =
        FrameLayout(ctx).apply {
            setPadding(0, 0, 0, dp(3))
            addView(tile, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

    /**
     * A day without lessons: a calm, see-through tile with a line icon (one per holiday or break) and "Free", and underneath the
     * holiday or school break that explains it when one is known (e.g. "All Saints' Day").
     */
    private fun makeFreeTile(holder: PageHolder, reason: SchoolCalendar.FreeDay?, dp: (Int) -> Int): View {
        val ctx = holder.itemView.context
        val onBackground = MaterialColors.getColor(
            holder.itemView, com.google.android.material.R.attr.colorOnBackground, Color.GRAY
        )
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(4), dp(2), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(ColorUtils.setAlphaComponent(onBackground, 28))
            }

            addView(ImageView(ctx).apply {
                setImageResource(reason?.icon ?: SchoolCalendar.DEFAULT_ICON)
                imageTintList = ColorStateList.valueOf(onBackground)
                alpha = 0.85f
            }, LinearLayout.LayoutParams(dp(26), dp(26)))
            addView(TextView(ctx).apply {
                text = "Free"
                gravity = Gravity.CENTER
                textSize = 12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(onBackground)
                alpha = 0.8f
            })
            if (reason != null) {
                addView(TextView(ctx).apply {
                    text = reason.name
                    gravity = Gravity.CENTER
                    maxLines = 3
                    ellipsize = TextUtils.TruncateAt.END // only if even the smallest size doesn't fit
                    setTextColor(onBackground)
                    alpha = 0.6f
                    // A long name ("Immaculate Conception") shrinks to fit the narrow column.
                    TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                        this, 6, 10, 1, TypedValue.COMPLEX_UNIT_SP
                    )
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(2) })
            }
        }
    }

    /** One lesson tile (the caller sets its size). Tapping it shows the lesson's details. */
    private fun makeTile(holder: PageHolder, lesson: LessonInfo, dp: (Int) -> Int): View {
        val ctx = holder.itemView.context
        val base = SubjectColors.colorForCode(ctx, lesson.subject.ifBlank { "?" })
        val color = if (lesson.isSubstitute) blend(base) else base
        val textColor = SubjectColors.readableTextColor(color)

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(ctx, R.drawable.pill_subject_chip)!!.mutate() as GradientDrawable
            bg.setColor(color)
            if (lesson.hasExam) {
                // A red stripe down the left edge, with the tile's rounded corners.
                val r = dp(6).toFloat()
                val stripe = GradientDrawable().apply {
                    setColor(EXAM_RED)
                    cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
                }
                background = LayerDrawable(arrayOf(bg, stripe)).apply {
                    setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL)
                    setLayerWidth(1, dp(4))
                }
                setPadding(dp(4), dp(4), dp(2), dp(4))
            } else {
                background = bg
                setPadding(dp(2), dp(4), dp(2), dp(4))
            }

            addView(TextView(ctx).apply {
                text = lesson.subject.ifBlank { "?" }
                gravity = Gravity.CENTER
                textSize = 15f
                maxLines = 2
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(textColor)
            })
            val room = lesson.rooms.substringBefore(',').trim()
            if (room.isNotBlank()) {
                addView(TextView(ctx).apply {
                    text = room
                    gravity = Gravity.CENTER
                    textSize = 10f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END // only if even the smallest size doesn't fit
                    alpha = 0.8f
                    setTextColor(textColor)
                    // A long room name ("Musikraum") shrinks to fit the tile instead of being cut off.
                    TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                        this, 7, 10, 1, TypedValue.COMPLEX_UNIT_SP
                    )
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            setOnClickListener { onLesson(lesson) }
        }
    }

    /** Slightly muted version of a colour, used to flag substitute lessons. */
    private fun blend(color: Int): Int = Color.rgb(
        (Color.red(color) * 0.7 + 255 * 0.3).toInt(),
        (Color.green(color) * 0.7 + 255 * 0.3).toInt(),
        (Color.blue(color) * 0.7 + 255 * 0.3).toInt()
    )
}
