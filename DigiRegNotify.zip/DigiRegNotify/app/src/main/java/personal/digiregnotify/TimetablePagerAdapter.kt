package personal.digiregnotify

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.color.MaterialColors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** What a week page currently holds. */
sealed class WeekState {
    object Loading : WeekState()
    /** [note] is set when this is a stored copy (offline / school unreachable): shown greyed out. */
    data class Loaded(val week: ParsedWeek, val note: String? = null) : WeekState()
    data class Failed(val message: String) : WeekState()
}

/**
 * One page per week, so weeks can be swiped through smoothly (the pages snap into place).
 * Page [BASE] is the current week; there are [PAGES] pages in all, a year either side.
 * A page draws its own grid: periods down the side, days across the top, and lesson tiles whose
 * height follows the periods they cover (a double hour is twice as tall), filling the screen.
 */
class TimetablePagerAdapter(
    private val baseMonday: Calendar,
    private val states: Map<String, WeekState>,
    private val onNeedWeek: (Int) -> Unit,
    private val onRefresh: (Int) -> Unit,
    private val onLesson: (LessonInfo) -> Unit
) : RecyclerView.Adapter<TimetablePagerAdapter.PageHolder>() {

    companion object {
        const val PAGES = 105
        const val BASE = 52
        private val iso = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        private val EXAM_RED = Color.rgb(255, 59, 48)
    }

    class PageHolder(view: View) : RecyclerView.ViewHolder(view) {
        val refresh: SwipeRefreshLayout = view.findViewById(R.id.weekRefresh)
        val header: LinearLayout = view.findViewById(R.id.weekHeader)
        val body: LinearLayout = view.findViewById(R.id.weekBody)
        val message: TextView = view.findViewById(R.id.weekMessage)
        val note: TextView = view.findViewById(R.id.weekNote)
    }

    fun mondayFor(position: Int): Calendar =
        (baseMonday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, (position - BASE) * 7) }

    fun keyFor(position: Int): String = iso.format(mondayFor(position).time)

    override fun getItemCount() = PAGES

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder =
        PageHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_timetable_week, parent, false))

    override fun onBindViewHolder(holder: PageHolder, position: Int) {
        val state = states[keyFor(position)]
        holder.refresh.setOnRefreshListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onRefresh(pos)
        }
        holder.header.removeAllViews()
        holder.body.removeAllViews()
        holder.message.visibility = View.GONE
        // A stored copy is shown greyed out, with a line saying when it was saved.
        val stored = (state as? WeekState.Loaded)?.note
        holder.note.text = stored
        holder.note.visibility = if (stored != null) View.VISIBLE else View.GONE
        val dim = if (stored != null) 0.55f else 1f
        holder.header.alpha = dim
        holder.body.alpha = dim

        when (state) {
            null -> {
                // Not requested yet: ask for it once the list has finished laying out.
                holder.refresh.isRefreshing = true
                holder.itemView.post { onNeedWeek(position) }
            }
            is WeekState.Loading -> holder.refresh.isRefreshing = true
            is WeekState.Failed -> {
                holder.refresh.isRefreshing = false
                holder.message.text = state.message
                holder.message.visibility = View.VISIBLE
            }
            is WeekState.Loaded -> {
                holder.refresh.isRefreshing = false
                if (state.week.lessons.isEmpty()) {
                    holder.message.text = "No lessons this week"
                    holder.message.visibility = View.VISIBLE
                } else {
                    buildGrid(holder, state.week)
                }
            }
        }
    }

    private fun buildGrid(holder: PageHolder, week: ParsedWeek) {
        val ctx = holder.itemView.context
        val density = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        fun themeColor(attr: Int) = MaterialColors.getColor(holder.itemView, attr, Color.GRAY)
        val onBackground = themeColor(com.google.android.material.R.attr.colorOnBackground)
        val primary = themeColor(com.google.android.material.R.attr.colorPrimary)
        val periodWidth = dp(38)
        val today = iso.format(Date())

        // --- Header: weekday and date, with today picked out ---
        holder.header.addView(View(ctx), LinearLayout.LayoutParams(periodWidth, dp(8)))
        for (dateStr in week.dates) {
            val date = TimetableParser.parseDate(dateStr)
            val isToday = dateStr == today
            val cell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2); marginEnd = dp(2); bottomMargin = dp(6)
                }
                gravity = Gravity.CENTER
                textSize = 12f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                text = date?.let {
                    SimpleDateFormat("EEE", Locale.getDefault()).format(it) + "\n" +
                        SimpleDateFormat("d", Locale.getDefault()).format(it)
                } ?: dateStr
                setPadding(dp(2), dp(6), dp(2), dp(6))
                if (isToday) {
                    setTextColor(primary)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(ColorUtils.setAlphaComponent(primary, 40))
                    }
                } else {
                    setTextColor(onBackground)
                    alpha = 0.75f
                }
            }
            holder.header.addView(cell)
        }

        // --- Body ---
        // A column of period labels, then one column per day. Every period is one unit of height
        // and a lesson is as tall as the periods it covers, so a double hour is a tall tile; the
        // gaps between lessons are spacers of the right size. All periods from the first to the
        // last of the week are shown, even ones with no lesson on any day.
        val firstPeriod = week.lessons.minOf { it.hour }
        val lastPeriod = week.lessons.maxOf { maxOf(it.toHour, it.hour) }
        val periodCount = lastPeriod - firstPeriod + 1
        holder.body.orientation = LinearLayout.HORIZONTAL
        holder.body.minimumHeight = dp(54) * periodCount

        val labels = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(periodWidth, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        for (period in firstPeriod..lastPeriod) {
            val start = week.lessons.firstOrNull { it.hour == period }?.time?.substringBefore('–').orEmpty()
            labels.addView(TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                gravity = Gravity.CENTER
                textSize = 12f
                text = if (start.isBlank()) "$period" else "$period\n$start"
                setTextColor(onBackground)
                alpha = 0.55f
            })
        }
        holder.body.addView(labels)

        for (dateStr in week.dates) {
            val column = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = dp(2); marginEnd = dp(2)
                }
            }
            var cursor = firstPeriod // the next free period in this column
            val byStart = week.lessons.filter { it.date == dateStr }.groupBy { it.hour }.toSortedMap()
            for ((hour, group) in byStart) {
                val start = maxOf(hour, cursor) // lessons never overlap a tile that is already placed
                val span = group.maxOf { maxOf(it.toHour, it.hour) } - hour + 1
                if (start > cursor) {
                    column.addView(View(ctx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, (start - cursor).toFloat()))
                }
                if (group.size == 1) {
                    column.addView(
                        slot(ctx, makeTile(holder, group[0], ::dp), ::dp),
                        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, span.toFloat())
                    )
                } else {
                    // Several lessons in the same period (a split group): side by side.
                    val side = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                    for (lesson in group) {
                        side.addView(
                            makeTile(holder, lesson, ::dp),
                            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                                .apply { marginStart = dp(1); marginEnd = dp(1) }
                        )
                    }
                    column.addView(
                        slot(ctx, side, ::dp),
                        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, span.toFloat())
                    )
                }
                cursor = start + span
            }
            if (cursor <= lastPeriod) {
                column.addView(View(ctx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, (lastPeriod + 1 - cursor).toFloat()))
            }
            holder.body.addView(column)
        }
    }

    /**
     * The space a tile occupies: as tall as its periods, with the small gap below it inside that
     * space. A gap kept as a margin on the tile would make periods slightly taller in columns
     * that have fewer tiles (e.g. with a double hour), so tiles would differ in size.
     */
    private fun slot(ctx: android.content.Context, tile: View, dp: (Int) -> Int): View =
        FrameLayout(ctx).apply {
            setPadding(0, 0, 0, dp(3))
            addView(tile, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

    /** One lesson tile (the caller sets its size). Tapping it shows the lesson's details. */
    private fun makeTile(holder: PageHolder, lesson: LessonInfo, dp: (Int) -> Int): View {
        val ctx = holder.itemView.context
        val base = SubjectColors.colorForCode(ctx, lesson.subject.ifBlank { "?" })
        val color = if (lesson.isSubstitute) blend(base) else base
        val textColor = SubjectColors.readableTextColor(color)

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(ctx, R.drawable.pill_subject_chip)!!.mutate() as GradientDrawable
            bg.setColor(color)
            if (lesson.hasExam) {
                // A red stripe down the left edge, with the tile's rounded corners.
                val r = dp(6).toFloat()
                val stripe = GradientDrawable().apply {
                    setColor(EXAM_RED)
                    cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
                }
                background = LayerDrawable(arrayOf(bg, stripe)).apply {
                    setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL)
                    setLayerWidth(1, dp(4))
                }
                setPadding(dp(4), dp(4), dp(2), dp(4))
            } else {
                background = bg
                setPadding(dp(2), dp(4), dp(2), dp(4))
            }

            addView(TextView(ctx).apply {
                text = lesson.subject.ifBlank { "?" }
                gravity = Gravity.CENTER
                textSize = 15f
                maxLines = 2
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(textColor)
            })
            val room = lesson.rooms.substringBefore(',').trim()
            if (room.isNotBlank()) {
                addView(TextView(ctx).apply {
                    text = room
                    gravity = Gravity.CENTER
                    textSize = 10f
                    maxLines = 1
                    alpha = 0.8f
                    setTextColor(textColor)
                })
            }
            setOnClickListener { onLesson(lesson) }
        }
    }

    /** Slightly muted version of a colour, used to flag substitute lessons. */
    private fun blend(color: Int): Int = Color.rgb(
        (Color.red(color) * 0.7 + 255 * 0.3).toInt(),
        (Color.green(color) * 0.7 + 255 * 0.3).toInt(),
        (Color.blue(color) * 0.7 + 255 * 0.3).toInt()
    )
}
