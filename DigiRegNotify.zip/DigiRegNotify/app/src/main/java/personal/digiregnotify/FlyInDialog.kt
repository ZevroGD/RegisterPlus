package personal.digiregnotify

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import com.google.android.material.color.MaterialColors

/**
 * A menu card that flies in from above the screen, passes its spot slightly and settles back
 * (the same small bounce as every pop-up, see res/anim/bounce_small.xml), and flies out upwards
 * when closed. The animation runs on the card inside a full-screen
 * transparent window, so it doesn't depend on the system's dialog animations (which some
 * phones replace with their own) and the card is never clipped while it moves. In fun mode
 * the card then becomes a physical object: it falls, tumbles, can be grabbed and swung around, and
 * wobbles and squashes like jelly (see [JellyCard]).
 */
class FlyInDialog(private val activity: Activity, content: View) {

    private val dialog = Dialog(activity, R.style.DigiReg_FlyDialog)
    private val root = FrameLayout(activity)
    private val card = JellyCard(activity)
    private val density = activity.resources.displayMetrics.density
    private var closing = false

    init {
        val surface = MaterialColors.getColor(activity, com.google.android.material.R.attr.colorSurface, Color.DKGRAY)
        card.body.apply {
            radius = 28f * density
            cardElevation = 8f * density
            setCardBackgroundColor(
                MaterialColors.getColor(activity, com.google.android.material.R.attr.colorSurfaceContainerHigh, surface)
            )
            isClickable = true // taps on the card must not count as taps outside it
            addView(content)
        }
        // In fun mode the card is smaller, in both directions: it gets thrown around the screen.
        card.setFunSize(ExtraPrefs.isFunMode(activity))
        card.visibility = View.INVISIBLE // shown once measured, so there is no flash in place
        val screenWidth = activity.resources.displayMetrics.widthPixels
        val width = minOf(screenWidth - (48 * density).toInt(), (420 * density).toInt())
        // The card is wrapped in a transparent margin, which the jelly can bulge into.
        root.addView(card, FrameLayout.LayoutParams(width + 2 * card.padPx, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.setOnClickListener { dismiss() } // a tap outside the card closes it
    }

    fun show() {
        if (isOpen()) return // tapping the button again while a menu is up must not stack another
        dialog.setContentView(root)
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.55f)
            setWindowAnimations(0)
        }
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                dismiss()
                true
            } else {
                false
            }
        }
        dialog.show()
        open = this
        dialog.setOnDismissListener { if (open === this) open = null }

        // Once the card has its size: park it just above the top edge, then let it fly in.
        root.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (root.height == 0 || card.height == 0) return
                root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                card.translationY = -offscreenDistance()
                card.visibility = View.VISIBLE
                card.animate()
                    .translationY(0f)
                    .setInterpolator(OvershootInterpolator(0.9f)) // small bounce, as in bounce_small.xml
                    .setDuration(380)
                    .withEndAction {
                        // Fun mode (Settings → Extras): from here on the card has gravity and is jelly.
                        if (!closing && ExtraPrefs.isFunMode(activity)) card.startJelly()
                    }
                    .start()
            }
        })
    }

    /** Flies out upwards, then closes. */
    fun dismiss() {
        if (closing) return
        closing = true
        card.stopJelly(keepShape = true) // it turns and un-squashes while it flies out
        card.animate()
            .translationY(-offscreenDistance())
            .rotation(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setInterpolator(AccelerateInterpolator(1.4f))
            .setDuration(240)
            .withEndAction {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    try {
                        dialog.dismiss()
                    } catch (e: Exception) {
                        // already gone
                    }
                }
            }
            .start()
    }

    /** How far up the card must move to be completely above the screen. */
    private fun offscreenDistance(): Float = root.height / 2f + card.height / 2f + 16f * density

    companion object {
        private var open: FlyInDialog? = null

        /** True while a menu is on screen and not already flying out. */
        fun isOpen(): Boolean {
            val current = open ?: return false
            if (!current.dialog.isShowing || current.activity.isFinishing || current.activity.isDestroyed) {
                open = null // left behind by a screen that closed
                return false
            }
            return !current.closing
        }
    }
}
