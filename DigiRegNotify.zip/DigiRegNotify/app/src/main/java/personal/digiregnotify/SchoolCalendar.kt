package personal.digiregnotify

import androidx.annotation.DrawableRes
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * Why a weekday has no lessons, for South Tyrol.
 *
 * Public holidays follow fixed rules, so they are worked out for any year. School breaks are set
 * by the province for each school year, so they are listed below, one block per school year
 * (source: the Schulkalender of the Deutsche Bildungsdirektion, Autonome Provinz Bozen). A year
 * that is not listed here simply has no break names yet: its free days still show as "Free".
 * Days that a single school decides to keep free (its own "flexible days") can't be known and
 * also show as plain "Free".
 *
 * To add a school year, add its breaks to [BREAKS]. The calendars are at
 * https://ladinische-bildung.provinz.bz.it/de/schulkalender-home
 */
object SchoolCalendar {

    enum class Kind { HOLIDAY, BREAK }

    /** [icon] is the line icon shown on the tile; a free day nothing is known about gets [DEFAULT_ICON]. */
    data class FreeDay(val name: String, @DrawableRes val icon: Int, val kind: Kind)

    @DrawableRes
    val DEFAULT_ICON = R.drawable.ic_free_umbrella

    private data class Break(val from: LocalDate, val to: LocalDate, val name: String, @DrawableRes val icon: Int)

    private fun brk(name: String, @DrawableRes icon: Int, fromY: Int, fromM: Int, fromD: Int, toY: Int, toM: Int, toD: Int) =
        Break(LocalDate.of(fromY, fromM, fromD), LocalDate.of(toY, toM, toD), name, icon)

    // Whole calendar days, both ends included. School year 2026/27: lessons run from 7 Sep 2026
    // to 16 Jun 2027 (176 school days, which these dates reproduce exactly).
    private val BREAKS = listOf(
        brk("Summer break", R.drawable.ic_free_sun, 2026, 6, 17, 2026, 9, 6),
        brk("Autumn break", R.drawable.ic_free_leaf, 2026, 11, 2, 2026, 11, 6),
        brk("Christmas break", R.drawable.ic_free_snowflake, 2026, 12, 24, 2027, 1, 6),
        brk("Carnival break", R.drawable.ic_free_hat, 2027, 2, 8, 2027, 2, 12),
        brk("Easter break", R.drawable.ic_free_egg, 2027, 3, 25, 2027, 3, 30),
        brk("Summer break", R.drawable.ic_free_sun, 2027, 6, 17, 2027, 9, 5)
    )

    /** True for Monday to Friday. [date] is "yyyy-MM-dd". */
    fun isWeekday(date: String): Boolean {
        val d = parse(date) ?: return false
        return d.dayOfWeek != DayOfWeek.SATURDAY && d.dayOfWeek != DayOfWeek.SUNDAY
    }

    /** What makes [date] ("yyyy-MM-dd") a free day, or null if nothing known does. */
    fun freeDay(date: String): FreeDay? {
        val d = parse(date) ?: return null
        holiday(d)?.let { return FreeDay(it.first, it.second, Kind.HOLIDAY) }
        BREAKS.firstOrNull { !d.isBefore(it.from) && !d.isAfter(it.to) }
            ?.let { return FreeDay(it.name, it.icon, Kind.BREAK) }
        return null
    }

    private fun parse(date: String): LocalDate? = try {
        LocalDate.parse(date)
    } catch (e: Exception) {
        null
    }

    /** A public holiday's name and icon: the holidays of Italy, plus Whit Monday (school-free in South Tyrol). */
    private fun holiday(d: LocalDate): Pair<String, Int>? {
        val fixed = when (d.monthValue * 100 + d.dayOfMonth) {
            101 -> "New Year's Day" to R.drawable.ic_free_burst
            106 -> "Epiphany" to R.drawable.ic_free_star
            425 -> "Liberation Day" to R.drawable.ic_free_flag
            501 -> "Labour Day" to R.drawable.ic_free_hammer
            602 -> "Republic Day" to R.drawable.ic_free_flag
            815 -> "Assumption Day" to R.drawable.ic_free_church
            1101 -> "All Saints' Day" to R.drawable.ic_free_candle
            1208 -> "Immaculate Conception" to R.drawable.ic_free_church
            1225 -> "Christmas Day" to R.drawable.ic_free_tree
            1226 -> "St. Stephen's Day" to R.drawable.ic_free_gift
            else -> null
        }
        if (fixed != null) return fixed
        val easter = easterSunday(d.year)
        return when (d) {
            easter.plusDays(1) -> "Easter Monday" to R.drawable.ic_free_egg
            easter.plusDays(50) -> "Whit Monday" to R.drawable.ic_free_flame
            else -> null
        }
    }

    /** Easter Sunday (Gregorian calendar, the usual "anonymous" algorithm). */
    private fun easterSunday(year: Int): LocalDate {
        val a = year % 19
        val b = year / 100
        val c = year % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = (h + l - 7 * m + 114) % 31 + 1
        return LocalDate.of(year, month, day)
    }
}
