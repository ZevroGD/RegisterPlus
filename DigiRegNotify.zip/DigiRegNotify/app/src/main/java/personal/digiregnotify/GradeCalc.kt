package personal.digiregnotify

/**
 * The maths behind the edit marks screen. The average is a weighted mean: every mark counts
 * with the weight the school lists for it (100 = a normal mark).
 */
object GradeCalc {
    const val MIN_MARK = 4.0
    const val MAX_MARK = 10.0

    /** Sum of mark x weight, and the sum of the weights, of the marks so far. */
    data class Totals(val weightedSum: Double, val weight: Double) {
        val average: Double? get() = if (weight > 0) weightedSum / weight else null
    }

    fun totals(grades: List<SubjectGrade>): Totals {
        var sum = 0.0
        var weight = 0.0
        for (g in grades) {
            val w = g.weight.coerceAtLeast(0).toDouble()
            sum += g.value * w
            weight += w
        }
        return Totals(sum, weight)
    }
}
