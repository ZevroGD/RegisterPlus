package personal.digiregnotify

import kotlin.math.ceil

/**
 * The maths behind the grade calculator. The average is a weighted mean: every mark counts
 * with the weight the school lists for it (100 = a normal mark).
 */
object GradeCalc {
    const val MIN_MARK = 4.0
    const val MAX_MARK = 10.0

    /** Sum of mark x weight, and the sum of the weights, of the marks so far. */
    data class Totals(val weightedSum: Double, val weight: Double) {
        val average: Double? get() = if (weight > 0) weightedSum / weight else null
    }

    sealed class Need {
        /** [exact] is the mark that hits the target exactly; [rounded] is the next quarter step up. */
        data class Mark(val exact: Double, val rounded: Float) : Need()

        /** The target is already safe, even with the lowest possible mark. */
        object AnyMark : Need()

        /** Even a top mark is not enough; [exact] is what would be needed. */
        data class Unreachable(val exact: Double) : Need()
    }

    fun totals(grades: List<SubjectGrade>): Totals {
        var sum = 0.0
        var weight = 0.0
        for (g in grades) {
            val w = g.weight.coerceAtLeast(0).toDouble()
            sum += g.value * w
            weight += w
        }
        return Totals(sum, weight)
    }

    /** The average after [count] more marks of [mark], each with [weight]. */
    fun averageWith(t: Totals, mark: Double, weight: Double, count: Int): Double {
        val added = weight * count
        return (t.weightedSum + mark * added) / (t.weight + added)
    }

    /** The mark needed on each of [count] more marks (each with [weight]) to reach [target]. */
    fun neededMark(t: Totals, target: Double, weight: Double, count: Int): Need {
        val added = weight * count
        val exact = (target * (t.weight + added) - t.weightedSum) / added
        return when {
            exact <= MIN_MARK -> Need.AnyMark
            exact > MAX_MARK + 1e-9 -> Need.Unreachable(exact)
            else -> {
                // Marks come in quarter steps; round up so the target is really reached.
                val up = ceil(exact * 4 - 1e-6) / 4
                Need.Mark(exact, up.coerceAtMost(MAX_MARK).toFloat())
            }
        }
    }
}
