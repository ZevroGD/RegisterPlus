package personal.digiregnotify

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DueDateFormat {
    // The formats below aren't thread-safe; the home list is now built off the main thread.

    private val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dayFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault())

    /** Parses "yyyy-MM-dd HH:mm:ss" as returned by the API. Null if unparsable. */
    @Synchronized
    fun parse(raw: String?): Date? {
        if (raw.isNullOrBlank()) return null
        return try {
            inputFormat.parse(raw)
        } catch (e: ParseException) {
            null
        }
    }

    private val dayOnlyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    /** Parses a plain "yyyy-MM-dd" day. Null if unparsable. */
    @Synchronized
    fun parseDay(raw: String?): Date? {
        if (raw.isNullOrBlank()) return null
        return try {
            dayOnlyFormat.parse(raw)
        } catch (e: ParseException) {
            null
        }
    }

    /** "Today", "Tomorrow", or "Mon, Oct 5" — used as a section header. */
    @Synchronized
    fun dayLabel(date: Date): String {
        val target = Calendar.getInstance().apply { time = date }
        val today = Calendar.getInstance()
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }

        return when {
            isSameDay(target, today) -> "Today"
            isSameDay(target, tomorrow) -> "Tomorrow"
            else -> dayFormat.format(date)
        }
    }

    /** "08:35" */
    @Synchronized
    fun timeLabel(date: Date): String = timeFormat.format(date)

    private fun isSameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}
