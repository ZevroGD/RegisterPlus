package personal.digiregnotify

/** The Marks screen hands what it loaded to the full-screen chart through here, so that
 *  screen opens instantly without asking the server again. */
object MarksChartData {
    @Volatile var subjects: List<SubjectSummary> = emptyList()
    @Volatile var thickness: Map<Int, Int> = emptyMap() // 0 = hidden on the Marks screen
}

/** Turns subjects with grades into chart series (shared by both chart screens). */
fun buildChartSeries(
    context: android.content.Context,
    subjects: List<SubjectSummary>,
    strokeFor: (SubjectSummary) -> Float
): List<ChartSeries> {
    val isoDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    return subjects.map { s ->
        val dated = s.grades.mapNotNull { g ->
            val date = try {
                isoDate.parse(g.date)?.time
            } catch (e: Exception) {
                null
            }
            date?.let { Triple(it, g.value, listOf(g.type, g.description).filter { t -> t.isNotBlank() }.joinToString(" – ")) }
        }
        ChartSeries(
            subjectId = s.subjectId,
            points = dated.map { it.first to it.second },
            color = SubjectColors.colorForCode(context, s.name),
            strokeWidthDp = strokeFor(s),
            label = SubjectNames.nameFor(context, s.name),
            details = dated.map { it.third }
        )
    }
}
