package personal.digiregnotify

import android.content.Context
import android.util.DisplayMetrics
import android.view.View
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView

/**
 * A small button that fades in once a list is scrolled down a bit and glides it back to the top
 * when tapped; it fades out again near the top. It can be switched off in Settings → Extras.
 */
object ScrollToTop {

    /** Wires the [button] to the [list]. Returns a function that re-checks whether it should show. */
    fun attach(context: Context, list: RecyclerView, button: View): () -> Unit {
        val threshold = 300 * context.resources.displayMetrics.density
        var shown = false

        fun setShown(show: Boolean) {
            if (show == shown) return
            shown = show
            button.animate().cancel()
            if (show) {
                button.visibility = View.VISIBLE
                button.animate().alpha(1f).setDuration(180).start()
            } else {
                button.animate().alpha(0f).setDuration(180).withEndAction {
                    if (!shown) button.visibility = View.GONE // out of the way, and not tappable
                }.start()
            }
        }

        val refresh = {
            setShown(ExtraPrefs.isBackToTop(context) && list.computeVerticalScrollOffset() > threshold)
        }
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) = refresh()
        })
        button.setOnClickListener {
            // Glides up from exactly where you are, at a fixed speed: the further down, the longer it takes.
            val scroller = object : LinearSmoothScroller(context) {
                override fun getVerticalSnapPreference() = SNAP_TO_START
                override fun calculateSpeedPerPixel(displayMetrics: DisplayMetrics): Float =
                    1f / (4f * displayMetrics.density) // milliseconds per pixel: 4000 dp per second
            }
            scroller.targetPosition = 0
            list.layoutManager?.startSmoothScroll(scroller)
        }
        return refresh
    }
}
