package personal.digiregnotify

import org.json.JSONObject

/**
 * A mark's title ("first grammar test") is not in the subject list, only on the subject's own
 * page (subject_detail), as "name". The same mark is found in both replies by its date, mark,
 * weight, type and creation time. The last answer of each subject's page is kept on the phone
 * (see [cacheName]), so titles also show instantly and offline.
 */
object MarkNames {

    fun cacheName(subjectId: Int) = "detail-$subjectId"

    private fun fullKey(date: String, value: Float, weight: Int, typeId: String, created: String) =
        "$date|$value|$weight|$typeId|$created"

    private fun looseKey(date: String, value: Float, weight: Int, typeId: String) =
        "$date|$value|$weight|$typeId"

    /** The titles in one subject_detail reply, by full and by loose key (without creation time). */
    fun parse(json: String): Map<String, String> {
        val array = JSONObject(json).optJSONArray("grades") ?: return emptyMap()
        val result = HashMap<String, String>()
        for (i in 0 until array.length()) {
            val g = array.optJSONObject(i) ?: continue
            if (g.optInt("cancelled", 0) != 0) continue
            val name = if (g.isNull("name")) "" else g.optString("name").trim()
            if (name.isEmpty()) continue
            val value = AllSubjectsParser.parseGradeValue(g.optString("grade")) ?: continue
            val date = g.optString("date")
            val weight = g.optInt("weight", 100)
            val typeId = g.optString("typeId")
            result[fullKey(date, value, weight, typeId, g.optString("createdTimeStamp"))] = name
            result.putIfAbsent(looseKey(date, value, weight, typeId), name)
        }
        return result
    }

    /** Gives every mark its title. [detailJson] returns a subject's page reply, if there is one. */
    fun apply(subjects: List<SubjectSummary>, detailJson: (Int) -> String?): List<SubjectSummary> =
        subjects.map { s ->
            if (s.grades.isEmpty()) return@map s
            val names = try {
                detailJson(s.subjectId)?.let { parse(it) }
            } catch (e: Exception) {
                null
            } ?: return@map s
            s.copy(grades = s.grades.map { g ->
                val name = names[fullKey(g.date, g.value, g.weight, g.typeId, g.created)]
                    ?: names[looseKey(g.date, g.value, g.weight, g.typeId)]
                if (name == null) g else g.copy(name = name)
            })
        }
}
