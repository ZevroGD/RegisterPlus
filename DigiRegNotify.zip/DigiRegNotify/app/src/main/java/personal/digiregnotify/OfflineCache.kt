package personal.digiregnotify

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Raw answers from the school, kept on the phone so the timetable and marks can still be shown
 * when the school's server can't be reached. Written after every successful load, removed on
 * sign-out. A file's modified time is when it was saved.
 */
object OfflineCache {

    private const val DIR = "offline"
    private const val MAX_WEEKS = 16 // timetable weeks kept; the oldest go first

    class Saved(val json: String, val savedAt: Long)

    private fun dir(context: Context): File = File(context.filesDir, DIR).also { it.mkdirs() }

    fun save(context: Context, name: String, json: String) {
        try {
            val target = File(dir(context), "$name.json")
            val temp = File(dir(context), "$name.json.tmp")
            temp.writeText(json)
            if (!temp.renameTo(target)) {
                target.writeText(json)
                temp.delete()
            }
            if (name.startsWith("timetable-")) pruneWeeks(context)
        } catch (e: Exception) {
            DevLog.w("Cache", "could not save $name: ${e.javaClass.simpleName}")
        }
    }

    fun load(context: Context, name: String): Saved? = try {
        val file = File(dir(context), "$name.json")
        if (file.exists()) Saved(file.readText(), file.lastModified()) else null
    } catch (e: Exception) {
        null
    }

    fun clearAll(context: Context) {
        try {
            dir(context).listFiles()?.forEach { it.delete() }
        } catch (e: Exception) {
            // nothing to do
        }
    }

    private fun pruneWeeks(context: Context) {
        val weeks = dir(context).listFiles { f -> f.name.startsWith("timetable-") && f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() } ?: return
        weeks.drop(MAX_WEEKS).forEach { it.delete() }
    }

    /** "13:15" for today, "9 Nov, 13:15" for an earlier day. */
    fun timeLabel(millis: Long): String {
        val then = Calendar.getInstance().apply { timeInMillis = millis }
        val now = Calendar.getInstance()
        val sameDay = then.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
            then.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
        return SimpleDateFormat(if (sameDay) "HH:mm" else "d MMM, HH:mm", Locale.getDefault()).format(Date(millis))
    }

    /** "Saved 13:15 · No internet", the line shown above a stored copy. */
    fun note(savedAt: Long, reason: String): String = "Saved ${timeLabel(savedAt)} · $reason"
}
