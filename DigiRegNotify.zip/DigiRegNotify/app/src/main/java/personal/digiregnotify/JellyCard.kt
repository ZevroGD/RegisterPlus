package personal.digiregnotify

import android.content.Context
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.google.android.material.card.MaterialCardView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The menu card, with the optional "fun mode" physics (Settings → Extras). Once [startJelly] is
 * called the card is a real object: a rigid body with mass, gravity and a moment of inertia
 * that falls, spins and tumbles, and bounces off the screen's edges with the right friction, so
 * landing on a corner makes it flip flat. Grab it anywhere: the finger holds that very spot
 * through a spring, so the card hangs from your finger, swings like a pendulum and turns around
 * the point you hold. On top of that it is jelly: it stretches along its movement, squashes
 * when it hits something and wobbles back, and it squashes while you press hard on it (the
 * phone's pressure or contact area, compared with how you touched it at first). Everything is a
 * small hand-made simulation, no library. Without [startJelly] it is a normal card.
 *
 * Units: pixels and seconds, every mass is 1. Angles are radians, positive = clockwise on screen
 * (the same as the view's own rotation).
 */
class JellyCard(context: Context) : MaterialCardView(context) {

    /** True once [startJelly] has been called (and until [stopJelly]). */
    var jellyEnabled = false
        private set

    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val screenPos = IntArray(2)

    // The body: centre in the parent's coordinates, angle, and their speeds.
    private var cx = 0f
    private var cy = 0f
    private var theta = 0f
    private var vx = 0f
    private var vy = 0f
    private var omega = 0f

    // The finger: where it is (parent coordinates), how fast it moves, and the spot on the card
    // it holds, measured from the card's centre in the card's own (unturned) frame.
    private var grabbing = false // a finger is down on the card
    private var dragging = false // ... and has moved far enough to hold and carry it
    private var downX = 0f
    private var downY = 0f
    private var fx = 0f
    private var fy = 0f
    private var fvx = 0f
    private var fvy = 0f
    private var lastMoveTime = 0L
    private var gx = 0f
    private var gy = 0f

    // Jelly: stretch (+ tall and thin, − flat and wide) as a damped spring, and the press.
    private var q = 0f
    private var qv = 0f
    private var press = 0f
    private var pressTarget = 0f
    private var pressStart = 0L
    private var basePressure = 0f
    private var baseSize = 0f

    private var running = false
    private var lastFrame = 0L
    private var restTime = 0f
    private val frame = Choreographer.FrameCallback { now -> onFrame(now) }

    // ---------------------------------------------------------------- start / stop

    /** Starts the physics from where the card is now: it falls. */
    fun startJelly() {
        jellyEnabled = true
        cx = left + width / 2f + translationX
        cy = top + height / 2f + translationY
        theta = 0f
        vx = 0f; vy = 0f; omega = 0f
        q = 0f; qv = 0f; press = 0f; pressTarget = 0f
        restTime = 0f
        ensureRunning()
    }

    /**
     * Stops the physics. With [keepShape] the card stays as it is (tilted, squashed) so the
     * caller can animate it back to normal; otherwise it is put straight at once.
     */
    fun stopJelly(keepShape: Boolean = false) {
        jellyEnabled = false
        grabbing = false
        dragging = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        if (!keepShape) {
            scaleX = 1f
            scaleY = 1f
            rotation = 0f
        }
    }

    override fun onDetachedFromWindow() {
        stopJelly()
        super.onDetachedFromWindow()
    }

    private fun ensureRunning() {
        if (!jellyEnabled || running) return
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    // ---------------------------------------------------------------- touch

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!jellyEnabled) return super.onInterceptTouchEvent(ev)
        trackPress(ev)
        when (ev.actionMasked) {
            // Buttons inside the card still get the touch; the card only takes over once the
            // finger has moved: then it is a drag, not a tap.
            MotionEvent.ACTION_DOWN -> begin(ev)
            MotionEvent.ACTION_MOVE -> if (grabbing && !dragging && movedPastSlop(ev)) {
                startDrag(ev)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!jellyEnabled) return super.onTouchEvent(ev)
        trackPress(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> begin(ev)
            MotionEvent.ACTION_MOVE -> {
                if (grabbing && !dragging && movedPastSlop(ev)) startDrag(ev)
                if (dragging) moveFinger(ev)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        return true
    }

    private fun updateFinger(ev: MotionEvent) {
        (parent as? View)?.getLocationOnScreen(screenPos)
        fx = ev.rawX - screenPos[0]
        fy = ev.rawY - screenPos[1]
    }

    private fun begin(ev: MotionEvent) {
        updateFinger(ev)
        grabbing = true
        dragging = false
        downX = ev.rawX
        downY = ev.rawY
        // Catching the card (even in mid-air) stops it. The spot under the finger is remembered.
        vx = 0f; vy = 0f; omega = 0f
        fvx = 0f; fvy = 0f
        val dx = fx - cx
        val dy = fy - cy
        val c = cos(theta)
        val s = sin(theta)
        gx = (c * dx + s * dy).coerceIn(-width / 2f, width / 2f)
        gy = (-s * dx + c * dy).coerceIn(-height / 2f, height / 2f)
        restTime = 0f
        ensureRunning()
    }

    private fun movedPastSlop(ev: MotionEvent) =
        abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop

    private fun startDrag(ev: MotionEvent) {
        dragging = true
        lastMoveTime = ev.eventTime
        updateFinger(ev)
    }

    private fun moveFinger(ev: MotionEvent) {
        val oldX = fx
        val oldY = fy
        updateFinger(ev)
        val dtMs = ev.eventTime - lastMoveTime
        if (dtMs > 0) {
            // The finger's speed, smoothed: the damper of the holding spring follows it, so the
            // card is not held back by its own damping while it is being carried.
            fvx = fvx * 0.6f + (fx - oldX) / dtMs * 1000f * 0.4f
            fvy = fvy * 0.6f + (fy - oldY) / dtMs * 1000f * 0.4f
        }
        lastMoveTime = ev.eventTime
    }

    private fun endTouch() {
        grabbing = false
        dragging = false
        pressTarget = 0f
        ensureRunning() // let go: thrown, or dropped
    }

    /**
     * How hard the finger presses: the phone's pressure or contact area, whichever grows more,
     * compared with the first moments of the touch (a finger always settles a little). Phones
     * that report a fixed value simply never squash the card.
     */
    private fun trackPress(ev: MotionEvent) {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            pressStart = ev.eventTime
            basePressure = ev.pressure
            baseSize = ev.size
            pressTarget = 0f
            return
        }
        if (ev.eventTime - pressStart < PRESS_SETTLE_MS) {
            basePressure = max(basePressure, ev.pressure)
            baseSize = max(baseSize, ev.size)
            return
        }
        val byPressure = (ev.pressure - basePressure) / PRESS_RANGE_PRESSURE
        val bySize = (ev.size - baseSize) / PRESS_RANGE_SIZE
        pressTarget = max(byPressure, bySize).coerceIn(0f, 1.3f)
    }

    // ---------------------------------------------------------------- the frame

    private fun onFrame(nowNanos: Long) {
        if (!running) return
        val dt = if (lastFrame == 0L) 1f / 60f else min((nowNanos - lastFrame) / 1e9f, 1f / 25f)
        lastFrame = nowNanos

        if (!dragging) { // the finger's speed fades when it stops moving
            val decay = exp(-dt * 10f)
            fvx *= decay
            fvy *= decay
        }
        val steps = min(12, max(1, ceil(dt / SUB_STEP).toInt()))
        val h = dt / steps
        repeat(steps) { physicsStep(h) }
        jelly(dt)
        applyTransform()

        if (shouldSleep(dt)) {
            running = false
            vx = 0f; vy = 0f; omega = 0f
            q = 0f; qv = 0f; press = 0f
            scaleX = 1f
            scaleY = 1f
            applyTransform()
        } else {
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun inertia(): Float {
        val w = width.toFloat()
        val h = height.toFloat()
        return (w * w + h * h) / 12f // a plate of mass 1
    }

    private fun physicsStep(dt: Float) {
        val p = parent as? View ?: return
        if (grabbing && !dragging) { // held still by a touch (maybe a tap on a button): it stays put
            vx = 0f; vy = 0f; omega = 0f
            return
        }
        val inertia = inertia()

        vy += GRAVITY * density * dt

        if (dragging) {
            // The finger holds the spot [gx, gy] of the card through a spring and a damper.
            val c = cos(theta)
            val s = sin(theta)
            val rx = c * gx - s * gy // that spot, as an offset from the centre, on screen
            val ry = s * gx + c * gy
            val spotVx = vx - omega * ry // how fast the spot moves
            val spotVy = vy + omega * rx
            val ax = HOLD_STIFFNESS * (fx - (cx + rx)) - HOLD_DAMPING * (spotVx - fvx)
            val ay = HOLD_STIFFNESS * (fy - (cy + ry)) - HOLD_DAMPING * (spotVy - fvy)
            vx += ax * dt
            vy += ay * dt
            omega += (rx * ay - ry * ax) / inertia * dt // the torque of that pull
        }

        cx += vx * dt
        cy += vy * dt
        theta += omega * dt
        val air = exp(-LINEAR_DRAG * dt)
        vx *= air
        vy *= air
        omega *= exp(-ANGULAR_DRAG * dt)

        collide(p.width.toFloat(), p.height.toFloat(), inertia)
        collide(p.width.toFloat(), p.height.toFloat(), inertia) // twice: two corners at once
    }

    /** The four corners against the four edges of the screen. */
    private fun collide(screenW: Float, screenH: Float, inertia: Float) {
        val m = 6f * density
        val c = cos(theta)
        val s = sin(theta)
        val hw = width / 2f
        val hh = height / 2f
        for (corner in 0 until 4) {
            val lx = if (corner and 1 == 0) -hw else hw
            val ly = if (corner and 2 == 0) -hh else hh
            val rx = c * lx - s * ly
            val ry = s * lx + c * ly
            for (wall in 0 until 4) {
                // Inward normal and the line: n·p must stay >= d.
                val nx: Float
                val ny: Float
                val d: Float
                when (wall) {
                    0 -> { nx = 1f; ny = 0f; d = m }
                    1 -> { nx = -1f; ny = 0f; d = -(screenW - m) }
                    2 -> { nx = 0f; ny = 1f; d = m }
                    else -> { nx = 0f; ny = -1f; d = -(screenH - m) }
                }
                val depth = d - (nx * (cx + rx) + ny * (cy + ry))
                if (depth <= 0f) continue
                cx += nx * depth // out of the wall
                cy += ny * depth

                val vcx = vx - omega * ry // the corner's velocity
                val vcy = vy + omega * rx
                val vn = vcx * nx + vcy * ny
                if (vn >= 0f) continue // already moving away
                val approach = -vn
                val e = if (approach > REST_SPEED * density) BOUNCE else 0f // slow = no bounce
                val rxn = rx * ny - ry * nx
                val j = -(1f + e) * vn / (1f + rxn * rxn / inertia)
                vx += j * nx
                vy += j * ny
                omega += rxn * j / inertia

                // Friction along the wall: it grips, so a corner hit makes the card spin.
                val tx = -ny
                val ty = nx
                val vt = (vx - omega * ry) * tx + (vy + omega * rx) * ty
                val rxt = rx * ty - ry * tx
                val maxF = FRICTION * j
                val jt = (-vt / (1f + rxt * rxt / inertia)).coerceIn(-maxF, maxF)
                vx += jt * tx
                vy += jt * ty
                omega += rxt * jt / inertia

                if (approach > MIN_HIT * density) hit(approach, nx, ny)
            }
        }
    }

    /** A hit: squash along the direction it came from (flat on the floor, narrow on a wall). */
    private fun hit(approach: Float, nx: Float, ny: Float) {
        val c = cos(theta)
        val s = sin(theta)
        val alongX = abs(nx * c + ny * s) // how much the card's own width faces the hit
        val alongY = abs(-nx * s + ny * c) // ... its height
        val kick = min(approach / density * KICK, MAX_KICK)
        qv += kick * (alongX - alongY)
    }

    /** The jelly: a spring pulled towards what the speed and the press ask for. */
    private fun jelly(dt: Float) {
        val c = cos(theta)
        val s = sin(theta)
        val localVx = (c * vx + s * vy) / density // speed along the card's own axes, in dp/s
        val localVy = (-s * vx + c * vy) / density
        val stretch = (abs(localVy) * 0.00018f - abs(localVx) * 0.00012f).coerceIn(-0.28f, 0.28f)
        press += (pressTarget - press) * (1f - exp(-dt * 25f))
        val target = stretch - press * PRESS_SQUASH
        qv += (-Q_STIFFNESS * (q - target) - Q_DAMPING * qv) * dt
        q = (q + qv * dt).coerceIn(-0.4f, 0.4f)
    }

    /**
     * Puts the view where the body is. The view is turned and squashed around a pivot: the spot
     * the finger holds, or else the edge nearest the floor, so the squash happens against the
     * finger or the floor instead of towards the middle. The translation then keeps that pivot
     * exactly where the body puts it.
     */
    private fun applyTransform() {
        val c = cos(theta)
        val s = sin(theta)
        val w = width.toFloat()
        val h = height.toFloat()
        val pxo: Float // pivot, as an offset from the card's centre
        val pyo: Float
        if (dragging) {
            pxo = gx
            pyo = gy
        } else {
            // the middle of whichever edge is lowest on screen
            var bestX = 0f
            var bestY = h / 2f
            var bestScreenY = s * 0f + c * (h / 2f)
            for (i in 0 until 4) {
                val mx = when (i) { 2 -> -w / 2f; 3 -> w / 2f; else -> 0f }
                val my = when (i) { 0 -> -h / 2f; 1 -> h / 2f; else -> 0f }
                val screenY = s * mx + c * my
                if (screenY > bestScreenY) {
                    bestScreenY = screenY
                    bestX = mx
                    bestY = my
                }
            }
            pxo = bestX
            pyo = bestY
        }
        val pivotLocalX = w / 2f + pxo
        val pivotLocalY = h / 2f + pyo
        pivotX = pivotLocalX
        pivotY = pivotLocalY
        scaleX = 1f - 0.75f * q // the volume stays about the same: taller means thinner
        scaleY = 1f + q
        rotation = Math.toDegrees(theta.toDouble()).toFloat()
        val pivotWorldX = cx + c * pxo - s * pyo
        val pivotWorldY = cy + s * pxo + c * pyo
        translationX = pivotWorldX - left - pivotLocalX
        translationY = pivotWorldY - top - pivotLocalY
    }

    /** True once the card lies still on the floor and its jelly has settled. */
    private fun shouldSleep(dt: Float): Boolean {
        val p = parent as? View ?: return false
        if (grabbing || dragging) {
            restTime = 0f
            return false
        }
        val c = cos(theta)
        val s = sin(theta)
        var lowest = -1e9f
        for (corner in 0 until 4) {
            val lx = if (corner and 1 == 0) -width / 2f else width / 2f
            val ly = if (corner and 2 == 0) -height / 2f else height / 2f
            lowest = max(lowest, cy + s * lx + c * ly)
        }
        val onFloor = lowest >= p.height - 6f * density - 1f
        val still = abs(vx) < 8f * density && abs(vy) < 8f * density && abs(omega) < 0.08f &&
            abs(q) < 0.003f && abs(qv) < 0.1f && press < 0.01f
        restTime = if (onFloor && still) restTime + dt else 0f
        return restTime > 0.25f
    }

    companion object {
        private const val GRAVITY = 2600f // dp/s²
        private const val BOUNCE = 0.35f // how much speed a hit leaves
        private const val FRICTION = 0.5f // grip on the edges
        private const val REST_SPEED = 120f // dp/s: slower hits don't bounce at all
        private const val MIN_HIT = 100f // dp/s: softer touches don't wobble the card
        private const val LINEAR_DRAG = 0.15f
        private const val ANGULAR_DRAG = 0.6f
        private const val SUB_STEP = 1f / 300f // the simulation steps in small slices per frame

        private const val HOLD_STIFFNESS = 6400f // the finger's spring: stiff = follows closely
        private const val HOLD_DAMPING = 136f

        private const val KICK = 0.0034f // squash per dp/s of impact
        private const val MAX_KICK = 6f
        private const val Q_STIFFNESS = 420f // jelly spring: low damping = wobbly
        private const val Q_DAMPING = 9f

        private const val PRESS_SETTLE_MS = 150L
        private const val PRESS_RANGE_PRESSURE = 0.25f // a rise this big = pressed as hard as it gets
        private const val PRESS_RANGE_SIZE = 0.15f
        private const val PRESS_SQUASH = 0.2f
    }
}
