package personal.digiregnotify

import android.content.Context
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.google.android.material.card.MaterialCardView
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * The menu card, with the optional "fun mode" physics (Settings → Extras). Once [startJelly] is
 * called the card falls to the bottom of the screen and bounces, can be grabbed and thrown
 * around, and wobbles like jelly: it stretches along its movement, tilts, squashes when it hits
 * a wall and then springs back. Everything is a small hand-made simulation (a gravity step plus
 * two damped springs per frame), no library. With [startJelly] never called the card is just a
 * normal card.
 */
class JellyCard(context: Context) : MaterialCardView(context) {

    /** True once [startJelly] has been called (and until [stopJelly]). */
    var jellyEnabled = false
        private set

    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private var grabbing = false // a finger is down on the card
    private var dragging = false // ... and has moved far enough to drag it
    private var downX = 0f
    private var downY = 0f
    private var grabX = 0f
    private var grabY = 0f
    private var lastMoveTime = 0L
    private var lastTx = 0f
    private var lastTy = 0f

    // Movement in px and px/s.
    private var vx = 0f
    private var vy = 0f

    // Jelly: stretch (+ tall and thin, − flat and wide) and tilt in degrees, each a damped spring.
    private var q = 0f
    private var qv = 0f
    private var r = 0f
    private var rv = 0f

    private var running = false
    private var lastFrame = 0L
    private val frame = Choreographer.FrameCallback { now -> onFrame(now) }

    /** Starts the physics from where the card is now: it falls. */
    fun startJelly() {
        jellyEnabled = true
        pivotX = width / 2f
        pivotY = height * 0.8f // squashes towards its bottom, so it stays on the floor
        vx = 0f
        vy = 0f
        ensureRunning()
    }

    /** Stops the physics and puts the card's shape back to normal (before it flies out). */
    fun stopJelly() {
        jellyEnabled = false
        grabbing = false
        dragging = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        scaleX = 1f
        scaleY = 1f
        rotation = 0f
    }

    override fun onDetachedFromWindow() {
        stopJelly()
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- touch

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!jellyEnabled) return super.onInterceptTouchEvent(ev)
        when (ev.actionMasked) {
            // Buttons inside the card still get the touch; the card only takes over once the
            // finger has moved: then it is a drag, not a tap.
            MotionEvent.ACTION_DOWN -> begin(ev)
            MotionEvent.ACTION_MOVE -> if (grabbing && !dragging && movedPastSlop(ev)) {
                startDrag(ev)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!jellyEnabled) return super.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> begin(ev)
            MotionEvent.ACTION_MOVE -> {
                if (grabbing && !dragging && movedPastSlop(ev)) startDrag(ev)
                if (dragging) dragTo(ev)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        return true
    }

    private fun begin(ev: MotionEvent) {
        grabbing = true
        dragging = false
        downX = ev.rawX
        downY = ev.rawY
        vx = 0f // catching the card in mid-air stops it
        vy = 0f
        ensureRunning()
    }

    private fun movedPastSlop(ev: MotionEvent) =
        abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop

    private fun startDrag(ev: MotionEvent) {
        dragging = true
        grabX = ev.rawX - translationX
        grabY = ev.rawY - translationY
        lastTx = translationX
        lastTy = translationY
        lastMoveTime = ev.eventTime
    }

    private fun dragTo(ev: MotionEvent) {
        val tx = (ev.rawX - grabX).coerceIn(-limitX(), limitX())
        val ty = (ev.rawY - grabY).coerceIn(-limitY(), limitY())
        val dtMs = ev.eventTime - lastMoveTime
        if (dtMs > 0) {
            // The finger's speed, smoothed; it is what the card is thrown with when let go.
            vx = vx * 0.6f + (tx - lastTx) / dtMs * 1000f * 0.4f
            vy = vy * 0.6f + (ty - lastTy) / dtMs * 1000f * 0.4f
        }
        translationX = tx
        translationY = ty
        lastTx = tx
        lastTy = ty
        lastMoveTime = ev.eventTime
    }

    private fun endTouch() {
        grabbing = false
        dragging = false
        ensureRunning() // thrown, or dropped
    }

    // ---------------------------------------------------------------- physics

    private fun margin() = 6f * density

    /** How far the card may move sideways / up and down from the centre and stay on screen. */
    private fun limitX(): Float {
        val p = parent as? View ?: return 0f
        return max(0f, (p.width - width) / 2f - margin())
    }

    private fun limitY(): Float {
        val p = parent as? View ?: return 0f
        return max(0f, (p.height - height) / 2f - margin())
    }

    private fun ensureRunning() {
        if (!jellyEnabled || running) return
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun onFrame(nowNanos: Long) {
        if (!running) return
        val dt = if (lastFrame == 0L) 1f / 60f else min((nowNanos - lastFrame) / 1e9f, 1f / 30f)
        lastFrame = nowNanos
        step(dt)
        if (atRest()) {
            running = false
            scaleX = 1f
            scaleY = 1f
            rotation = 0f
            q = 0f; qv = 0f; r = 0f; rv = 0f
            vx = 0f; vy = 0f
        } else {
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun step(dt: Float) {
        val lx = limitX()
        val ly = limitY()

        if (grabbing || dragging) {
            // The finger holds the card. Its speed fades when the finger stops moving.
            val decay = exp(-dt * 10f)
            vx *= decay
            vy *= decay
        } else {
            vy += GRAVITY * density * dt
            vx *= exp(-dt * 0.2f) // a little air drag
            var tx = translationX + vx * dt
            var ty = translationY + vy * dt
            if (tx < -lx) {
                tx = -lx
                if (vx < 0) { hit(vx, sideways = true); vx = -vx * BOUNCE }
            } else if (tx > lx) {
                tx = lx
                if (vx > 0) { hit(vx, sideways = true); vx = -vx * BOUNCE }
            }
            if (ty > ly) {
                ty = ly
                if (vy > 0) {
                    if (vy > MIN_HIT * density) hit(vy, sideways = false)
                    vy = -vy * BOUNCE
                    if (abs(vy) < REST_SPEED * density) vy = 0f
                }
                vx *= exp(-dt * 4f) // friction on the floor
            } else if (ty < -ly) {
                ty = -ly
                if (vy < 0) { hit(vy, sideways = false); vy = -vy * BOUNCE }
            }
            translationX = tx
            translationY = ty
        }

        // The jelly: two springs pulled towards what the current speed asks for.
        val vxDp = vx / density
        val vyDp = vy / density
        val stretchTarget = (abs(vyDp) * 0.00018f - abs(vxDp) * 0.00012f).coerceIn(-0.28f, 0.28f)
        val tiltTarget = (vxDp * 0.004f).coerceIn(-12f, 12f)
        qv += (-Q_STIFFNESS * (q - stretchTarget) - Q_DAMPING * qv) * dt
        q = (q + qv * dt).coerceIn(-0.4f, 0.4f)
        rv += (-R_STIFFNESS * (r - tiltTarget) - R_DAMPING * rv) * dt
        r += rv * dt
        scaleX = 1f - 0.75f * q // volume stays about the same: taller means thinner
        scaleY = 1f + q
        rotation = r
    }

    /** A hit on a wall, floor or ceiling: squash against it and wobble. */
    private fun hit(speed: Float, sideways: Boolean) {
        val kick = min(abs(speed) / density * KICK, MAX_KICK)
        if (sideways) qv += kick else qv -= kick
        rv += (vx / density) * 0.01f
    }

    private fun atRest(): Boolean {
        if (grabbing || dragging) return false
        val onFloor = translationY >= limitY() - 0.5f
        return onFloor &&
            abs(vx) < REST_SPEED * density * 0.1f && abs(vy) < 1f &&
            abs(q) < 0.002f && abs(qv) < 0.05f && abs(r) < 0.05f && abs(rv) < 0.5f
    }

    companion object {
        private const val GRAVITY = 2600f // dp/s²
        private const val BOUNCE = 0.5f // how much speed a hit leaves
        private const val REST_SPEED = 150f // dp/s: slower bounces stop
        private const val MIN_HIT = 100f // dp/s: softer touches don't wobble the card
        private const val KICK = 0.0034f // squash per dp/s of impact
        private const val MAX_KICK = 6f
        private const val Q_STIFFNESS = 420f // stretch spring: low damping = wobbly
        private const val Q_DAMPING = 9f
        private const val R_STIFFNESS = 300f // tilt spring
        private const val R_DAMPING = 7f
    }
}
