package personal.digiregnotify

import android.content.Context
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import androidx.annotation.RequiresApi
import com.google.android.material.card.MaterialCardView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The menu card, with the optional "fun mode" physics (Settings → Extras).
 *
 * It is a wrapper around the visible card [body], with a transparent margin all around so the
 * jelly has room to bulge out. Once [startJelly] is called:
 *  - The card is a rigid body with mass, gravity and a moment of inertia that falls, spins and
 *    tumbles and bounces off the screen's edges with friction. Grab it anywhere: the finger
 *    holds that spot through a spring, so the card hangs from it, swings and turns around it.
 *  - The jelly is a real warp of the picture (Android 13+, a small shader): the four corners
 *    are soft springs that lag behind when the finger pulls the card (the parts far from the
 *    finger lag the most) and that are kicked when the card hits something (the far side keeps
 *    going and squashes against the near side), and the card as a whole squashes and stretches
 *    like a jelly block, flat against the floor or the finger. Pressing hard squashes it too
 *    (the phone's touch pressure or contact area, compared with the first moments of the touch).
 *  - On older phones the warp is replaced by a plain squash and stretch of the card.
 *
 * Units: pixels and seconds, every mass is 1. Angles are radians, positive = clockwise on screen
 * (the same as the view's own rotation).
 */
class JellyCard(context: Context) : FrameLayout(context) {

    /** The visible card: set its look and add its content here. */
    val body = MaterialCardView(context)

    private val density = resources.displayMetrics.density

    /** The transparent margin around the card, in px. */
    val padPx = (64f * density).toInt()

    /** True once [startJelly] has been called (and until [stopJelly]). */
    var jellyEnabled = false
        private set

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val screenPos = IntArray(2)

    // The body: centre in the parent's coordinates, angle, and their speeds.
    private var cx = 0f
    private var cy = 0f
    private var theta = 0f
    private var vx = 0f
    private var vy = 0f
    private var omega = 0f

    // The finger: where it is (parent coordinates), how fast it moves, and the spot on the card
    // it holds, measured from the card's centre in the card's own (unturned) frame.
    private var grabbing = false // a finger is down on the card
    private var dragging = false // ... and has moved far enough to hold and carry it
    private var downX = 0f
    private var downY = 0f
    private var fx = 0f
    private var fy = 0f
    private var fvx = 0f
    private var fvy = 0f
    private var lastMoveTime = 0L
    private var gx = 0f
    private var gy = 0f
    private var pullX = 0f // the finger's pull on the card, summed over a frame's small steps
    private var pullY = 0f
    private var pullSteps = 0

    // Jelly: the whole card squashes/stretches (q, a spring) ...
    private var q = 0f
    private var qv = 0f
    // ... and each of the four corners (top-left, top-right, bottom-left, bottom-right) is a
    // soft spring too: how far it is from where a stiff card would have it, and how fast it moves.
    private val ox = FloatArray(4)
    private val oy = FloatArray(4)
    private val ovx = FloatArray(4)
    private val ovy = FloatArray(4)

    // The press.
    private var press = 0f
    private var pressTarget = 0f
    private var pressStart = 0L
    private var basePressure = 0f
    private var baseSize = 0f

    private var effect: JellyEffect? = null // the warp, on Android 13+

    private var running = false
    private var lastFrame = 0L
    private var restTime = 0f
    private val frame = Choreographer.FrameCallback { now -> onFrame(now) }

    init {
        setPadding(padPx, padPx, padPx, padPx)
        clipChildren = false
        clipToPadding = false
        addView(body, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    private fun bodyW() = (width - 2 * padPx).toFloat()
    private fun bodyH() = (height - 2 * padPx).toFloat()

    // ---------------------------------------------------------------- start / stop

    /** Starts the physics from where the card is now: it falls. */
    fun startJelly() {
        jellyEnabled = true
        effect = if (Build.VERSION.SDK_INT >= 33) JellyEffect() else null
        if (effect != null) body.cardElevation = 0f // a shadow would not bend with the card
        cx = left + width / 2f + translationX
        cy = top + height / 2f + translationY
        theta = 0f
        vx = 0f; vy = 0f; omega = 0f
        q = 0f; qv = 0f; press = 0f; pressTarget = 0f
        clearCorners()
        restTime = 0f
        ensureRunning()
    }

    /**
     * Stops the physics. With [keepShape] the card stays as it is (turned, squashed) so the
     * caller can animate it back to normal; otherwise it is put straight at once.
     */
    fun stopJelly(keepShape: Boolean = false) {
        jellyEnabled = false
        grabbing = false
        dragging = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        clearEffect()
        if (!keepShape) {
            scaleX = 1f
            scaleY = 1f
            rotation = 0f
        }
    }

    private fun clearEffect() {
        if (effect != null) {
            effect = null
            if (Build.VERSION.SDK_INT >= 31) setRenderEffect(null)
        }
    }

    private fun clearCorners() {
        for (i in 0 until 4) {
            ox[i] = 0f; oy[i] = 0f; ovx[i] = 0f; ovy[i] = 0f
        }
    }

    override fun onDetachedFromWindow() {
        stopJelly()
        super.onDetachedFromWindow()
    }

    private fun ensureRunning() {
        if (!jellyEnabled || running) return
        // The warp is taken off while the card sleeps; put it back when it wakes up.
        if (effect == null && Build.VERSION.SDK_INT >= 33) effect = JellyEffect()
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    // ---------------------------------------------------------------- touch

    /** Touches in the transparent margin are not on the card: they go on to the screen behind. */
    private fun insideBody(ev: MotionEvent) =
        ev.x >= padPx && ev.x <= width - padPx && ev.y >= padPx && ev.y <= height - padPx

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!jellyEnabled) return super.onInterceptTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && !insideBody(ev)) return false
        trackPress(ev)
        when (ev.actionMasked) {
            // Buttons inside the card still get the touch; the card only takes over once the
            // finger has moved: then it is a drag, not a tap.
            MotionEvent.ACTION_DOWN -> begin(ev)
            MotionEvent.ACTION_MOVE -> if (grabbing && !dragging && movedPastSlop(ev)) {
                startDrag(ev)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!jellyEnabled) return super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && !insideBody(ev)) return false
        trackPress(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> begin(ev)
            MotionEvent.ACTION_MOVE -> {
                if (grabbing && !dragging && movedPastSlop(ev)) startDrag(ev)
                if (dragging) moveFinger(ev)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        return true
    }

    private fun updateFinger(ev: MotionEvent) {
        (parent as? View)?.getLocationOnScreen(screenPos)
        fx = ev.rawX - screenPos[0]
        fy = ev.rawY - screenPos[1]
    }

    private fun begin(ev: MotionEvent) {
        updateFinger(ev)
        grabbing = true
        dragging = false
        downX = ev.rawX
        downY = ev.rawY
        // Catching the card (even in mid-air) stops it. The spot under the finger is remembered.
        vx = 0f; vy = 0f; omega = 0f
        fvx = 0f; fvy = 0f
        val dx = fx - cx
        val dy = fy - cy
        val c = cos(theta)
        val s = sin(theta)
        gx = (c * dx + s * dy).coerceIn(-bodyW() / 2f, bodyW() / 2f)
        gy = (-s * dx + c * dy).coerceIn(-bodyH() / 2f, bodyH() / 2f)
        restTime = 0f
        ensureRunning()
    }

    private fun movedPastSlop(ev: MotionEvent) =
        abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop

    private fun startDrag(ev: MotionEvent) {
        dragging = true
        lastMoveTime = ev.eventTime
        updateFinger(ev)
    }

    private fun moveFinger(ev: MotionEvent) {
        val oldX = fx
        val oldY = fy
        updateFinger(ev)
        val dtMs = ev.eventTime - lastMoveTime
        if (dtMs > 0) {
            // The finger's speed, smoothed: the damper of the holding spring follows it, so the
            // card is not held back by its own damping while it is being carried.
            fvx = fvx * 0.6f + (fx - oldX) / dtMs * 1000f * 0.4f
            fvy = fvy * 0.6f + (fy - oldY) / dtMs * 1000f * 0.4f
        }
        lastMoveTime = ev.eventTime
    }

    private fun endTouch() {
        grabbing = false
        dragging = false
        pressTarget = 0f
        ensureRunning() // let go: thrown, or dropped
    }

    /**
     * How hard the finger presses: the phone's pressure or contact area, whichever grows more,
     * compared with the first moments of the touch (a finger always settles a little). Phones
     * that report a fixed value simply never squash the card.
     */
    private fun trackPress(ev: MotionEvent) {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            pressStart = ev.eventTime
            basePressure = ev.pressure
            baseSize = ev.size
            pressTarget = 0f
            return
        }
        if (ev.eventTime - pressStart < PRESS_SETTLE_MS) {
            basePressure = max(basePressure, ev.pressure)
            baseSize = max(baseSize, ev.size)
            return
        }
        val byPressure = (ev.pressure - basePressure) / PRESS_RANGE_PRESSURE
        val bySize = (ev.size - baseSize) / PRESS_RANGE_SIZE
        pressTarget = max(byPressure, bySize).coerceIn(0f, 1.3f)
    }

    // ---------------------------------------------------------------- the frame

    private fun onFrame(nowNanos: Long) {
        if (!running) return
        val dt = if (lastFrame == 0L) 1f / 60f else min((nowNanos - lastFrame) / 1e9f, 1f / 25f)
        lastFrame = nowNanos

        if (!dragging) { // the finger's speed fades when it stops moving
            val decay = exp(-dt * 10f)
            fvx *= decay
            fvy *= decay
        }
        pullX = 0f; pullY = 0f; pullSteps = 0
        val steps = min(12, max(1, ceil(dt / SUB_STEP).toInt()))
        val h = dt / steps
        repeat(steps) { physicsStep(h) }
        jelly(dt)
        applyTransform()

        if (shouldSleep(dt)) {
            running = false
            vx = 0f; vy = 0f; omega = 0f
            q = 0f; qv = 0f; press = 0f
            clearCorners()
            scaleX = 1f
            scaleY = 1f
            applyTransform()
            clearEffect()
        } else {
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun inertia(): Float {
        val w = bodyW()
        val h = bodyH()
        return (w * w + h * h) / 12f // a plate of mass 1
    }

    private fun physicsStep(dt: Float) {
        val p = parent as? View ?: return
        if (grabbing && !dragging) { // held still by a touch (maybe a tap on a button): it stays put
            vx = 0f; vy = 0f; omega = 0f
            return
        }
        val inertia = inertia()

        vy += GRAVITY * density * dt

        if (dragging) {
            // The finger holds the spot [gx, gy] of the card through a spring and a damper.
            val c = cos(theta)
            val s = sin(theta)
            val rx = c * gx - s * gy // that spot, as an offset from the centre, on screen
            val ry = s * gx + c * gy
            val spotVx = vx - omega * ry // how fast the spot moves
            val spotVy = vy + omega * rx
            val ax = HOLD_STIFFNESS * (fx - (cx + rx)) - HOLD_DAMPING * (spotVx - fvx)
            val ay = HOLD_STIFFNESS * (fy - (cy + ry)) - HOLD_DAMPING * (spotVy - fvy)
            vx += ax * dt
            vy += ay * dt
            omega += (rx * ay - ry * ax) / inertia * dt // the torque of that pull
            pullX += ax
            pullY += ay
            pullSteps++
        }

        cx += vx * dt
        cy += vy * dt
        theta += omega * dt
        val air = exp(-LINEAR_DRAG * dt)
        vx *= air
        vy *= air
        omega *= exp(-ANGULAR_DRAG * dt)

        collide(p.width.toFloat(), p.height.toFloat(), inertia)
        collide(p.width.toFloat(), p.height.toFloat(), inertia) // twice: two corners at once
    }

    /** The four corners against the four edges of the screen. */
    private fun collide(screenW: Float, screenH: Float, inertia: Float) {
        val m = 6f * density
        val c = cos(theta)
        val s = sin(theta)
        val hw = bodyW() / 2f
        val hh = bodyH() / 2f
        for (corner in 0 until 4) {
            val lx = if (corner and 1 == 0) -hw else hw
            val ly = if (corner and 2 == 0) -hh else hh
            val rx = c * lx - s * ly
            val ry = s * lx + c * ly
            for (wall in 0 until 4) {
                // Inward normal and the line: n·p must stay >= d.
                val nx: Float
                val ny: Float
                val d: Float
                when (wall) {
                    0 -> { nx = 1f; ny = 0f; d = m }
                    1 -> { nx = -1f; ny = 0f; d = -(screenW - m) }
                    2 -> { nx = 0f; ny = 1f; d = m }
                    else -> { nx = 0f; ny = -1f; d = -(screenH - m) }
                }
                val depth = d - (nx * (cx + rx) + ny * (cy + ry))
                if (depth <= 0f) continue
                cx += nx * depth // out of the wall
                cy += ny * depth

                val vcx = vx - omega * ry // the corner's velocity
                val vcy = vy + omega * rx
                val vn = vcx * nx + vcy * ny
                if (vn >= 0f) continue // already moving away
                val approach = -vn
                val e = if (approach > REST_SPEED * density) BOUNCE else 0f // slow = no bounce
                val rxn = rx * ny - ry * nx
                val j = -(1f + e) * vn / (1f + rxn * rxn / inertia)
                vx += j * nx
                vy += j * ny
                omega += rxn * j / inertia

                // Friction along the wall: it grips, so a corner hit makes the card spin.
                val tx = -ny
                val ty = nx
                val vt = (vx - omega * ry) * tx + (vy + omega * rx) * ty
                val rxt = rx * ty - ry * tx
                val maxF = FRICTION * j
                val jt = (-vt / (1f + rxt * rxt / inertia)).coerceIn(-maxF, maxF)
                vx += jt * tx
                vy += jt * ty
                omega += rxt * jt / inertia

                if (approach > MIN_HIT * density) hit(approach, nx, ny, rx, ry)
            }
        }
    }

    /**
     * A hit at the corner [rx], [ry] (offset from the centre) against a wall with inward normal
     * [nx], [ny]. The whole card squashes along the direction it came from (flat on the floor,
     * narrow against a wall), and the corners are kicked: the near ones have stopped, the far
     * ones carry on towards the wall for a moment, so the card squashes and then wobbles back.
     */
    private fun hit(approach: Float, nx: Float, ny: Float, rx: Float, ry: Float) {
        val c = cos(theta)
        val s = sin(theta)
        val alongX = abs(nx * c + ny * s) // how much the card's own width faces the hit
        val alongY = abs(-nx * s + ny * c) // ... its height
        val kick = min(approach / density * KICK, MAX_KICK)
        qv += kick * (alongX - alongY)

        val nlx = c * nx + s * ny // the wall's normal and the hit, in the card's own axes
        val nly = -s * nx + c * ny
        val hitX = c * rx + s * ry
        val hitY = -s * rx + c * ry
        val maxDist = hypot(bodyW(), bodyH())
        val corner = min(approach * CORNER_KICK, MAX_CORNER_KICK * density)
        for (i in 0 until 4) {
            val d = hypot(cornerX(i) - hitX, cornerY(i) - hitY) / maxDist // 0 at the hit, 1 far away
            val k = corner * (0.2f + 0.8f * d)
            ovx[i] -= nlx * k
            ovy[i] -= nly * k
        }
    }

    private fun cornerX(i: Int) = if (i and 1 == 0) -bodyW() / 2f else bodyW() / 2f
    private fun cornerY(i: Int) = if (i and 2 == 0) -bodyH() / 2f else bodyH() / 2f

    /** The jelly: springs pulled towards what the finger, the speed and the press ask for. */
    private fun jelly(dt: Float) {
        val c = cos(theta)
        val s = sin(theta)

        // The whole card: stretches along its movement, flattens under a hard press.
        val localVx = (c * vx + s * vy) / density // speed along the card's own axes, in dp/s
        val localVy = (-s * vx + c * vy) / density
        val stretch = (abs(localVy) * 0.00018f - abs(localVx) * 0.00012f).coerceIn(-0.28f, 0.28f)
        press += (pressTarget - press) * (1f - exp(-dt * 25f))
        val target = stretch - press * PRESS_SQUASH
        qv += (-Q_STIFFNESS * (q - target) - Q_DAMPING * qv) * dt
        q = (q + qv * dt).coerceIn(-0.4f, 0.4f)

        // The corners: the finger pulls on one spot, so the card's far parts lag behind it.
        var lagX = 0f
        var lagY = 0f
        if (dragging && pullSteps > 0) {
            val ax = pullX / pullSteps
            val ay = pullY / pullSteps
            lagX = -(c * ax + s * ay) * LAG_GAIN // in the card's own axes, opposite to the pull
            lagY = -(-s * ax + c * ay) * LAG_GAIN
        }
        val maxLag = LAG_MAX * density
        val maxDist = max(1f, hypot(bodyW(), bodyH()))
        for (i in 0 until 4) {
            val w = if (dragging) hypot(cornerX(i) - gx, cornerY(i) - gy) / maxDist else 0f
            val tx = (lagX * w).coerceIn(-maxLag, maxLag)
            val ty = (lagY * w).coerceIn(-maxLag, maxLag)
            ovx[i] += (-C_STIFFNESS * (ox[i] - tx) - C_DAMPING * ovx[i]) * dt
            ovy[i] += (-C_STIFFNESS * (oy[i] - ty) - C_DAMPING * ovy[i]) * dt
            ox[i] = (ox[i] + ovx[i] * dt).coerceIn(-maxLag * 2f, maxLag * 2f)
            oy[i] = (oy[i] + ovy[i] * dt).coerceIn(-maxLag * 2f, maxLag * 2f)
        }
    }

    /**
     * Puts the view where the body is. With the warp the view is only moved and turned about its
     * centre and the shader paints the jelly. Without it the view is turned and squashed around
     * a pivot: the spot the finger holds, or else the edge nearest the floor, so the squash
     * happens against the finger or the floor; the translation then keeps that pivot exactly
     * where the body puts it.
     */
    private fun applyTransform() {
        val c = cos(theta)
        val s = sin(theta)
        val bw = bodyW()
        val bh = bodyH()
        val pxo: Float // the anchor, as an offset from the card's centre
        val pyo: Float
        if (dragging) {
            pxo = gx
            pyo = gy
        } else {
            // the middle of whichever edge is lowest on screen
            var bestX = 0f
            var bestY = bh / 2f
            var bestScreenY = c * (bh / 2f)
            for (i in 0 until 4) {
                val mx = when (i) { 2 -> -bw / 2f; 3 -> bw / 2f; else -> 0f }
                val my = when (i) { 0 -> -bh / 2f; 1 -> bh / 2f; else -> 0f }
                val screenY = s * mx + c * my
                if (screenY > bestScreenY) {
                    bestScreenY = screenY
                    bestX = mx
                    bestY = my
                }
            }
            pxo = bestX
            pyo = bestY
        }
        rotation = Math.toDegrees(theta.toDouble()).toFloat()

        val warp = effect
        if (warp != null) {
            pivotX = width / 2f
            pivotY = height / 2f
            scaleX = 1f
            scaleY = 1f
            translationX = cx - left - width / 2f
            translationY = cy - top - height / 2f
            warp.update(
                this, width.toFloat(), height.toFloat(), padPx.toFloat(),
                width / 2f + pxo, height / 2f + pyo, q, bw, ox, oy, 2f * density
            )
        } else {
            val pivotLocalX = width / 2f + pxo
            val pivotLocalY = height / 2f + pyo
            pivotX = pivotLocalX
            pivotY = pivotLocalY
            scaleX = 1f - 0.75f * q // the volume stays about the same: taller means thinner
            scaleY = 1f + q
            val pivotWorldX = cx + c * pxo - s * pyo
            val pivotWorldY = cy + s * pxo + c * pyo
            translationX = pivotWorldX - left - pivotLocalX
            translationY = pivotWorldY - top - pivotLocalY
        }
    }

    /** True once the card lies still on the floor and its jelly has settled. */
    private fun shouldSleep(dt: Float): Boolean {
        val p = parent as? View ?: return false
        if (grabbing || dragging) {
            restTime = 0f
            return false
        }
        val c = cos(theta)
        val s = sin(theta)
        var lowest = -1e9f
        for (corner in 0 until 4) {
            lowest = max(lowest, cy + s * cornerX(corner) + c * cornerY(corner))
        }
        val onFloor = lowest >= p.height - 6f * density - 1f
        var cornersStill = true
        for (i in 0 until 4) {
            if (abs(ox[i]) > 0.5f || abs(oy[i]) > 0.5f || abs(ovx[i]) > 5f || abs(ovy[i]) > 5f) {
                cornersStill = false
            }
        }
        val still = abs(vx) < 8f * density && abs(vy) < 8f * density && abs(omega) < 0.08f &&
            abs(q) < 0.003f && abs(qv) < 0.1f && press < 0.01f && cornersStill
        restTime = if (onFloor && still) restTime + dt else 0f
        return restTime > 0.25f
    }

    companion object {
        private const val GRAVITY = 2600f // dp/s²
        private const val BOUNCE = 0.35f // how much speed a hit leaves
        private const val FRICTION = 0.5f // grip on the edges
        private const val REST_SPEED = 120f // dp/s: slower hits don't bounce at all
        private const val MIN_HIT = 100f // dp/s: softer touches don't wobble the card
        private const val LINEAR_DRAG = 0.15f
        private const val ANGULAR_DRAG = 0.6f
        private const val SUB_STEP = 1f / 300f // the simulation steps in small slices per frame

        private const val HOLD_STIFFNESS = 6400f // the finger's spring: stiff = follows closely
        private const val HOLD_DAMPING = 136f

        private const val KICK = 0.0034f // whole-card squash per dp/s of impact
        private const val MAX_KICK = 6f
        private const val Q_STIFFNESS = 420f // whole-card spring: low damping = wobbly
        private const val Q_DAMPING = 9f

        private const val CORNER_KICK = 0.1f // corner speed (px/s) per px/s of impact
        private const val MAX_CORNER_KICK = 450f // dp/s
        private const val LAG_GAIN = 0.0012f // corner lag (px) per px/s² of the finger's pull
        private const val LAG_MAX = 34f // dp
        private const val C_STIFFNESS = 380f // corner springs: low damping = jelly
        private const val C_DAMPING = 7f

        private const val PRESS_SETTLE_MS = 150L
        private const val PRESS_RANGE_PRESSURE = 0.25f // a rise this big = pressed as hard as it gets
        private const val PRESS_RANGE_SIZE = 0.15f
        private const val PRESS_SQUASH = 0.2f
    }
}

/**
 * The jelly's warp (Android 13+): every pixel is looked up a little away from where it is, by
 * an amount that follows the four soft corners (blended across the card), a squash/stretch of
 * the whole card around an anchor (the held spot or the floor) and a bow so the sides bulge
 * when it is squashed and pinch when it is stretched.
 */
@RequiresApi(33)
private class JellyEffect {
    private val shader = RuntimeShader(AGSL)

    fun update(
        view: View, w: Float, h: Float, pad: Float, anchorX: Float, anchorY: Float, q: Float,
        bodyW: Float, ox: FloatArray, oy: FloatArray, margin: Float
    ) {
        shader.setFloatUniform("size", w, h)
        shader.setFloatUniform("pad", pad, pad)
        shader.setFloatUniform("anchor", anchorX, anchorY)
        shader.setFloatUniform("sq", -0.75f * q, q)
        shader.setFloatUniform("bow", -q * 0.35f * bodyW, 0f)
        shader.setFloatUniform("c00", ox[0], oy[0])
        shader.setFloatUniform("c10", ox[1], oy[1])
        shader.setFloatUniform("c01", ox[2], oy[2])
        shader.setFloatUniform("c11", ox[3], oy[3])
        shader.setFloatUniform("maxOff", pad - margin)
        view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "image"))
    }

    private companion object {
        const val AGSL = """
            uniform shader image;
            uniform float2 size;
            uniform float2 pad;
            uniform float2 anchor;
            uniform float2 sq;
            uniform float2 bow;
            uniform float2 c00;
            uniform float2 c10;
            uniform float2 c01;
            uniform float2 c11;
            uniform float maxOff;

            half4 main(float2 p) {
                float2 body = size - 2.0 * pad;
                float2 uv = (p - pad) / body;
                float2 u = clamp(uv, 0.0, 1.0);
                float2 off = mix(mix(c00, c10, u.x), mix(c01, c11, u.x), u.y);
                off += (p - anchor) * sq;
                float2 cc = clamp(uv - 0.5, -0.5, 0.5);
                off.x += cc.x * bow.x * (1.0 - 4.0 * cc.y * cc.y);
                off.y += cc.y * bow.y * (1.0 - 4.0 * cc.x * cc.x);
                float len = length(off);
                if (len > maxOff) {
                    off *= maxOff / len;
                }
                return image.eval(p - off);
            }
        """
    }
}
