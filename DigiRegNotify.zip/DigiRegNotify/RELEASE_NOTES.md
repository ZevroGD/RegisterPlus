## What's new

**Changed**
- Developer menu: the log is now shown newest first and shortened, so the latest lines are at the top and the page isn't pushed far down. It shows 30 entries at first ("Show more" adds older ones), drops the date from each line (a line marks each new day) and merges identical repeated entries into one line with "×N". "Copy" still copies the full log with complete timestamps.
- Settings: "GitHub access" now says "(optional)", and its dialog explains that updates work fine without a token and when you would want one (only if the update check reports that GitHub's limit was reached).
