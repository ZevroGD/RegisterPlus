## What's new

**Changed**
- Grade calculator: a toggle at the top switches between two modes, and the app remembers your choice.
  - Simple: your average now, a table of what each mark from 10 down to 4 on the next test would do to it (green up, red down), and one sentence with the lowest mark you need to stay at your current whole-number average. Nothing to set.
  - Advanced: everything adjustable. Count the whole year or one semester, say how many tests are still to come and how much each counts, set the average you want to see the mark you need, and slide a mark to see what your average becomes.
