## What's new

**Changed**
- New Settings section "Extras", every item with its own switch:
  - Evening reminder: at a time you choose, a notification lists what is due tomorrow, with any test or exam first. It works from the last saved data, so it needs no connection.
  - Quiet hours: no background checks between two times you choose (for example at night).
  - Colour homework by time left: a card's outline turns yellow, orange or red as its deadline gets close.
  - Back-to-top button: now also on Messages and History, and it can be switched off.
- Timetable: a period with no lesson on any day of the week no longer gets an empty row, and the period numbers count the rows shown (1, 2, 3 … without skipping).
- Messages now keep a saved copy too: with no internet they show the last one, greyed out, with a line saying when it was saved.

**Fixed**
- Timetable: the red exam stripe now only marks tests and exams. Before, nearly everything attached to a lesson that wasn't plain homework got one, so about a third of a normal week was striped.
- Timetable: long room names such as "Musikraum" or "Werkraum" now shrink to fit their tile instead of being cut off.
- Timetable: a week that failed to load, or is only a saved copy, is tried again when you come back to it, and keeps showing while it does.
- Messages: opening an unread message no longer reloads the whole list afterwards, which could cut its opening animation short.
