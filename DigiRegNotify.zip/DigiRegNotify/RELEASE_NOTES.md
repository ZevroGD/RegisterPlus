## What's new

**Changed**
- Grade calculator rebuilt to be understood at a glance. Open a subject on the Marks screen and tap "Grade calculator": it shows your average now and a short table, "if you get this mark on the next test, your average becomes this", from 10 down to 4, with the change in green or red. Below it, one sentence says the lowest mark you need to stay at your current whole-number average (or to reach a 6 if you are below it). There is nothing to set.
- Year or semester, the number of tests still to come and how much each counts are under "More options".
- The calculator now uses the marks your school actually gives (4 to 10).
