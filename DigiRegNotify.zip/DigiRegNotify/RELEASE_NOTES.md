## What's new

**Added**
- Marks: a new "Edit marks" button at the very bottom of the Marks screen opens a copy of the Marks screen where the marks can be edited, for all subjects at once. Open a subject and an "Add mark" button sits at the top of it; it first asks for everything (the mark, the weight in % and the semester) and only adds the mark when you tap "Add". Tap a mark to open it, then change its mark or its weight (%), or remove it. The chart, the subject averages and the overall average update at once, and the overall average shows the difference from your real one. "Reset" brings back the real marks. Nothing is sent to the school or saved, and leaving the screen drops the changes.

**Changed**
- Marks: the old grade calculator (Simple/Advanced, in each opened subject) is gone; the new edit screen replaces it.
- Marks: a mark's weight is now always shown, also when it is 100% (before, 100% was left blank).
- Developer menu: the log now lists the field names the school sends for a mark and for a subject's detail page (names only, no values).

**Fixed**
- Settings: the X (back) button and the title now stay in place when you scroll, like on the Marks and Developer screens. Before, they scrolled out of view.
- Homework cards: all text can now be selected and copied. Before, only the description, the text of attachments and the edit-history text could be selected. The subject badge, the category line (the title above the description), the "Edited …" timestamps in the edit history and the mark on the history screen could not. Links and files in the attachment list still open on tap, as before.
