## 1.7.6

**Changed**
- Fun mode: the jelly is now a real warp of the card instead of just making it bigger and smaller. The four corners are soft springs: when you drag the card by one spot, the parts far from your finger lag behind and wobble back; when it hits an edge, the far side keeps going for a moment and squashes against the near side. The sides bulge when it is squashed and pinch when it is stretched, and the squash stays anchored on your finger or on the floor. This needs Android 13 or newer; on older phones the old squash is used. The menu card has no shadow in fun mode, because a shadow would not bend with it.
