## What's new

**Changed**
- Timetable: the holiday and free-day tiles no longer have a box; the icon, "Free" and the name sit directly on the background.

**Fixed**
- Timetable: the "Today" button and the week arrows are now vertically centred in the header row. The arrows are drawn as proper icons, because the ‹ and › characters used before sat too low.
- Timetable: the name of a lesson or of a holiday or break is no longer cut in the middle of a word (for example "Chris-tmas break" or "Lehra-usgang"); the text shrinks to fit the column instead.
- Settings: the boxes are now evenly spaced. The "Account" box was almost touching the "Notifications" heading, and the "Developer menu" button sat closer to the box above than the boxes do to each other.
