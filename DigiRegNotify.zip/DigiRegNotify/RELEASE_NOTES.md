## 1.7.4

**Added**
- Settings → Extras: a new "Fun mode" switch (off by default), just to try what is possible. With it on, a menu card falls to the bottom of the screen and bounces, can be grabbed, dragged and thrown around, and wobbles like jelly: it stretches while it moves, tilts, and squashes when it hits an edge.

**Changed**
- Timetable: the lesson popup is tidier. The labels (Time, Room, Teacher) sit in a column on the left with the facts next to them, "Cancelled" and "Substitute lesson" are shown in color at the top, and the unclear "Also: Test, Mappe" line is now called "Homework & tests". The text in the popup can be selected and copied.
- Timetable: the line under the title shows only the month (for example "This week · November") instead of the dates of the week. A week that spans two months shows both ("November – December"), and the year is added when it isn't the current one.
