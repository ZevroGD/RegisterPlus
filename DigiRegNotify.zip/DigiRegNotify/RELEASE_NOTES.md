## 1.7.8

**Changed**
- Fun mode: the whole menu card is smaller, in width and in height (about a fifth smaller each way, so roughly 40% less area). The normal menu is unchanged.
