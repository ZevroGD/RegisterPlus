## What's new

**Changed**
- Updates: when you tap "Download" on mobile data (or any metered connection, such as a phone hotspot), the app now asks first and tells you how big the update is, with "Download now" and "Wait for Wi-Fi". On normal Wi-Fi nothing changes.
- Updates: an update that was already downloaded completely (for example when the install was cancelled) is reused instead of being downloaded again.
- Developer log: every download now records how many KB it used and whether the connection was metered.
