## What's new

**Changed**
- You can now select and copy more text: mark descriptions and teacher observations on the Marks screen, the old versions of an edited homework in its edit history, the text of new-mark notices, and the status and error messages on the main, Marks, Messages and Homework screens (handy when you want to report a problem). Long-press the text to select it.
- Timetable: a period with no lesson on any day of the week is now shown as an empty row instead of being left out, so the numbers on the left are always the school's real period numbers. Nothing is shown after the last period that has a lesson.
- Timetable: a weekday without any lessons now shows a palm tree and "Free" instead of an empty column. When the day is a South Tyrol public holiday (New Year, Epiphany, Easter Monday, 25 April, 1 May, Whit Monday, 2 June, 15 August, All Saints', 8 December, Christmas, St. Stephen's) or a school break (summer, autumn, Christmas, carnival and Easter break of 2026/27), its name is shown underneath, with its own plain line icon (a Christmas tree, fireworks, an egg, a candle and so on). A free day with no known reason shows an umbrella. Weeks without any lessons are shown the same way instead of just saying "No lessons this week".

**Fixed**
- Timetable: after a free period in the middle of the day, the lessons were labelled one period too early (the 8th hour was shown as the 7th).
- Timetable: the "Today" button is now centred in the header row, at the same height as the week arrows.
