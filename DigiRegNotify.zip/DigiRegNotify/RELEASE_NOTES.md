## 1.7.3

**Changed**
- Edit marks: simpler screen. The explanation text under the title, the chart and the "Reset to the real marks" button are gone (closing the screen and opening it again also brings back the real marks), and "Add mark" no longer asks for a semester.
- Pop-ups and menus: they now all settle with the same small bounce. The menu card used to bounce a lot more and took 700 ms to arrive; it now takes about 380 ms, like the other pop-ups. (The system time picker in Settings keeps the system's own animation.)
- Edit marks: a subject whose marks you changed now shows how far its average moved, as a small +0.12 or −0.12 to the left of the average (like the one under "Average of all subjects"). It only shows when something changed.
