## 1.7.2

**Fixed**
- Marks: every mark now shows its title (for example "Test · first vocabulary test"), as on the website. The title was never in the subject list the app used; it is on each subject's own page, which the app now loads for all subjects with marks. The last answers are kept on the phone, so the titles show right away next time, also offline. A mark that is new shows its title a moment after the page opens. The titles also show in the chart's mark details and on the Edit marks screen.

**Changed**
- Developer menu: the field-name lines in the log (added in 1.7.0 and 1.7.1 to find the titles) are gone again.
