## 1.7.5

**Changed**
- Fun mode: the menu card is now a proper physical object. It has weight and falls, spins and tumbles (landing on a corner makes it flip flat), and bounces off the edges of the screen with friction. Grab it anywhere: it hangs from your finger on that spot, swings like a pendulum and turns around the point you hold. It still stretches, squashes on impact and wobbles like jelly, and now it also squashes when you press hard on it (it needs a phone that reports touch pressure or contact area).
