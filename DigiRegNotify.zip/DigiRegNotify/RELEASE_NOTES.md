## What's new

**Changed**
- Grade calculator made simpler. It now shows your current average, then two plain questions: "I want an average of …" (use − and + to set it) tells you the lowest mark you need on the next test, and a slider shows what your average becomes if you get a certain mark. It starts on your current whole-number average, so the first answer is always a useful one.
- Year or semester, the number of tests still to come and how much each counts are now under "More options", since most people never need them.

**Fixed**
- Grade calculator: the "Sem." buttons were cut off to "Se…" on narrow screens.
