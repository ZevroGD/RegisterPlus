## What's new

**Changed**
- Settings: a new "About" section at the bottom shows the app name and version and says that the app is unofficial and that your login details are stored encrypted on the phone. It has three links: the source code on GitHub, the releases and changelog page, and the Digitales Register website.
