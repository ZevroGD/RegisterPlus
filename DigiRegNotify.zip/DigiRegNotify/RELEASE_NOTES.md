## What's new

**Changed**
- Marks: a new card right under the chart shows your average over all subjects (the mean of the subject averages listed below).
- Marks: the "Grade calculator" button in an opened subject now stretches over the full width instead of sitting at the left.
