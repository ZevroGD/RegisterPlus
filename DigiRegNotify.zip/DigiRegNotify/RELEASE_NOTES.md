## What's new

**Added**
- Marks: a new "Edit marks (what-if)" button at the very bottom of the Marks screen. Pick a subject and a full screen opens with all its marks. Tap a mark to open it, then change its mark or its weight (%), or remove it. "Add mark" first asks for everything (the mark, the weight in % and the semester) and only adds it when you tap "Add". The average, and the average of each semester, update at once and show the difference from your real average. "Reset" brings back the real marks. It's only a simulation: nothing is sent to the school or saved, and leaving the screen drops the changes.

**Changed**
- Marks: the old grade calculator (Simple/Advanced, in each opened subject) is gone; the what-if screen above replaces it.
- Marks: a mark's weight is now always shown, also when it is 100% (before, 100% was left blank).
- Developer menu: the log now lists the field names the school sends for a mark (names only, no values).

**Fixed**
- Homework cards: all text can now be selected and copied. Before, only the description, the text of attachments and the edit-history text could be selected. The subject badge, the category line (the title above the description), the "Edited …" timestamps in the edit history and the mark on the history screen could not. Links and files in the attachment list still open on tap, as before.
