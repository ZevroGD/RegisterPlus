## 1.7.7

**Changed**
- Fun mode: the menu card is smaller (about a fifth narrower than the normal menu). The normal menu is unchanged.
