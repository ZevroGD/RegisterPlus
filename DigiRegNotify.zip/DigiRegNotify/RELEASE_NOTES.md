## What's new

**Fixed**
- The back-to-top button on Home no longer jumps first. It glides up from where you are at a steady speed, so a longer way takes longer.
