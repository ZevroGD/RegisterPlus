## What's new

**Changed**
- Timetable: cancelled lessons are now recognised. The school only writes "Ausfall" where the room would go; the app now shows such a lesson faded and struck through, with "Cancelled" instead of the room, and the lesson details say "Cancelled".
- Timetable changes notification: you now also get a notification when a lesson from today onwards becomes cancelled, for example "Tomorrow / Cancelled: 3 Maths". It uses the existing "Timetable changes" switch in Settings.
- Faster-feeling screens: Homework, Marks, Messages and the Timetable now show the last data the school sent straight away while the fresh data loads (the small refresh spinner still runs at the top), instead of an empty screen. When the new data arrives it replaces the old without being greyed out.
- Homework: when the fresh list arrives, the list stays where you had scrolled to instead of jumping back to the top.

**Fixed**
- Homework search: the keyboard sometimes came up without the search field being selected. The field now gets focus again once the search bar has finished sliding open.
